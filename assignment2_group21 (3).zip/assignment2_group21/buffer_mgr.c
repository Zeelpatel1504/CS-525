#include <stdio.h>
#include <stdlib.h>
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include <math.h>
#include "buffer_mgr_stat.h"  

// Global variables to track buffer management
int bufferSize = 0;       // Size of the buffer pool
int rearIndex = 0;        // Index for the rear of the buffer pool
int writeCount = 0;       // Count of write operations to disk
int hit = 0;              // Count of page hits
int clockPointer = 0;     // Pointer for the CLOCK replacement strategy
int lruKPointer = 0;      // Pointer for the LRU-K replacement strategy

// Function prototypes for various page replacement strategies
extern void FIFO(BM_BufferPool *const bm, PageFrame *page);
extern void LRU(BM_BufferPool *const bm, PageFrame *page);
extern void CLOCK(BM_BufferPool *const bm, PageFrame *page);
extern void LRUK(BM_BufferPool *const bm, PageFrame *page); // LRU-K added

// External function prototypes for buffer management
extern RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                         const int numPages, ReplacementStrategy strategy,
                         void *stratData);

extern RC shutdownBufferPool(BM_BufferPool *const bm);
extern RC forceFlushPool(BM_BufferPool *const bm);
extern RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page);
extern RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page);
extern RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page,
                    const PageNumber pageNum);
extern RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page,
                  const PageNumber pageNum);

extern PageNumber *getFrameContents(BM_BufferPool *const bm);
extern bool *getDirtyFlags(BM_BufferPool *const bm);
extern int *getFixCounts(BM_BufferPool *const bm);
extern int getNumReadIO(BM_BufferPool *const bm);
extern int getNumWriteIO(BM_BufferPool *const bm);

// FIFO Strategy Implementation
extern void FIFO(BM_BufferPool *const bm, PageFrame *page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Access the page frames from management data
    int i, frontIndex;
    frontIndex = rearIndex % bufferSize; // Calculate the front index for FIFO

    // Find an unpinned page to replace
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[frontIndex].fixCount == 0) {
            // Write the dirty page back to disk if necessary
            if (pageFrame[frontIndex].dirtyBit == 1) {
                SM_FileHandle fh;
                openPageFile(bm->pageFile, &fh);
                writeBlock(pageFrame[frontIndex].pageNum, &fh, pageFrame[frontIndex].data);
                writeCount++;
            }

            // Replace the page with the new page data
            pageFrame[frontIndex] = *page;
            break;
        } else {
            frontIndex = (frontIndex + 1) % bufferSize; // Move to the next index
        }
    }
}

// LRU-K Strategy Implementation
extern void LRUK(BM_BufferPool *const bm, PageFrame *page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;
    int leastHitIndex = -1;
    int leastHitNum = -1;

    // Iterate through the buffer pool to find the least recently used page
    for (int i = 0; i < bm->numPages; i++) {
        if (pageFrame[i].fixCount == 0) { // Only consider unpinned pages
            if (leastHitNum == -1 || pageFrame[i].hitNum < leastHitNum) {
                leastHitIndex = i;
                leastHitNum = pageFrame[i].hitNum;
            }
        }
    }

    // If a valid least used page is found
    if (leastHitIndex != -1) {
        // Write back the dirty page if needed
        if (pageFrame[leastHitIndex].dirtyBit == 1) {
            SM_FileHandle fh;
            openPageFile(bm->pageFile, &fh);
            writeBlock(pageFrame[leastHitIndex].pageNum, &fh, pageFrame[leastHitIndex].data);
            writeCount++;
            printf("LRU-K: Wrote dirty page %d back to disk.\n", pageFrame[leastHitIndex].pageNum);
        }

        // Log the replacement action
        printf("LRU-K: Replacing page %d (hits: %d) with page %d.\n", 
                pageFrame[leastHitIndex].pageNum, pageFrame[leastHitIndex].hitNum, page->pageNum);

        // Free existing page data if necessary
        if (pageFrame[leastHitIndex].data) {
            free(pageFrame[leastHitIndex].data); // Ensure we're freeing allocated memory
        }

        // Replace with new page data and update metadata
        pageFrame[leastHitIndex] = *page;      // Replace with new page data
        pageFrame[leastHitIndex].hitNum = 1;   // Initialize hit number for the new page
        pageFrame[leastHitIndex].dirtyBit = 0; // New page is not dirty initially
        pageFrame[leastHitIndex].fixCount = 1;  // Set fix count for the new page

        // Log the state of the buffer after replacement
        char *poolContents = sprintPoolContent(bm); // Ensure this returns a properly allocated string
        if (poolContents) {
            printf("LRU-K: Current pool contents: %s\n", poolContents);
            free(poolContents); // Free allocated memory
        } else {
            printf("LRU-K: Failed to retrieve pool contents.\n");
        }
    } else {
        printf("LRU-K: No replacement needed; all pages are pinned.\n");
    }
}

// CLOCK Strategy Implementation
extern void CLOCK(BM_BufferPool *const bm, PageFrame *page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;
    while (1) {
        clockPointer = (clockPointer % bufferSize); // Circularly iterate through the pages

        if (pageFrame[clockPointer].hitNum == 0) { // If the page is not used
            // Write the dirty page back to disk if needed
            if (pageFrame[clockPointer].dirtyBit == 1) {
                SM_FileHandle fh;
                openPageFile(bm->pageFile, &fh);
                writeBlock(pageFrame[clockPointer].pageNum, &fh, pageFrame[clockPointer].data);
                writeCount++;
            }

            // Replace the page with new data
            pageFrame[clockPointer] = *page;
            pageFrame[clockPointer].hitNum = 1; // Mark the new page as recently used
            clockPointer++; // Move the clock pointer
            break;
        } else {
            pageFrame[clockPointer++].hitNum = 0; // Reset the hit number
        }
    }
}

// LRU Strategy Implementation
extern void LRU(BM_BufferPool *const bm, PageFrame *page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;
    int i, leastHitIndex = -1, leastHitNum = -1;

    // Find the least recently used page
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].fixCount == 0) { // Only consider unpinned pages
            if (leastHitNum == -1 || pageFrame[i].hitNum < leastHitNum) {
                leastHitIndex = i; // Update the index of the least hit page
                leastHitNum = pageFrame[i].hitNum; // Update the least hit number
            }
        }
    }

    // Write back the dirty page if needed
    if (leastHitIndex != -1 && pageFrame[leastHitIndex].dirtyBit == 1) {
        SM_FileHandle fh;
        openPageFile(bm->pageFile, &fh);
        writeBlock(pageFrame[leastHitIndex].pageNum, &fh, pageFrame[leastHitIndex].data);
        writeCount++;
    }

    // Replace the page with new data
    pageFrame[leastHitIndex] = *page;
    pageFrame[leastHitIndex].hitNum = ++hit; // Update the hit number for the replaced page
}

extern RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                         const int numPages, ReplacementStrategy strategy,
                         void *stratData) {
    bm->pageFile = (char *)pageFileName; // Store the page file name in the buffer pool structure
    bm->numPages = numPages; // Set the number of pages in the buffer pool
    bm->strategy = strategy; // Set the replacement strategy

    // Allocate memory for the page frames
    PageFrame *page = malloc(sizeof(PageFrame) * numPages);
    bufferSize = numPages; // Set the global buffer size
    int i;

    // Initialize each page frame in the buffer
    for (i = 0; i < bufferSize; i++) {
        page[i].data = NULL; // No data initially
        page[i].pageNum = NO_PAGE; // No page number assigned
        page[i].dirtyBit = 0; // Not dirty
        page[i].fixCount = 0; // Not pinned
        page[i].hitNum = 0; // No hits yet
        page[i].refNum = 0; // Reference number
    }

    bm->mgmtData = page; // Set the management data to the allocated page frames
    writeCount = clockPointer = lruKPointer = 0; // Reset counts and pointers
    return RC_OK; // Return success
}

extern RC shutdownBufferPool(BM_BufferPool *const bm) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    forceFlushPool(bm); // Write back any dirty pages to disk
    int i;

    // Check for pinned pages before shutting down
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].fixCount != 0) { // If any page is pinned
            return RC_PINNED_PAGES_IN_BUFFER; // Return error
        }
    }

    free(pageFrame); // Free allocated memory for page frames
    bm->mgmtData = NULL; // Reset management data
    return RC_OK; // Return success
}

extern RC forceFlushPool(BM_BufferPool *const bm) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i;

    // Write back all dirty pages that are not pinned
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].fixCount == 0 && pageFrame[i].dirtyBit == 1) {
            SM_FileHandle fh;
            openPageFile(bm->pageFile, &fh);
            writeBlock(pageFrame[i].pageNum, &fh, pageFrame[i].data);
            pageFrame[i].dirtyBit = 0; // Reset dirty bit after writing
            writeCount++; // Increment write count
        }
    }
    return RC_OK; // Return success
}

extern RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i;

    // Mark the specified page as dirty
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].pageNum == page->pageNum) { // Find the page in the buffer
            pageFrame[i].dirtyBit = 1; // Mark as dirty
            return RC_OK; // Return success
        }
    }
    return RC_ERROR; // Return error if page not found
}

extern RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i;

    // Unpin the specified page by decrementing its fix count
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].pageNum == page->pageNum) { // Find the page in the buffer
            pageFrame[i].fixCount--; // Decrement fix count
            break; // Exit loop
        }
    }
    return RC_OK; // Return success
}

extern RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page,const PageNumber pageNum) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i;

    // Write the specified page back to disk
    for (i = 0; i < bufferSize; i++) {
        if (pageFrame[i].pageNum == page->pageNum) { // Find the page in the buffer
            SM_FileHandle fh;
            openPageFile(bm->pageFile, &fh);
            writeBlock(pageFrame[i].pageNum, &fh, pageFrame[i].data);
            pageFrame[i].dirtyBit = 0; // Reset dirty bit after writing
            writeCount++; // Increment write count
        }
    }
    return RC_OK; // Return success
}

extern RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page,
                  const PageNumber pageNum) {
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data

    // If the first frame is empty, initialize it
    if (pageFrame[0].pageNum == NO_PAGE) {
        SM_FileHandle fh;
        openPageFile(bm->pageFile, &fh);
        pageFrame[0].data = (SM_PageHandle) malloc(PAGE_SIZE); // Allocate memory for page data
        ensureCapacity(pageNum, &fh); // Ensure the page file can hold the page
        readBlock(pageNum, &fh, pageFrame[0].data); // Read the block from disk
        pageFrame[0].pageNum = pageNum; // Set the page number
        pageFrame[0].fixCount = 1; // Pin the page
        rearIndex = hit = 0; // Reset rear index and hit count
        pageFrame[0].hitNum = hit; // Set hit number for the new page
        pageFrame[0].refNum = 0; // Reset reference number
        page->pageNum = pageNum; // Update the page handle
        page->data = pageFrame[0].data; // Set the page data
        return RC_OK; // Return success
    } else {
        int i;
        bool isBufferFull = true;

        // Check if the page is already in the buffer
        for (i = 0; i < bufferSize; i++) {
            if (pageFrame[i].pageNum != NO_PAGE) {
                if (pageFrame[i].pageNum == pageNum) {
                    pageFrame[i].fixCount++; // Increment fix count
                    isBufferFull = false; // Buffer is not full
                    hit++; // Increment hit count

                    // Update hit numbers based on the strategy
                    if (bm->strategy == RS_LRU)
                        pageFrame[i].hitNum = hit;
                    else if (bm->strategy == RS_CLOCK)
                        pageFrame[i].hitNum = 1;

                    page->pageNum = pageNum; // Update the page handle
                    page->data = pageFrame[i].data; // Set the page data
                    clockPointer++; // Increment clock pointer
                    break; // Exit loop
                }
            } else {
                // If there is an empty frame, load the page into it
                SM_FileHandle fh;
                openPageFile(bm->pageFile, &fh);
                pageFrame[i].data = (SM_PageHandle) malloc(PAGE_SIZE); // Allocate memory for the new page
                readBlock(pageNum, &fh, pageFrame[i].data); // Read the block from disk
                pageFrame[i].pageNum = pageNum; // Set the page number
                pageFrame[i].fixCount = 1; // Pin the page
                pageFrame[i].refNum = 0; // Reset reference number
                rearIndex++; // Increment rear index
                hit++; // Increment hit count

                // Update hit numbers based on the strategy
                if (bm->strategy == RS_LRU)
                    pageFrame[i].hitNum = hit;
                else if (bm->strategy == RS_CLOCK)
                    pageFrame[i].hitNum = 1;

                page->pageNum = pageNum; // Update the page handle
                page->data = pageFrame[i].data; // Set the page data
                isBufferFull = false; // Buffer is not full
                break; // Exit loop
            }
        }

        // If the buffer is full, we need to apply the replacement strategy
        if (isBufferFull) {
            PageFrame *newPage = (PageFrame *) malloc(sizeof(PageFrame)); // Create a new page frame
            SM_FileHandle fh;
            openPageFile(bm->pageFile, &fh);
            newPage->data = (SM_PageHandle) malloc(PAGE_SIZE); // Allocate memory for page data
            readBlock(pageNum, &fh, newPage->data); // Read the block from disk
            newPage->pageNum = pageNum; // Set the page number
            newPage->dirtyBit = 0; // New page is not dirty
            newPage->fixCount = 1; // Pin the page
            newPage->refNum = 0; // Reset reference number
            rearIndex++; // Increment rear index
            hit++; // Increment hit count

            // Update hit numbers based on the strategy
            if (bm->strategy == RS_LRU)
                newPage->hitNum = hit;
            else if (bm->strategy == RS_CLOCK)
                newPage->hitNum = 1;

            page->pageNum = pageNum; // Update the page handle
            page->data = newPage->data; // Set the page data

            // Apply the appropriate page replacement strategy
            switch (bm->strategy) {
                case RS_FIFO:
                    FIFO(bm, newPage);
                    break;

                case RS_LRU:
                    LRU(bm, newPage);
                    break;

                case RS_CLOCK:
                    CLOCK(bm, newPage);
                    break;

                case RS_LRU_K:
                    LRUK(bm, newPage);
                    break;

                default:
                    printf("\nAlgorithm Not Implemented\n");
                    break;
            }
        }
        return RC_OK; // Return success
    }
}

extern PageNumber *getFrameContents(BM_BufferPool *const bm) {
    PageNumber *frameContents = malloc(sizeof(PageNumber) * bufferSize); // Allocate memory for frame contents
    PageFrame *pageFrame = (PageFrame *) bm->mgmtData; // Get the page frames from management data
    int i = 0;

    // Fill frame contents array
    while (i < bufferSize) {
        frameContents[i] = (pageFrame[i].pageNum != NO_PAGE) ? pageFrame[i].pageNum : NO_PAGE; // Copy page numbers
        i++;
    }
    return frameContents; // Return the array of frame contents
}

extern bool *getDirtyFlags(BM_BufferPool *const bm) {
    bool *dirtyFlags = malloc(sizeof(bool) * bufferSize); // Allocate memory for dirty flags
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i;

    // Fill dirty flags array
    for (i = 0; i < bufferSize; i++) {
        dirtyFlags[i] = (pageFrame[i].dirtyBit == 1) ? true : false; // Check if the page is dirty
    }
    return dirtyFlags; // Return the array of dirty flags
}

extern int *getFixCounts(BM_BufferPool *const bm) {
    int *fixCounts = malloc(sizeof(int) * bufferSize); // Allocate memory for fix counts
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData; // Get the page frames from management data
    int i = 0;

    // Fill fix counts array
    while (i < bufferSize) {
        fixCounts[i] = (pageFrame[i].fixCount != -1) ? pageFrame[i].fixCount : 0; // Copy fix counts
        i++;
    }
    return fixCounts; // Return the array of fix counts
}

extern int getNumReadIO(BM_BufferPool *const bm) {
    return (rearIndex + 1); // Tracks how many pages have been read into the buffer
}

extern int getNumWriteIO(BM_BufferPool *const bm) {
    return writeCount; // Tracks how many pages have been written back to disk
}