#include "buffer_mgr_stat.h"
#include "buffer_mgr.h"

#include <stdio.h>
#include <stdlib.h>

// local functions
static void printStrat (BM_BufferPool *const bm); // Function to print the strategy type

// external functions
void 
printPoolContent (BM_BufferPool *const bm) {
  PageNumber *frameContent; // Array to hold page numbers in the buffer pool
  bool *dirty;              // Array to hold dirty flags for pages
  int *fixCount;           // Array to hold the fix count for pages
  int i;

  // Retrieve frame contents, dirty flags, and fix counts from the buffer pool
  frameContent = getFrameContents(bm);
  dirty = getDirtyFlags(bm);
  fixCount = getFixCounts(bm);

  printf("{");
  printStrat(bm); // Print the strategy used
  printf(" %i}: ", bm->numPages); // Print the number of pages in the pool

  // Print each page's information: page number, dirty flag, and fix count
  for (i = 0; i < bm->numPages; i++)
      printf("%s[%i%s%i]", ((i == 0) ? "" : ","), frameContent[i], (dirty[i] ? "x": " "), fixCount[i]);
  printf("\n");
}

char *
sprintPoolContent (BM_BufferPool *const bm) {
  PageNumber *frameContent; // Array to hold page numbers in the buffer pool
  bool *dirty;              // Array to hold dirty flags for pages
  int *fixCount;           // Array to hold the fix count for pages
  int i;
  char *message;           // String to hold formatted output
  int pos = 0;

  // Allocate memory for the output message
  message = (char *) malloc(256 + (22 * bm->numPages));
  frameContent = getFrameContents(bm);
  dirty = getDirtyFlags(bm);
  fixCount = getFixCounts(bm);

  // Build the message with page information
  for (i = 0; i < bm->numPages; i++)
    pos += sprintf(message + pos, "%s[%i%s%i]", ((i == 0) ? "" : ","), frameContent[i], (dirty[i] ? "x": " "), fixCount[i]);
  
  return message; // Return the formatted message
}

void
printPageContent (BM_PageHandle *const page) {
  int i;

  printf("[Page %i]\n", page->pageNum); // Print the current page number

  // Print the content of the page in hexadecimal format
  for (i = 1; i <= PAGE_SIZE; i++)
    printf("%02X%s%s", page->data[i], (i % 8) ? "" : " ", (i % 64) ? "" : "\n"); 
}

char *
sprintPageContent (BM_PageHandle *const page) {
  int i;
  char *message; // String to hold formatted output
  int pos = 0;

  // Allocate memory for the output message
  message = (char *) malloc(30 + (2 * PAGE_SIZE) + (PAGE_SIZE % 64) + (PAGE_SIZE % 8));
  pos += sprintf(message + pos, "[Page %i]\n", page->pageNum); // Print the current page number

  // Build the message with page content
  for (i = 1; i <= PAGE_SIZE; i++)
    pos += sprintf(message + pos, "%02X%s%s", page->data[i], (i % 8) ? "" : " ", (i % 64) ? "" : "\n"); 
  
  return message; // Return the formatted message
}

void
printStrat (BM_BufferPool *const bm) {
  // Print the page replacement strategy used by the buffer pool
  switch (bm->strategy) {
    case RS_FIFO:
      printf("FIFO"); // First In First Out
      break;
    case RS_LRU:
      printf("LRU"); // Least Recently Used
      break;
    case RS_CLOCK:
      printf("CLOCK"); // CLOCK replacement strategy
      break;
    case RS_LRU_K:
      printf("LRU-K"); // Least Recently Used - K
      break;
    default:
      printf("%i", bm->strategy); // Print the strategy number if unrecognized
      break;
  }
}
