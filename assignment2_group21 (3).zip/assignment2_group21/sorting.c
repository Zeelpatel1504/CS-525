#include "sorting.h"

// Function to swap two integers.
void swap(int* a, int* b) {
    int temp = *a; // Store the value of the first integer in a temporary variable.
    *a = *b;       // Assign the value of the second integer to the first.
    *b = temp;    // Assign the value of the temporary variable (original first integer) to the second.
}

// Function to partition the array for Quick Sort.
// It selects a pivot element and rearranges the array elements such that
// all elements less than or equal to the pivot are on the left,
// and all elements greater than the pivot are on the right.
// Parameters:
//   arr[]: The array to be partitioned.
//   low: The starting index of the segment to be partitioned.
//   high: The ending index of the segment to be partitioned.
// Returns: The index of the pivot after partitioning.
int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // Choose the last element as the pivot.
    int i = low - 1;       // Pointer for the smaller element.

    // Iterate through the array segment.
    for (int j = low; j < high; j++) {
        // If the current element is smaller than or equal to the pivot.
        if (arr[j] <= pivot) {
            i++; // Increment the smaller element pointer.
            swap(&arr[i], &arr[j]); // Swap the found element with the element at the smaller pointer.
        }
    }
    swap(&arr[i + 1], &arr[high]); // Swap the pivot element with the element at the (i + 1) position.
    return i + 1; // Return the index of the pivot element.
}

// Function to perform Quick Sort on an array.
// Parameters:
//   arr[]: The array to be sorted.
//   low: The starting index of the segment to be sorted.
//   high: The ending index of the segment to be sorted.
void quickSort(int arr[], int low, int high) {
    if (low < high) { // Base condition for recursion.
        int pi = partition(arr, low, high); // Partition the array and get the pivot index.
        quickSort(arr, low, pi - 1); // Recursively sort the left segment.
        quickSort(arr, pi + 1, high); // Recursively sort the right segment.
    }
}