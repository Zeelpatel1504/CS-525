#ifndef SORTING_H
#define SORTING_H

// Function to perform the Quick Sort algorithm on an array.
// Parameters:
//   arr[]: The array to be sorted.
//   low: The starting index of the array segment to be sorted.
//   high: The ending index of the array segment to be sorted.
void quickSort(int arr[], int low, int high);

// Helper function to swap two integers.
// Parameters:
//   a: Pointer to the first integer to swap.
//   b: Pointer to the second integer to swap.
void swap(int* a, int* b);

#endif