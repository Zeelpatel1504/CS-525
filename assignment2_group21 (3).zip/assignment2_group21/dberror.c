#include "dberror.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char *RC_message; // Global variable to hold the error message

/* 
 * Function to print a descriptive error message to the standard output
 * If an error message is available in RC_message, it prints the error code
 * along with the message. Otherwise, it prints only the error code.
 */
void printError(RC error)
{
    if (RC_message != NULL)
        printf("EC (%i), \"%s\"\n", error, RC_message); // Print error code and message if available
    else
        printf("EC (%i)\n", error); // Print only the error code if no message is set
}

/*
 * Function to return the error message as a string
 * If an error message is available in RC_message, it appends the error code
 * and the message into a newly allocated string. Otherwise, it returns just
 * the error code.
 */
char *errorMessage(RC error)
{
    char *message;

    if (RC_message != NULL)
    {
        // Allocate memory for the message including the error code and the error message
        message = (char *)malloc(strlen(RC_message) + 30);
        sprintf(message, "EC (%i), \"%s\"\n", error, RC_message); // Format the error code and message
    }
    else
    {
        // Allocate memory for the message to hold only the error code
        message = (char *)malloc(30);
        sprintf(message, "EC (%i)\n", error); // Format the error code
    }

    return message; // Return the generated message
}