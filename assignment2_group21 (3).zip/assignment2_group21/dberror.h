#ifndef DBERROR_H
#define DBERROR_H

#include <stdio.h>

/* Module-wide constants */
#define PAGE_SIZE 4096

/* Return code definitions */
typedef int RC;

/* General return codes */
#define RC_OK 0
#define RC_FILE_NOT_FOUND 1
#define RC_FILE_HANDLE_NOT_INIT 2
#define RC_WRITE_FAILED 3
#define RC_READ_NON_EXISTING_PAGE 4
#define RC_READ_FAILED 5
#define RC_DELETE_FAILED 6
#define RC_PIN_FAILED 7       // Pin page failed
#define RC_ERROR 8            // General error code
#define RC_UNKNOWN_STRATEGY 9 // Added unknown strategy error code

/* Buffer Pool (BP) error codes */
#define RC_MEMORY_ALLOCATION_FAILED 100    // Error when memory allocation fails
#define RC_PINNED_PAGES_IN_BUFFER 101      // Error when buffer pool still has pinned pages
#define RC_REPLACEMENT_STRATEGY_NOT_IMPLEMENTED 102  // Replacement strategy not implemented
#define RC_BP_SHUTDOWN_ERROR 103
#define RC_BP_FORCE_FLUSH_FAILED 104
#define RC_BP_PIN_ERROR 105
#define RC_BP_UNPIN_ERROR 106
#define RC_BP_MARK_DIRTY_ERROR 107
#define RC_BP_FORCE_ERROR 108
#define RC_BP_INVALID_PAGE_NUM 109

/* Return codes for Record Manager (RM) operations */
#define RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE 200
#define RC_RM_EXPR_RESULT_IS_NOT_BOOLEAN 201
#define RC_RM_BOOLEAN_EXPR_ARG_IS_NOT_BOOLEAN 202
#define RC_RM_NO_MORE_TUPLES 203
#define RC_RM_NO_PRINT_FOR_DATATYPE 204
#define RC_RM_UNKNOWN_DATATYPE 205

/* Return codes for Index Manager (IM) operations */
#define RC_IM_KEY_NOT_FOUND 300
#define RC_IM_KEY_ALREADY_EXISTS 301
#define RC_IM_N_TOO_LARGE 302  // Fixed typo
#define RC_IM_NO_MORE_ENTRIES 303

/* Holder for error messages */
extern char *RC_message;

/* Print a message to standard out describing the error */
extern void printError(RC error);
extern char *errorMessage(RC error);

/* Throw an error with a message */
#define THROW(rc, message)    \
    do {                      \
        RC_message = message; \
        return rc;           \
    } while (0)

/* Check the return code and exit if it is an error */
#define CHECK(code)                                                         \
    do {                                                                    \
        RC rc_internal = (code);                                            \
        if (rc_internal != RC_OK) {                                         \
            char *message = errorMessage(rc_internal);                      \
            printf("[%s-L%i-%s] ERROR: Operation returned error: %s\n",     \
                   __FILE__, __LINE__, __TIME__, message);                  \
            free(message);                                                  \
            exit(1);                                                        \
        }                                                                   \
    } while (0)

#endif
