#ifndef BUFFER_MGR_STAT_H
#define BUFFER_MGR_STAT_H

#include "buffer_mgr.h"

// Function declarations for buffer manager statistics and debugging

// Prints the content of the entire buffer pool, including page numbers, dirty flags, and fix counts
void printPoolContent (BM_BufferPool *const bm);

// Prints the content of a specific page in a human-readable format
void printPageContent (BM_PageHandle *const page);

// Returns a string representation of the buffer pool content for logging or display purposes
char *sprintPoolContent (BM_BufferPool *const bm);

// Returns a string representation of a specific page's content for logging or display purposes
char *sprintPageContent (BM_PageHandle *const page);

#endif // BUFFER_MGR_STAT_H
