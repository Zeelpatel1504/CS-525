#ifndef STORAGE_MGR_H
#define STORAGE_MGR_H

#include "dberror.h"

/************************************************************
 *                    Definitions                           *
 ************************************************************/
#define PAGE_SIZE 4096  // Define the size of a page (4KB is typical)

typedef char* SM_PageHandle;  // Represents the memory where pages are stored

/************************************************************
 *                    File Handle Structure                 *
 ************************************************************/
typedef struct SM_FileHandle {
    char *fileName;       // Name of the file
    int totalNumPages;    // Total number of pages in the file
    int curPagePos;       // Current position in the file (page number)
    void *mgmtInfo;       // Management info (used for internal file handling)
} SM_FileHandle;

/************************************************************
 *                    Interface Declarations                *
 ************************************************************/
/* Manipulating page files */
extern void initStorageManager (void);
extern RC createPageFile (char *fileName);
extern RC openPageFile (char *fileName, SM_FileHandle *fHandle);
extern RC closePageFile (SM_FileHandle *fHandle);
extern RC destroyPageFile (char *fileName);

/* Reading blocks from disk */
extern RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);
extern int getBlockPos (SM_FileHandle *fHandle);
extern RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);

/* Writing blocks to a page file */
extern RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC appendEmptyBlock (SM_FileHandle *fHandle);
extern RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle);

#endif // STORAGE_MGR_H


