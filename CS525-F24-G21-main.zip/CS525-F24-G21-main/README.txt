# Creating the README.txt file content

CS525 Assignment 1 - Storage Manager
=====================================

This repository is maintained by Group 21 for CS525 - Advanced Database Organization.

Group Members:
- Patel Zeel - A20556822
- Rajodiya Ruchika - A20562246
- Patel Dhruval - A20549909

Each group member has contributed equally to complete Assignment #1.

Tools and Environment
=====================
IDE:
- Visual Studio Code (optional for Windows and Linux users)

Compiler:
- GCC Compiler for Windows (via MinGW Installation)

How to Run Assignment #1 on Windows
===================================
Prerequisites:
1. Install MinGW:
   - Download and install MinGW from SourceForge.
   - During installation, ensure that the `gcc`, `g++`, and `make` components are selected.
   - Add the MinGW `bin` directory (e.g., `C:\\MinGW\\bin`) to your system's PATH environment variable.

Option 1: Using Visual Studio Code
----------------------------------
1. Open the Project:
   - Open Visual Studio Code.
   - Click on `File > Open Folder` and select the project folder.

2. Configure Build:
   - Open the integrated terminal in VS Code (`Ctrl + `).

3. Compile and Run:
   - Navigate to the project directory (if needed):  
     cd path/to/project

   - Compile the project using the Makefile:  
     mingw32-make

   - Run the executable:  
     ./main.exe

Option 2: Using Command Prompt
------------------------------
1. Open Command Prompt:
   - Press `Win + R`, type `cmd`, and press Enter.

2. Navigate to Project Directory:
   Use the `cd` command to navigate to the project folder:
   cd path/to/project

3. Compile and Run:
   - Compile the project using the Makefile:  
     mingw32-make

   - Run the executable:  
     ./main.exe


Project Structure
=================
Files Used:
- `storage_mgr.h` - Header file containing declarations for the storage manager functions.
- `storage_mgr.c` - Implements functions to manage storage, such as creating, opening, reading, and writing page files.
- `dberror.h` - Header file defining error codes and related functions.
- `dberror.c` - Contains implementations of functions to handle errors in the storage manager.
- `test_assign1_1.c` - Test file to verify the correctness of the storage manager's functions.
- `test_helper.h` - Contains helper functions for testing.
- `Makefile` - Used to build the project using `mingw32-make` (or any `make` compatible system).
- `README.txt` - Instructions for compiling and running the project.

Functions Implemented
=====================
storage_mgr.c Functions:
- `initStorageManager()`: Initializes the storage manager.
- `createPageFile()`: Creates a new page file.
- `openPageFile()`: Opens an existing page file.
- `closePageFile()`: Closes the opened page file and frees associated resources.
- `destroyPageFile()`: Deletes the specified page file from the disk.
- `readBlock()`: Reads a block from the page file into memory.
- `getBlockPos()`: Returns the current position of the block in the page file.
- `readFirstBlock()`: Reads the first block from the page file.
- `readPreviousBlock()`: Reads the block preceding the current block.
- `readCurrentBlock()`: Reads the current block from the page file.
- `readNextBlock()`: Reads the block following the current block.
- `readLastBlock()`: Reads the last block from the page file.
- `writeBlock()`: Writes a block to the specified page in the page file.
- `writeCurrentBlock()`: Writes the current block to the page file.
- `appendEmptyBlock()`: Appends an empty block to the end of the page file.
- `ensureCapacity()`: Ensures that the page file has the specified number of pages. If not, it appends empty blocks.

dberror.c Functions:
- `printError()`: Prints error messages based on error codes.
- `errorMessage()`: Returns a string representation of the error code.

Test Cases
==========
The test cases are located in `test_assign1_1.c`. These are the major tests performed:

1. `initStorageManager()`: Tests the initialization of the storage manager to ensure proper setup.
2. `testCreateOpenClose()`: Verifies the functionality to create, open, and close page files.
3. `testSinglePageContent()`: Ensures that page files can be created, opened, read, and destroyed successfully.

How to Compile and Run
======================
To compile the project:
mingw32-make

To run the project:
./main.exe
"""

