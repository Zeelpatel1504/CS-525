#include <stdio.h>
#include <stdlib.h>
#include "storage_mgr.h"
#include "dberror.h"

// Test function for File Management
void testFileManagement() {
    printf("Running File Management tests...\n");

    SM_FileHandle fh;
    RC rc;

    // Initialize the storage manager
    initStorageManager();
    printf("Storage Manager initialized.\n");

    // Create a new page file
    printf("Creating a new page file...\n");
    rc = createPageFile("testfile.bin");
    if (rc == RC_OK) {
        printf("Page file created successfully.\n");
    } else {
        printf("Failed to create page file. Error code: %d\n", rc);
        return;
    }

    // Open the page file
    printf("Opening the page file...\n");
    rc = openPageFile("testfile.bin", &fh);
    if (rc == RC_OK) {
        printf("Page file opened successfully.\n");
    } else {
        printf("Failed to open page file. Error code: %d\n", rc);
        return;
    }

    // Close the page file
    printf("Closing the page file...\n");
    rc = closePageFile(&fh);
    if (rc == RC_OK) {
        printf("Page file closed successfully.\n");
    } else {
        printf("Failed to close page file. Error code: %d\n", rc);
    }

    // Destroy the page file
    printf("Destroying the page file...\n");
    rc = destroyPageFile("testfile.bin");
    if (rc == RC_OK) {
        printf("Page file destroyed successfully.\n");
    } else {
        printf("Failed to destroy page file. Error code: %d\n", rc);
    }

    printf("File Management tests completed.\n");
}

// Test function for Reading and Writing Blocks
void testBlockOperations() {
    printf("Running Block Operations tests...\n");

    SM_FileHandle fh;
    SM_PageHandle ph = (SM_PageHandle) malloc(PAGE_SIZE); // Allocate memory for a page
    RC rc;

    // Create and open a new page file
    rc = createPageFile("testfile.bin");
    openPageFile("testfile.bin", &fh);

    // Fill block 0 with 'A' and block 1 with 'B' for testing
    for (int i = 0; i < PAGE_SIZE; i++) {
        ph[i] = 'A';
    }
    writeBlock(0, &fh, ph); // Write block 0

    appendEmptyBlock(&fh); // Append a new block
    for (int i = 0; i < PAGE_SIZE; i++) {
        ph[i] = 'B';
    }
    writeBlock(1, &fh, ph); // Write block 1

    // Read block 0 and display content
    printf("Reading block 0...\n");
    rc = readBlock(0, &fh, ph);
    if (rc == RC_OK) {
        printf("Block 0 content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Get current block position
    printf("Current block position: %d\n", getBlockPos(&fh));

    // Read First Block
    printf("Reading first block...\n");
    rc = readFirstBlock(&fh, ph);
    if (rc == RC_OK) {
        printf("First block content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Read Last Block
    printf("Reading last block...\n");
    rc = readLastBlock(&fh, ph);
    if (rc == RC_OK) {
        printf("Last block content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Read Previous Block
    printf("Reading previous block...\n");
    rc = readPreviousBlock(&fh, ph);
    if (rc == RC_OK) {
        printf("Previous block content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Read Next Block
    printf("Reading next block...\n");
    rc = readNextBlock(&fh, ph);
    if (rc == RC_OK) {
        printf("Next block content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Read Current Block
    printf("Reading current block...\n");
    rc = readCurrentBlock(&fh, ph);
    if (rc == RC_OK) {
        printf("Current block content (first 20 characters): ");
        for (int i = 0; i < 20; i++) {
            printf("%c", ph[i]);
        }
        printf("\n");
    }

    // Append an empty block
    printf("Appending an empty block...\n");
    rc = appendEmptyBlock(&fh);
    if (rc == RC_OK) {
        printf("Empty block appended successfully.\n");
    }

    // Ensure Capacity of 5 Pages
    printf("Ensuring capacity of 5 pages...\n");
    rc = ensureCapacity(5, &fh);
    if (rc == RC_OK) {
        printf("Capacity ensured. Total number of pages: %d\n", fh.totalNumPages);
    }

    // Clean up
    closePageFile(&fh);
    destroyPageFile("testfile.bin");
    free(ph);

    printf("Block Operations tests completed.\n");
}

// Main function to run all tests
int main() {
    printf("Starting all tests...\n");

    initStorageManager(); // Initialize storage manager
    testFileManagement(); // Run file management tests
    testBlockOperations(); // Run block operations tests

    printf("All tests completed.\n");
    return 0;
}
