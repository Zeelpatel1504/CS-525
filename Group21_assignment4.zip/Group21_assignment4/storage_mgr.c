#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<math.h>
#include <stdbool.h>

#include "storage_mgr.h"

FILE *pageFile;
int pgread;
bool isInitialized=false;

/*
 * Function: initStorageManager
 * ------------------------------
 * Parameters: No parameter is required for this function
 * It will initialize the storage manager
 * ------------------------------
 * Returns: Function doesn't return anything, it will just print the RC message.
 */
void initStorageManager (void) {
    isInitialized=true;
    printf("<-- Initializing the Storage Manager -->") ;
    pageFile = NULL;
}

/*
 * Function: validateStorageMgrInitStatus
 * ------------------------------
 * Parameters:This function takes the input as filename
 * Check whether pagefile is exist or not
 * ------------------------------
 * Returns: return o or 1 based on file existence
 */
int validateStorageMgrInitStatus ()
{
    int checkInit = (isInitialized == true);
    if(checkInit)
        return RC_OK;
    else
        return -1;
}

/*
 * Function: fileExists
 * ------------------------------
 * Parameters:This function takes the input as filename
 * Check whether pagefile is exist or not
 * ------------------------------
 * Returns: return true or false based on file existence
 */
bool fileExists(const char *filename)
{
    int x=(access(filename, F_OK) != -1 );
    if(x) {
        return true;
    } else {
        return false;
    }
}

/*
 * Function:  createPageFile
 * ------------------------------
 * Parameters:This function takes the input as filename and  check whether pagefile is exist or not
 * if exists then return RC_FILE_ALREADY_EXIST
 * if not then create pagefile with file operations
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC createPageFile (char *filename) {
    printf("<---In page File Creation Function--->");
    if(fileExists(filename))
    {
        return RC_FILE_ALREADY_EXIST;   // tells file already exsist if the file is there
    }
    FILE *fname=fopen(filename,"w+");
    if(fname==NULL) {
        return RC_FILE_HANDLE_NOT_INIT;    // if fname is null then file handle will not be initialized
    }
    char empty[PAGE_SIZE];        // Create a string of size PAGE_SIZE
    memset(empty,'\0',PAGE_SIZE); // Set the string value to null bytes
    fwrite(empty,1,PAGE_SIZE,fname);  // Write the empty string to file
    fclose(fname);
    return RC_OK;
}

/*
 * Function:  openPageFile
 * ------------------------------
 * Parameters:This function takes the input as filename and checks if the file is null and if null
 * then returns file not found else returns okay
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC openPageFile (char *fileName, SM_FileHandle *fHandle) {
    // Opening file stream in read mode. 'r' mode creates an empty file for reading only.
    pageFile = fopen(fileName, "r");

    // Checking if file was successfully opened.
    if(pageFile == NULL) {
        return RC_FILE_NOT_FOUND;
    } else {
        // Updating file handle's filename and set the current position to the start of the page.
        fHandle->fileName = fileName;
        fHandle->curPagePos = 0;

        struct stat fileInfo;
        if(fstat(fileno(pageFile), &fileInfo) < 0)
            return RC_ERROR;
        fHandle->totalNumPages = fileInfo.st_size/ PAGE_SIZE;

        // Closing file stream so that all the buffers are flushed.
        fclose(pageFile);
        return RC_OK;
    }
}

/*
 * Function:  closePageFile
 * ------------------------------
 * Parameters:This function is used to close the file if file is found then close it if not then return file not found

 * ------------------------------
 * Returns: RC message based on code definitions
 */
extern RC closePageFile (SM_FileHandle *fHandle)
{
    printf("<----closing the file---->");
    FILE *F=fHandle->mgmtInfo; // Read file pointer from file handle
    F=NULL;
    return RC_OK;
}


/*
 * Function:  destroyPageFile
 * ------------------------------
 * Parameters:This function takes the input as filename and  check whether pagefile is exist or not
 * if exists then destroy pagefile
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC destroyPageFile (char *filename) {
    printf("destroying page file");
    if(validateStorageMgrInitStatus() !=RC_OK)
        return RC_STRG_MGR_NOT_INIT;

    if(!fileExists(filename))
        return RC_FILE_NOT_FOUND;

    if(remove(filename)==0)
        return RC_OK;

    return RC_FAILED_FILE_DELETE;
}

/*
 * Function: readBlock
 * ------------------------------
 * Parameters:This function takes the input as page number, file and page handle
 * Checks whether all the input parameters have correct values i.e. file and page handle should not be null also the page number should be in the range.
 * ------------------------------
 * Returns: return RC_OK based on the if conditions else will return the respective messages for else part.
 */
RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    // Checking if the pageNumber parameter is less than Total number of pages and less than 0, then return respective error code
    if (pageNum > fHandle->totalNumPages || pageNum < 0)
        return RC_READ_NON_EXISTING_PAGE;

    // Opening file stream in read mode. 'r' mode opens file for reading only.
    pageFile = fopen(fHandle->fileName, "r");

    // Checking if file was successfully opened.
    if(pageFile == NULL)
        return RC_FILE_NOT_FOUND;

    // Setting the cursor(pointer) position of the file stream. Position is calculated by Page Number x Page Size
    // And the seek is success if fseek() return 0
    int isSeekSuccess = fseek(pageFile, (pageNum * PAGE_SIZE), SEEK_SET);
    if(isSeekSuccess == 0) {
        // We're reading the content and storing it in the location pointed out by memPage.
        if(fread(memPage, sizeof(char), PAGE_SIZE, pageFile) < PAGE_SIZE)
            return RC_ERROR;
    } else {
        return RC_READ_NON_EXISTING_PAGE;
    }

    // Setting the current page position to the cursor(pointer) position of the file stream
    fHandle->curPagePos = ftell(pageFile);

    // Closing file stream so that all the buffers are flushed.
    fclose(pageFile);

    return RC_OK;
}

/*
* Function: getBlockPos
* ------------------------------
* Parameters:This function is used to check the block position and returns current page position
* ------------------------------
* Returns: RC message based on code definitions
*/

int getBlockPos (SM_FileHandle *fHandle)
{
    //check if the file contains related data
    printf("getting block pos");
    if(fHandle ==NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else{
        if((fopen(fHandle->fileName,"r+"))==NULL)
        {
            return RC_FILE_NOT_FOUND;
        }
        else{
            printf("%d",fHandle->curPagePos);
            return fHandle->curPagePos;

        }
    }
}

/*
 * Function:  readFirstBlock
 * ------------------------------
 * Parameters:This function takes the input as filehandle and pagehandle
 * This function reuses the process of readblock
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage) {
    printf("readFirstBlock ");

    if ((!validateStorageMgrInitStatus()) == RC_OK)
        return RC_STRG_MGR_NOT_INIT;

    if (!fileExists(fHandle->fileName))
        return RC_FILE_NOT_FOUND;

    return readBlock(0, fHandle, memPage);

}


/*
Function - ReadPreviousBlock
--------------------------------------------------------
Parameters are filehandle and pagehandle

Purpose - It reads the previous block from where the current page position is , so we
pass the (currentPos-1) to the read block so that it reads the block before the currentPos
It then reuses the readblock function

*--------------------------------------------- *
It calls the readBlock method and then from there the RC message will be returned
*/
RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage) {
    printf("<--Reading Previous Block-->\n");
    if(fHandle==NULL) {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    return readBlock(fHandle->curPagePos-1,fHandle,memPage);
}

/*
 * Function:  readCurrentBlock
 * ------------------------------
 * Parameters:Here we get the current page's position from the filehandle
 * ------------------------------
 * Returns:
 *1.RC_CURENT_BLOCK_READ: is the message for successful reading of the current block
 */
RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage) {
    printf("11: readCurrentBlock ");
    pgread=getBlockPos(fHandle);
    // Display a message indicating the current block is being read.
    printf("Reading current block at position %d\n", pgread);
    readBlock (pgread,fHandle, memPage);//this function reads the last block into memorypage
    return RC_OK;
}

/*
 * Function:  readNextBlock
 * ------------------------------
 * Parameters:This function takes the input as filehandle and pagehandle
 * This function reuses the process of readblock
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    printf("12: readNextBlock ");

    if((!validateStorageMgrInitStatus()) == RC_OK)
        return RC_STRG_MGR_NOT_INIT;

    if(!fileExists(fHandle->fileName))
        return RC_FILE_NOT_FOUND;

    return(readBlock ((fHandle->curPagePos+1), fHandle, memPage));
}

/*
 * Function:  readLastBlock
 * ------------------------------
 * Parameters:Here we are calculating the page number of the last block by subtracting 'one' from the total number of page
 * ------------------------------
 * Returns: RC message based on code definitions
 */
 RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage){
    pgread=(fHandle->totalNumPages)-1;
    printf("Reading last block at position %d\n", pgread);
    readBlock (pgread,fHandle, memPage);
    return RC_OK;
}

/*
 Function - writeBlock
 *-----------------------------------------------*
 parameters - We are passing the filehandle , the page num where we want to make a write operation
 and the memPage which is the pageHandle
 *-----------------------------------------------*
 Purpose - The functions writes the data in the page to the file if there are any error
 it returns the appropriate error message
 *----------------------------------------------*
 ** Return the RC meassages as defined in the header file
*/
RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
    // Checking if the pageNumber parameter is less than Total number of pages and less than 0, then return respective error code
    if (pageNum > fHandle->totalNumPages || pageNum < 0)
        return RC_WRITE_FAILED;

    // Opening file stream in read & write mode. 'r+' mode opens the file for both reading and writing.
    pageFile = fopen(fHandle->fileName, "r+");

    // Checking if file was successfully opened.
    if(pageFile == NULL)
        return RC_FILE_NOT_FOUND;

    int startPosition = pageNum * PAGE_SIZE;

    if(pageNum == 0) {
        //Writing data to non-first page
        fseek(pageFile, startPosition, SEEK_SET);
        int i;
        for(i = 0; i < PAGE_SIZE; i++)
        {
            // Checking if it is end of file. If yes then append an enpty block.
            if(feof(pageFile)) // check file is ending in between writing
                appendEmptyBlock(fHandle);
            // Writing a character from memPage to page file
            fputc(memPage[i], pageFile);
        }

        // Setting the current page position to the cursor(pointer) position of the file stream
        fHandle->curPagePos = ftell(pageFile);

        // Closing file stream so that all the buffers are flushed.
        fclose(pageFile);
    } else {
        // Writing data to the first page.
        fHandle->curPagePos = startPosition;
        fclose(pageFile);
        writeCurrentBlock(fHandle, memPage);
    }
    return RC_OK;
}

/*
 * Function: writeCurrentBlock
 * ------------------------------
 * Parameters:This function takes the input as file and page handle
 * Checks whether both the input parameters are proper
 * ------------------------------
 * Returns: return rc messages based on the conditions.
 */
RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage) {
    // Opening file stream in read & write mode. 'r+' mode opens the file for both reading and writing.
    pageFile = fopen(fHandle->fileName, "r+");

    // Checking if file was successfully opened.
    if(pageFile == NULL)
        return RC_FILE_NOT_FOUND;

    // Appending an empty block to make some space for the new content.
    appendEmptyBlock(fHandle);

    // Initiliazing file pointer
    fseek(pageFile, fHandle->curPagePos, SEEK_SET);

    // Writing memPage contents to the file.
    fwrite(memPage, sizeof(char), strlen(memPage), pageFile);

    // Setting the current page position to the cursor(pointer) position of the file stream
    fHandle->curPagePos = ftell(pageFile);

    // Closing file stream so that all the buffers are flushed.
    fclose(pageFile);
    return RC_OK;
}


/*
 * Function:  appendEmptyBlock
 * ------------------------------
 * Parameters:This function takes the input as filehandle
 * This function reuses the process of writeblock to append empty block
 * ------------------------------
 * Returns: RC message based on code definitions
 */
RC appendEmptyBlock (SM_FileHandle *fHandle) {
    // Creating an empty page of size PAGE_SIZE bytes
    SM_PageHandle emptyBlock = (SM_PageHandle)calloc(PAGE_SIZE, sizeof(char));

    // Moving the cursor (pointer) position to the begining of the file stream.
    // And the seek is success if fseek() return 0
    int isSeekSuccess = fseek(pageFile, 0, SEEK_END);

    if( isSeekSuccess == 0 ) {
        // Writing an empty page to the file
        fwrite(emptyBlock, sizeof(char), PAGE_SIZE, pageFile);
    } else {
        free(emptyBlock);
        return RC_WRITE_FAILED;
    }

    // De-allocating the memory previously allocated to 'emptyPage'.
    // This is optional but always better to do for proper memory management.
    free(emptyBlock);

    // Incrementing the total number of pages since we added an empty black.
    fHandle->totalNumPages++;
    return RC_OK;
}

/*
 * Function:  ensureCapacity
 * ------------------------------
 * Parameters:Here we check whether number of pages are equal to what we wanted or are they greater than that.
 * ------------------------------
 * Returns:
 *1.RC_ENOUGH_PAGES_SUCCESS: is the message where it is ensured that we have achieved the enough pages successfully
 */
RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle) {
    if(fHandle->totalNumPages >= numberOfPages)
    {
        return RC_OK;
    }
    else
    {
        int i, numPages_toAdd;

        numPages_toAdd = numberOfPages - fHandle->totalNumPages;

        printf("Adding %d pages to meet the desired capacity.\n", numPages_toAdd);
        for(i=RC_OK; i < numPages_toAdd; i++)
        {
            appendEmptyBlock(fHandle);
        }
        return RC_OK;
    }
}