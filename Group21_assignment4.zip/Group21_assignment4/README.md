Here's the README content in text format with the added note about the output files being in respective folders:

---

# Group21 Assignment 4: B+-Tree Based Database Management System

### Team Members

- _Zeel Patel_ - A-20556822
- _Dhruval Patel_ - A-20549909
- _Rajodiya Ruchika_ - A-20562246

---

## Project Overview

This project implements a simplified database management system that leverages B+-Tree indexing for efficient data handling. Key functionalities include buffer management, record management, and thorough testing to ensure robust performance. Sample output files are provided in respective folders to showcase the expected results for each test case, enabling easy verification of correct functionality.

---

## Project Structure

### Source Files

- _Core Implementations_: Implements the main functionalities of the database management system.
  - buffer_mgr.c: Manages the buffer pool, handling page requests and memory management using page replacement strategies.
  - record_mgr.c: Implements CRUD (Create, Read, Update, Delete) operations for database records.
  - btree_mgr.c: Manages B+-Tree indexing, optimizing data access and retrieval.

### Header Files

- _Modular Declarations_: Contains declarations, structures, and constants to support the modular functionality.
  - btree_helper.h: Helper functions specific to B+-Tree operations.
  - btree_mgr.h: Header for B+-Tree management functions.
  - buffer_mgr.h: Header for buffer manager functions.
  - buffer_mgr_stat.h: Provides statistics functions for the buffer manager.
  - dberror.h: Defines error codes used throughout the project.
  - dt.h: Defines data types and structures used across modules.
  - expr.h: Header for expression evaluation functions.
  - record_mgr.h: Header for record management functions.
  - storage_mgr.h: Header for storage management functions.
  - tables.h: Defines tables, schemas, and metadata.

### Helper Files

- _Support for Auxiliary Operations_: Provides additional support for serialization, data manipulation, and error management.
  - btree_implement.c: Additional B+-Tree operations, including insertion, deletion, and search.
  - expr.c: Functions for evaluating expressions within database operations.
  - rm_serializer.c: Serializes and deserializes records for storage and retrieval.
  - dberror.c: Manages error reporting across modules.

### Build and Configuration Files

- _Build Scripts_:
  - Makefile: Script for building the project using make.
  - CMakeLists.txt: Configuration file for setting up cross-platform builds with CMake.

### Test Files

- _Unit Tests_: Contains unit tests to verify system components and functionality.
  - test_assign4_1.c: Tests buffer and B+-Tree basic functionalities, focusing on page handling and indexing.
  - test_assign4_2.c: Custom test cases for B+-Tree, validating advanced operations like node splitting and underflow handling.
  - test_expr.c: Tests expression evaluation functions used in database operations.
  - test_helper.h: Provides helper functions to support testing.

### Executables

- _Precompiled Test Executables_:
  - test_assign4_1.exe: Runs tests for buffer and B+-Tree basic operations.
  - test_assign4_2.exe: Runs custom test cases for B+-Tree.

---

## Core Requirements and Corresponding Functions

### B+-Tree Initialization and Management Functions

- _Requirement_: Initialize and shut down the index manager, manage B-tree creation and deletion.
- _Functions_:
  - initIndexManager: Initializes the index manager.
  - shutdownIndexManager: Shuts down the index manager, freeing up resources.
  - createBtree: Creates a new B-tree with a specified idxId and order.
  - openBtree, closeBtree: Opens and closes the B-tree.
  - deleteBtree: Deletes the B-tree and removes the page file.
- _Status_: These functions meet the requirements for initialization, creation, opening, closing, and deletion of the B+-tree index. They also ensure resource management by utilizing the buffer manager and page file.

### B+-Tree Node Operations

- _Requirement_: Insert and find keys, handle leaf and non-leaf splits, and maintain record pointers for integer keys (DT_INT).
- _Functions_:
  - insertKey: Inserts a key into the B+-tree, handling leaf and non-leaf splits.
  - deleteKey: Deletes a key from the B+-tree.
  - findKey: Finds a specific key and returns the RID of the corresponding record.
- _Status_: These functions handle insertion, deletion, and search operations, adhering to the requirements for managing keys and splits. Specifics for leaf and non-leaf splits, underflow, and overflow are implemented within insertKey and deleteKey functions.

### Index Statistics and Information

- _Requirement_: Retrieve the number of nodes, number of entries, and key type of the B+-tree.
- _Functions_:
  - getNumNodes: Returns the number of nodes in the B+-tree.
  - getNumEntries: Returns the number of entries in the B+-tree.
  - getKeyType: Returns the key type of the B+-tree (currently DT_INT).
- _Status_: These functions meet the requirement for retrieving B-tree statistics.

### Index Scanning

- _Requirement_: Support scanning through all entries of the B-tree in sorted order.
- _Functions_:
  - openTreeScan: Initializes a scan on the B-tree.
  - nextEntry: Retrieves the next entry during the scan.
  - closeTreeScan: Closes the scan on the B-tree.
- _Status_: These functions meet the requirement for scanning the B+-tree in sorted order, with nextEntry providing entries in ascending order of keys.

### Debug and Test Functions

- _Requirement_: Support debugging and testing with a function to print the B+-tree structure.
- _Function_:
  - printTree: Generates a string representation of the B+-tree in a depth-first pre-order format.
- _Status_: This function meets the requirement for debugging by providing a formatted string representation of the B+-tree.

---

## Additional Requirements and Constraints

### Leaf and Non-Leaf Splits

Specific split rules include:

- _Leaf Split_: If the number of keys (n) is even, the left node receives the extra key.
- _Non-Leaf Split_: For odd n, the middle key is added to the parent, and the right node contains one more key.
- _Implementation_: These rules are handled within the insertKey function and its helper functions.

### Leaf Underflow

Underflow handling is managed by borrowing from a sibling, prioritizing the left sibling if available. This logic is incorporated within deleteKey or its associated helper functions.

### Optional Extensions

- _Multiple Data Types_: Functions like findKey, insertKey, and deleteKey can be extended to handle additional data types.
- _Record Manager Integration_: Functions like createBtree can be modified to allow a key attribute for tables created with the record manager.
- _Pointer Swizzling_: Extend the buffer manager to support swizzling, modifying functions like findKey for efficient access.

---

## Setup and Build Instructions

### Prerequisites

- _C Compiler_: Required for compilation (e.g., GCC or Clang).
- _CMake_: Version 3.0 or higher.
- _MinGW_: Necessary for compiling on Windows.

### Using PowerShell (Windows)

1. _Remove Previous Builds_:
   powershell
   Remove-Item -Recurse -Force build

2. _Create and Enter Build Directory_:
   powershell
   mkdir build
   cd build

3. _Run CMake_:
   powershell
   cmake -G "MinGW Makefiles" ..

4. _Compile_:
   powershell
   mingw32-make

5. _Run Tests_:
   - Basic operations:
     powershell
     .\test_assign4_1.exe
   - Advanced B+-Tree operations:
     powershell
     .\test_assign4_2.exe

### Using Makefile (Linux/MacOS)

1. _Navigate to Project Root_:
   bash
   cd assign4

2. _Clean Previous Builds_:
   bash
   make clean

3. _Build the Project_:
   bash
   make

4. _Run Tests_:
   - Basic test:
     bash
     make run_test1
   - Additional test cases:
     bash
     make test2
     make run_test2

---

## Running Tests

### Custom Test Cases in test_assign4_2.c

This file includes advanced B+-Tree operations, such as node splits and underflow handling.

### Output Reference

Sample output files are provided in respective folders to validate the functionality of each component. Use these files to compare against your test runs to confirm correct behavior.

---

## Optional Extensions

- _Record Manager Integration_: Integrate B+-Tree indexing with record management for key-based searches.
- _Multiple Entries per Key_: Extend the B+-Tree to handle multiple RIDs for each key using linked pages for overflow.

---

B+ Tree Implementation

This project implements a B+ Tree structure, showcasing ordered insertions, node splits, and key promotions. Below is a detailed walkthrough of the insertion process and the resulting tree structure at each step.

Inserting key 5 with value 33.00
Inserted into new leaf node.
Inserting key 15 with value 21.00
Inserted into existing leaf node. Leaf has 2 pairs.
Leaf node is full. Splitting...
Split leaf node. New leaf starts with key 15.
Created new root with promoted key 15.
Inserting key 25 with value 31.00
Inserted into existing leaf node. Leaf has 2 pairs.
Leaf node is full. Splitting...
Split leaf node. New leaf starts with key 25.
Inserted promoted key 25 into parent.
Inserting key 35 with value 41.00
Inserted into existing leaf node. Leaf has 2 pairs.
Leaf node is full. Splitting...
Split leaf node. New leaf starts with key 35.
Inserted promoted key 35 into parent.

nitial Insertion Process (Tree Structure at Each Step)
Insert Key 5 with Value 33.00

New leaf node created:
csharp
Copy code
[5]
Insert Key 15 with Value 21.00

Inserted into the existing leaf node, making two keys:
csharp
Copy code
[5, 15]
Insert Key 25 with Value 31.00

Leaf node is full and splits.
Split Leaf Nodes:
Left Leaf: [5]
Right Leaf: [15, 25]
Created new root with promoted key 15:
css
Copy code
   [15]
   /    \
[5]    [15, 25]
Insert Key 35 with Value 41.00

Inserted into the right leaf node [15, 25].
Leaf node is full and splits.
Split Leaf Nodes:
Left Leaf: [15]
Right Leaf: [25, 35]
Inserted promoted key 25 into the parent:
css
Copy code
      [15, 25]
      /    |     \
   [5]   [15]  [25, 35]
Summary of Tree Structure After All Insertions
After the full sequence of insertions and splits, the B+ Tree structure is:

Root Node: [15, 25]
First Child: Leaf Node [5]
Second Child: Leaf Node [15]
Third Child: Leaf Node [25, 35]
Tree Visualization
css
Copy code
         [15, 25]
         /    |     \
      [5]   [15]  [25, 35]
Each level:

The Root Node holds the keys [15, 25], directing to leaf nodes where values are stored.
The Leaf Nodes contain the actual data in ordered keys, ensuring that each node points to its right sibling, following the B+ Tree structure.
Explanation
This tree structure demonstrates:

Ordered Insertions and Splitting: Keys are organized to maintain order across leaf nodes.
Balanced Structure: The root node adjusts by promoting keys, keeping the tree balanced.
Efficiency in Search: Each split maintains the B+ Tree properties, ensuring efficient searches.
This presentation provides a clear, step-by-step transformation of the tree structure as keys are inserted, helping to visualize how B+ Tree nodes are organized and balanced during operations.






