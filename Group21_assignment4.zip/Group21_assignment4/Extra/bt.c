#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

typedef struct DictionaryPair {
    int key;
    double value;
} DictionaryPair;

typedef struct Node {
    struct InternalNode *parent;
    bool isLeaf;
} Node;

typedef struct LeafNode {
    Node node;
    DictionaryPair *dictionary;
    int numPairs;
    int maxNumPairs;
    struct LeafNode *leftSibling;
    struct LeafNode *rightSibling;
} LeafNode;

typedef struct InternalNode {
    Node node;
    int *keys;
    int degree;
    int maxDegree;
    struct InternalNode *leftSibling;
    struct InternalNode *rightSibling;
    Node **childPointers;
} InternalNode;

typedef struct BPlusTree {
    int m;
    InternalNode *root;
    LeafNode *firstLeaf;
} BPlusTree;

// Function prototypes
LeafNode* findLeafNode(BPlusTree *tree, int key);
void insert(BPlusTree *tree, int key, double value);
double search(BPlusTree *tree, int key);
int binarySearch(DictionaryPair *dps, int numPairs, int key);
int getMidpoint(BPlusTree *tree);
void splitLeafNode(BPlusTree *tree, LeafNode *leaf);
void splitInternalNode(BPlusTree *tree, InternalNode *internal);
void insertIntoParent(BPlusTree *tree, Node *left, int key, Node *right);
InternalNode* createInternalNode(int m);
LeafNode* createLeafNode(int m);
BPlusTree* createBPlusTree(int m);
void freeBPlusTree(BPlusTree *tree);
void freeLeafNode(LeafNode *leaf);
void freeInternalNode(InternalNode *internal);
void sortDictionary(DictionaryPair *dps, int numPairs);
void printLeafKeys(BPlusTree *tree);

// Create a new B+ tree
BPlusTree* createBPlusTree(int m) {
    BPlusTree *tree = (BPlusTree *)malloc(sizeof(BPlusTree));
    tree->m = m;
    tree->root = NULL;
    tree->firstLeaf = NULL;
    return tree;
}

// Free a B+ tree and all allocated nodes
void freeBPlusTree(BPlusTree *tree) {
    if (tree->root) {
        if (tree->root->node.isLeaf) {
            freeLeafNode((LeafNode*)tree->root);
        } else {
            freeInternalNode(tree->root);
        }
    }
    free(tree);
}

// Free a leaf node and its data
void freeLeafNode(LeafNode *leaf) {
    free(leaf->dictionary);
    free(leaf);
}

// Free an internal node and its children
void freeInternalNode(InternalNode *internal) {
    for (int i = 0; i < internal->degree; i++) {
        if (internal->childPointers[i]->isLeaf) {
            freeLeafNode((LeafNode*)internal->childPointers[i]);
        } else {
            freeInternalNode((InternalNode*)internal->childPointers[i]);
        }
    }
    free(internal->keys);
    free(internal->childPointers);
    free(internal);
}

// Sort dictionary by key after insertion
void sortDictionary(DictionaryPair *dps, int numPairs) {
    for (int i = 0; i < numPairs - 1; i++) {
        for (int j = i + 1; j < numPairs; j++) {
            if (dps[i].key > dps[j].key) {
                DictionaryPair temp = dps[i];
                dps[i] = dps[j];
                dps[j] = temp;
            }
        }
    }
}

// Search for a specific key in the B+ tree
double search(BPlusTree *tree, int key) {
    if (tree->firstLeaf == NULL) {
        return -1;
    }
    LeafNode *leaf = findLeafNode(tree, key);
    int index = binarySearch(leaf->dictionary, leaf->numPairs, key);
    return (index >= 0) ? leaf->dictionary[index].value : -1;
}

// Binary search within a leaf node's dictionary
int binarySearch(DictionaryPair *dps, int numPairs, int key) {
    int low = 0;
    int high = numPairs - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (dps[mid].key == key) {
            return mid;
        }
        if (dps[mid].key < key) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    return -1;
}

// Find the appropriate leaf node for a given key
LeafNode* findLeafNode(BPlusTree *tree, int key) {
    if (tree->root == NULL) {
        return tree->firstLeaf;
    }
    InternalNode *currentNode = tree->root;
    while (!currentNode->node.isLeaf) {
        int i;
        for (i = 0; i < currentNode->degree - 1; i++) {
            if (key < currentNode->keys[i]) {
                break;
            }
        }
        currentNode = (InternalNode *)currentNode->childPointers[i];
    }
    return (LeafNode *)currentNode;
}

// Insert a key-value pair into the B+ tree
void insert(BPlusTree *tree, int key, double value) {
    printf("Inserting key %d with value %.2f\n", key, value);
    if (tree->firstLeaf == NULL) {
        LeafNode *leaf = createLeafNode(tree->m);
        leaf->dictionary[0] = (DictionaryPair){key, value};
        leaf->numPairs = 1;
        tree->firstLeaf = leaf;
        printf("Inserted into new leaf node.\n");
        return;
    }
    LeafNode *leaf = findLeafNode(tree, key);
    leaf->dictionary[leaf->numPairs++] = (DictionaryPair){key, value};
    sortDictionary(leaf->dictionary, leaf->numPairs);

    printf("Inserted into existing leaf node. Leaf has %d pairs.\n", leaf->numPairs);

    if (leaf->numPairs == leaf->maxNumPairs) {
        printf("Leaf node is full. Splitting...\n");
        splitLeafNode(tree, leaf);
    }
}

// Split a leaf node and insert into parent
void splitLeafNode(BPlusTree *tree, LeafNode *leaf) {
    int midpoint = getMidpoint(tree);
    LeafNode *newLeaf = createLeafNode(tree->m);

    for (int i = midpoint; i < leaf->numPairs; i++) {
        newLeaf->dictionary[i - midpoint] = leaf->dictionary[i];
        newLeaf->numPairs++;
    }
    leaf->numPairs = midpoint;

    // Link siblings
    newLeaf->rightSibling = leaf->rightSibling;
    if (newLeaf->rightSibling) {
        newLeaf->rightSibling->leftSibling = newLeaf;
    }
    leaf->rightSibling = newLeaf;
    newLeaf->leftSibling = leaf;

    printf("Split leaf node. New leaf starts with key %d.\n", newLeaf->dictionary[0].key);

    insertIntoParent(tree, (Node *)leaf, newLeaf->dictionary[0].key, (Node *)newLeaf);
}

// Insert into the parent node after splitting
void insertIntoParent(BPlusTree *tree, Node *left, int key, Node *right) {
    InternalNode *parent = left->parent;
    if (parent == NULL) {
        InternalNode *newRoot = createInternalNode(tree->m);
        newRoot->keys[0] = key;
        newRoot->childPointers[0] = left;
        newRoot->childPointers[1] = right;
        newRoot->degree = 2;
        tree->root = newRoot;
        left->parent = newRoot;
        right->parent = newRoot;
        printf("Created new root with promoted key %d.\n", key);
        return;
    }

    // Insert key in parent node
    int i;
    for (i = parent->degree - 1; i >= 0 && parent->keys[i] > key; i--) {
        parent->keys[i + 1] = parent->keys[i];
        parent->childPointers[i + 2] = parent->childPointers[i + 1];
    }
    parent->keys[i + 1] = key;
    parent->childPointers[i + 2] = right;
    parent->degree++;
    right->parent = parent;

    printf("Inserted promoted key %d into parent.\n", key);

    // Check if the parent node needs to be split
    if (parent->degree > tree->m) {
        splitInternalNode(tree, parent);
    }
}

// Split an internal node and adjust the tree structure
void splitInternalNode(BPlusTree *tree, InternalNode *internal) {
    int midpoint = getMidpoint(tree);
    InternalNode *newInternal = createInternalNode(tree->m);
    newInternal->degree = internal->degree - midpoint - 1;

    for (int i = 0; i < newInternal->degree; i++) {
        newInternal->keys[i] = internal->keys[midpoint + 1 + i];
        newInternal->childPointers[i] = internal->childPointers[midpoint + 1 + i];
        ((Node *)newInternal->childPointers[i])->parent = newInternal;
    }
    newInternal->childPointers[newInternal->degree] = internal->childPointers[internal->degree];
    ((Node *)newInternal->childPointers[newInternal->degree])->parent = newInternal;

    int promoteKey = internal->keys[midpoint];

    internal->degree = midpoint;

    printf("Split internal node. Promoting key %d to parent.\n", promoteKey);

    insertIntoParent(tree, (Node *)internal, promoteKey, (Node *)newInternal);
}

// Get the midpoint for splitting nodes
int getMidpoint(BPlusTree *tree) {
    return (int)ceil((tree->m + 1) / 2.0) - 1;
}

// Create a new internal node
InternalNode* createInternalNode(int m) {
    InternalNode *node = (InternalNode *)malloc(sizeof(InternalNode));
    node->node.isLeaf = false;
    node->keys = (int *)malloc(sizeof(int) * m);
    node->childPointers = (Node **)malloc(sizeof(Node *) * (m + 1));
    node->degree = 0;
    node->maxDegree = m;
    node->leftSibling = NULL;
    node->rightSibling = NULL;
    return node;
}

// Create a new leaf node
LeafNode* createLeafNode(int m) {
    LeafNode *node = (LeafNode *)malloc(sizeof(LeafNode));
    node->node.isLeaf = true;
    node->dictionary = (DictionaryPair *)malloc(sizeof(DictionaryPair) * m);
    node->numPairs = 0;
    node->maxNumPairs = m - 1;
    node->leftSibling = NULL;
    node->rightSibling = NULL;
    return node;
}

// Print all keys in the leaf nodes to verify correct linking
void printLeafKeys(BPlusTree *tree) {
    LeafNode *current = tree->firstLeaf;
    while (current != NULL) {
        printf("Leaf keys: ");
        for (int i = 0; i < current->numPairs; i++) {
            printf("%d ", current->dictionary[i].key);
        }
        printf("\n");
        current = current->rightSibling;
    }
}

int main() {
    BPlusTree *bpt = createBPlusTree(3);

    insert(bpt, 5, 33.0);
    insert(bpt, 15, 21.0);
    insert(bpt, 25, 31.0);
    insert(bpt, 35, 41.0);
    insert(bpt, 45, 10.0);
    insert(bpt, 55, 15.0);
    insert(bpt, 65, 22.0);
    insert(bpt, 75, 37.0);

    printLeafKeys(bpt);  // Debugging: print all keys in the leaf nodes

    printf("Search 15: %.2f\n", search(bpt, 15));
    printf("Search 45: %.2f\n", search(bpt, 45));
    printf("Search 65: %.2f\n", search(bpt, 65));
    printf("Search 100 (Not Found): %.2f\n", search(bpt, 100));
    printf("Search 85 after inserting: %.2f\n", search(bpt, 85));

    freeBPlusTree(bpt);
    return 0;
}