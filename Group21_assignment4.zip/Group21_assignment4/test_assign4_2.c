#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include "buffer_mgr.h"      // for initBufferManager
#include "storage_mgr.h"     // for file-related functions
#include "btree_mgr.h"       // for B-tree management functions

#include "dberror.h"
#include "expr.h"
#include "btree_mgr.h"
#include "tables.h"
#include "test_helper.h"

#define ASSERT_EQUALS_RID(_l, _r, message) \
  do { \
    ASSERT_TRUE((_l).page == (_r).page && (_l).slot == (_r).slot, message); \
  } while(0)

#define VERBOSE_OUTPUT 0

char *testName = "B-tree Test Suite";
// Swizzling Data Structure
typedef struct SwizzleEntry {
    int pagenum;           // Page number of the swizzled node
    void *memoryPointer;   // Memory pointer to the node in memory
} SwizzleEntry;

static SwizzleEntry *swizzleTable;
static int swizzleTableSize = 0;

void initSwizzleTable(int size) {
    swizzleTable = (SwizzleEntry *)malloc(size * sizeof(SwizzleEntry));
    swizzleTableSize = size;
}

void addSwizzleEntry(int pagenum, void *memoryPointer) {
    for (int i = 0; i < swizzleTableSize; i++) {
        if (swizzleTable[i].pagenum == -1) {
            swizzleTable[i].pagenum = pagenum;
            swizzleTable[i].memoryPointer = memoryPointer;
            break;
        }
    }
}

void onPageEviction(int pagenum) {
    for (int i = 0; i < swizzleTableSize; i++) {
        if (swizzleTable[i].pagenum == pagenum) {
            swizzleTable[i].memoryPointer = NULL;
            swizzleTable[i].pagenum = -1;
            break;
        }
    }
}

// Multiple Entries Insertion Function
RC insertMultipleEntries(BTreeHandle *tree, Value *key, RID rid) {
    EntryList *entryList;
    RC rc = findAllEntries(tree, key, &entryList);

    if (rc == RC_IM_KEY_NOT_FOUND) {
        entryList = (EntryList *)malloc(sizeof(EntryList));
        entryList->head = entryList->tail = NULL;
    }

    RIDNode *newRidNode = (RIDNode *)malloc(sizeof(RIDNode));
    newRidNode->rid = rid;
    newRidNode->next = NULL;

    if (entryList->tail) {
        entryList->tail->next = newRidNode;
        entryList->tail = newRidNode;
    } else {
        entryList->head = entryList->tail = newRidNode;
    }

    return insertKey(tree, key, rid);
}
// Test methods
static void testInsertAndFind(void);
static void testDelete(void);
static void testIndexScan(void);
static void testMultipleEntries(void);

static Value **createValues(char **stringVals, int size);
static void freeValues(Value **vals, int size);
static int *createPermutation(int size);

int main(void) {
    srand(0);
    testInsertAndFind();
    testDelete();
    testIndexScan();
    testMultipleEntries();
    return 0;
}
// ************************************************************ 
void testInsertAndFind(void) {
    RID insert[] = { {1,1}, {2,3}, {1,2}, {3,5}, {4,4}, {3,2} };
    int numInserts = 6;
    Value **keys;
    char *stringKeys[] = { "i1", "i11", "i13", "i17", "i23", "i52" };
    testName = "B-tree Insert and Find Test";
    int i, testint;
    BTreeHandle *tree = NULL;

    printf("*** %s ***\n", testName);
    printf("-------------------------------\n");

    keys = createValues(stringKeys, numInserts);

    // Init
    printf("\n>>> Initializing Index Manager...\n");
    TEST_CHECK(initIndexManager(NULL));
    if (createBtree("testidx", DT_INT, 2) != RC_OK) {
        printf("Failed to create B-tree.\n");
        return;
    }
    TEST_CHECK(openBtree(&tree, "testidx"));
    printf("[Index Manager Initialized Successfully]\n");

    // Insert keys
    printf("\n>> Inserting Keys\n");
    for (i = 0; i < numInserts; i++) {
        printf("   - Inserting key %s at RID(%d, %d)\n", stringKeys[i], insert[i].page, insert[i].slot);
        TEST_CHECK(insertKey(tree, keys[i], insert[i]));
    }

    // Check index stats
    printf("\n>> Summary of Inserted Entries\n");
    TEST_CHECK(getNumNodes(tree, &testint));
    printf("   Number of nodes in B-tree: %d\n", testint);
    TEST_CHECK(getNumEntries(tree, &testint));
    printf("   Number of entries in B-tree: %d\n", testint);

    // Search for keys
    printf("\n>> Searching for Keys\n");
    for (i = 0; i < numInserts; i++) {
        RID rid;
        TEST_CHECK(findKey(tree, keys[i], &rid));
        printf("   - Found key %s at RID(%d, %d)\n", stringKeys[i], rid.page, rid.slot);
    }

    // Cleanup
    TEST_CHECK(closeBtree(tree));
    TEST_CHECK(deleteBtree("testidx"));
    TEST_CHECK(shutdownIndexManager());
    freeValues(keys, numInserts);

    printf("\n[Insert and Find Test Completed]\n");
    printf("==============================\n\n");
}
// ************************************************************ 
void testDelete(void) {
  RID insert[] = { {1,1}, {2,3}, {1,2}, {3,5}, {4,4}, {3,2} };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = { "i1", "i11", "i13", "i17", "i23", "i52" };
  testName = "B-tree Deletion Test";
  int i, iter;
  BTreeHandle *tree = NULL;
  int numDeletes = 3;
  bool *deletes = (bool *) malloc(numInserts * sizeof(bool));

  printf("*** %s ***\n", testName);
  printf("-------------------------------\n");

  keys = createValues(stringKeys, numInserts);

  // Init
  printf("\n>>> Initializing Index Manager for Deletion Test...\n");
  TEST_CHECK(initIndexManager(NULL));
  printf("[Index Manager Initialized Successfully]\n");

  // Create test B-tree and randomly remove entries
  for (iter = 0; iter < 5; iter++) {
    printf("\n>> Iteration %d\n", iter + 1);

    // Set up random deletion pattern
    for (i = 0; i < numInserts; i++) deletes[i] = false;
    for (i = 0; i < numDeletes; i++) deletes[rand() % numInserts] = true;

    // Init B-tree
    TEST_CHECK(createBtree("testidx", DT_INT, 2));
    TEST_CHECK(openBtree(&tree, "testidx"));

    // Insert keys
    printf(">> Inserting Keys\n");
    for (i = 0; i < numInserts; i++) {
      TEST_CHECK(insertKey(tree, keys[i], insert[i]));
    }

    // Delete keys
    printf("\n>> Deleting Keys\n");
    for (i = 0; i < numInserts; i++) {
      if (deletes[i]) {
        printf("   - Deleting key %s\n", stringKeys[i]);
        TEST_CHECK(deleteKey(tree, keys[i]));
      }
    }

    // Verify deletions
    printf("\n>> Verifying Deletions and Presence\n");
    for (i = 0; i < numInserts; i++) {
      RID rid;
      Value *key = keys[i];

      if (deletes[i]) {
        int rc = findKey(tree, key, &rid);
        printf("   - Verifying deletion of key %s: %s\n", stringKeys[i], rc == RC_IM_KEY_NOT_FOUND ? "OK" : "Failed");
      } else {
        TEST_CHECK(findKey(tree, key, &rid));
        printf("   - Verifying presence of key %s: OK\n", stringKeys[i]);
      }
    }

    // Cleanup
    TEST_CHECK(closeBtree(tree));
    TEST_CHECK(deleteBtree("testidx"));
  }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);
  free(deletes);

  printf("\n[Deletion Test Completed]\n");
  printf("==============================\n\n");
}

// ************************************************************ 
void testIndexScan(void) {
  RID insert[] = { {1,1}, {2,3}, {1,2}, {3,5}, {4,4}, {3,2} };
  int numInserts = 6;
  Value **keys;
  char *stringKeys[] = { "i1", "i11", "i13", "i17", "i23", "i52" };
  
  testName = "B-tree Index Scan Test";
  int i, iter, rc;
  BTreeHandle *tree = NULL;
  BT_ScanHandle *sc = NULL;
  RID rid;

  printf("*** %s ***\n", testName);
  printf("-------------------------------\n");

  keys = createValues(stringKeys, numInserts);

  // Init
  printf("\n>>> Initializing Index Manager for Index Scan Test...\n");
  TEST_CHECK(initIndexManager(NULL));
  printf("[Index Manager Initialized Successfully]\n");

  for (iter = 0; iter < 5; iter++) {
    int *permute = createPermutation(numInserts);
    printf("\n>> Iteration %d\n", iter + 1);

    // Create B-tree
    TEST_CHECK(createBtree("testidx", DT_INT, 2));
    TEST_CHECK(openBtree(&tree, "testidx"));

    // Insert keys
    printf(">> Inserting Keys\n");
    for (i = 0; i < numInserts; i++) {
      TEST_CHECK(insertKey(tree, keys[permute[i]], insert[permute[i]]));
    }

    // Execute scan
    printf("\n>> Scanning Entries\n");
    openTreeScan(tree, &sc);
    int scanCount = 0;
    i = 0;
    while ((rc = nextEntry(sc, &rid)) == RC_OK) {
      RID expRid = insert[i++];
      if (VERBOSE_OUTPUT) printf("Scanned RID(%d, %d)\n", rid.page, rid.slot);
      scanCount++;
    }
    
    printf("   - Iteration %d: Scanned %d entries successfully.\n", iter + 1, scanCount);

    closeTreeScan(sc);

    // Cleanup
    TEST_CHECK(closeBtree(tree));
    TEST_CHECK(deleteBtree("testidx"));
    free(permute);
  }

  TEST_CHECK(shutdownIndexManager());
  freeValues(keys, numInserts);

  printf("\n[Index Scan Test Completed]\n");
  printf("==============================\n\n");
}


void testMultipleEntries(void) {
    printf("*** B-tree Multiple Entries Test ***\n");
    printf("-------------------------------\n");

    BTreeHandle *tree;
    initIndexManager(NULL);
    createBtree("testidx_multiple", DT_INT, 3);
    openBtree(&tree, "testidx_multiple");

    Value *key1 = stringToValue("i50");
    Value *key2 = stringToValue("i100");

    insertMultipleEntries(tree, key1, (RID){1, 1});
    insertMultipleEntries(tree, key1, (RID){1, 2});
    insertMultipleEntries(tree, key1, (RID){1, 3});

    EntryList *list;
    findAllEntries(tree, key1, &list);

    printf("Entries for key i50:\n");
    for (RIDNode *node = list->head; node != NULL; node = node->next) {
        printf("   - RID(%d, %d)\n", node->rid.page, node->rid.slot);
    }

    printf("[Multiple Entries Test Completed]\n");
    free(key1);
    free(key2);
    closeBtree(tree);
    shutdownIndexManager();
}

// Utility functions for creating and freeing values
int *createPermutation(int size) {
    int *result = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++) result[i] = i;

    for (int i = 0; i < 100; i++) {
        int l = rand() % size;
        int r = rand() % size;
        int temp = result[l];
        result[l] = result[r];
        result[r] = temp;
    }

    return result;
}

Value **createValues(char **stringVals, int size) {
    Value **result = (Value **)malloc(sizeof(Value *) * size);
    for (int i = 0; i < size; i++) {
        result[i] = stringToValue(stringVals[i]);
    }
    return result;
}

void freeValues(Value **vals, int size) {
    while (--size >= 0) {
        free(vals[size]);
    }
    free(vals);
}