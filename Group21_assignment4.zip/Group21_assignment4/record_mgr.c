#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"

/*
 * DataStructure Name: RecordManager
 * ------------------------------
 * This is a custom data structure which is used for record manager.
 * rowCount provied the total number of rows in a table
 * rcrdID -> this is used as for record id .
 * bufferPoolManager -> for buffer pool manager
 * BMpgHndl -> buffer pool manager pahge handle for accessing the page files.
 * check -> condition for record scanning
 * ------------------------------
 */
typedef struct RecordManager
{
    BM_PageHandle BMpgHndl;
    BM_BufferPool bufferPoolManager;
    RID rcrdID;
    Expr *check;
    int rowCount;
    int freePg;
    int totalScanCount;
} RecordManager;

RecordManager *rcrdMngr;

const int MAXIMUM_NO_OF_PAGES = 100;
const int SIZE_OF_THE_ATTRIBUTE = 15;

/**** User Defined Function ****/

/*
 * Function: findFreeSlot
 * ------------------------------
 * Parameters: This function will take data and recordsize as parameters.
 * This function will return a slot which is free withing the specified page.
 * ------------------------------
 * Returns: returns number of pages or -1 based on the condition
 */
int findFreeSlot(char *info, int rcrdSize)
{
    int k = 0;
    int Slots;
    Slots = PAGE_SIZE / rcrdSize;
    while (k < Slots)
    {
        if (info[k * rcrdSize] != '+')
        {
            return k;
        }
        k++;
    }
    return -1;
}

/*
 * Function: initRecordManager
 * ------------------------------
 * Parameters: management data as input will be requied for initialling the record manager
 * This function will initiate the record manager
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC initRecordManager(void *mgmtData)
{
    initStorageManager();
    return RC_OK;
}

/*
 * Function: shutdownRecordManager
 * ------------------------------
 * Parameters:no input parameter needed.
 * This function will shutdown the record manager.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC shutdownRecordManager()
{
    free(rcrdMngr);  // Freeing the record manager.
    return RC_OK;
}

/*
 * Function: createTable
 * ------------------------------
 * Parameters: This function take sinput as name of the table and schema name
 * This function will be creating a table with name as 'name' as specified in parameter in the schema 'schema'.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC createTable(char *name, Schema *schema)
{

    rcrdMngr = (RecordManager *)malloc(sizeof(RecordManager));

    initBufferPool(&rcrdMngr->bufferPoolManager, name, MAXIMUM_NO_OF_PAGES, RS_LRU, NULL); // Initializing bufferpool manager using replacement strategy.

    char info[PAGE_SIZE];
    char *pgHndl = info;
    int result;

    *(int *)pgHndl = 0; // Number of rows
    pgHndl += sizeof(int);
    *(int *)pgHndl = 1;
    pgHndl += sizeof(int);
    *(int *)pgHndl = schema->numAttr; // Number of columns
    pgHndl += sizeof(int);
    *(int *)pgHndl = schema->keySize; // Size of the key
    pgHndl += sizeof(int);

    int k = 0;
    do
    {
        strncpy(pgHndl, schema->attrNames[k], SIZE_OF_THE_ATTRIBUTE);
        pgHndl += SIZE_OF_THE_ATTRIBUTE;
        *(int *)pgHndl = (int)schema->dataTypes[k];
        pgHndl += sizeof(int);
        *(int *)pgHndl = (int)schema->typeLength[k];
        pgHndl += sizeof(int);
        k++;
    } while (k < schema->numAttr);

    SM_FileHandle fileHndl;
    if ((result = createPageFile(name)) != RC_OK)
        return result;
    if ((result = openPageFile(name, &fileHndl)) != RC_OK)
        return result;
    if ((result = writeBlock(0, &fileHndl, info)) != RC_OK)
        return result;
    if ((result = closePageFile(&fileHndl)) != RC_OK)
        return result;
    
    return RC_OK;
}

/*
 * Function: openTable
 * ------------------------------
 * Parameters: This function take sinput as relation and name of the table
 * This function will open the table with name as 'name' as specified in parameter.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC openTable(RM_TableData *rel, char *name)
{
    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, 0); // Pinning the page
    SM_PageHandle pgHndl = (char *)rcrdMngr->BMpgHndl.data;

    rcrdMngr->rowCount = *(int *)pgHndl;
    pgHndl += sizeof(int);

    rcrdMngr->freePg = *(int *)pgHndl;
    pgHndl += sizeof(int);

    int rowCount = *(int *)pgHndl;
    pgHndl += sizeof(int);

    Schema *tableSchema;
    tableSchema = (Schema *)malloc(sizeof(Schema));
    tableSchema->numAttr = rowCount;
    tableSchema->attrNames = (char **)malloc(sizeof(char *) * rowCount);
    tableSchema->dataTypes = (DataType *)malloc(sizeof(DataType) * rowCount);
    tableSchema->typeLength = (int *)malloc(sizeof(int) * rowCount);
    int k = 0;
    while (k < tableSchema->numAttr)
    {
        tableSchema->attrNames[k] = (char *)malloc(SIZE_OF_THE_ATTRIBUTE);
        strncpy(tableSchema->attrNames[k], pgHndl, SIZE_OF_THE_ATTRIBUTE);
        pgHndl += SIZE_OF_THE_ATTRIBUTE;

        tableSchema->dataTypes[k] = *(int *)pgHndl;
        pgHndl += sizeof(int);

        tableSchema->typeLength[k] = *(int *)pgHndl;
        pgHndl += sizeof(int);
        k++;
    }

    rel->mgmtData = rcrdMngr;
    rel->name = name;
    rel->schema = tableSchema;

    unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);
    forcePage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);

    return RC_OK;
}

/*
 * Function: closeTable
 * ------------------------------
 * Parameters: This function takes input as relation
 * This function will close the table with name as 'rel' as specified in parameter.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC closeTable(RM_TableData *rel)
{
    if (rel == NULL || rel->mgmtData == NULL)
    {
        return RC_RM_TABLE_NOT_INITIALIZED;
    }

    RecordManager *rcrdMngr = rel->mgmtData;
    shutdownBufferPool(&rcrdMngr->bufferPoolManager);

   //free(rel);
    free(rel->schema->attrNames);
    free(rel->schema->dataTypes);
    free(rel->schema->keyAttrs);
    free(rel->schema->typeLength);
    free(rel->schema);
    return RC_OK;
}

/*
 * Function: deleteTable
 * ------------------------------
 * Parameters: This function takes input as name of the table.
 * This function will delete the table with name as 'name' as specified in parameter.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC deleteTable(char *name)
{
    destroyPageFile(name);
    return RC_OK;
}

/*
 * Function: getNumTuples
 * ------------------------------
 * Parameters: This function takes input as relation of the table.
 * This function will be returning the number of records in the table 'rel'
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
extern int getNumTuples(RM_TableData *rel)
{
    RecordManager *manager = rel->mgmtData;
    return manager->rowCount;
}

/*
 * Function: insertRecord
 * ------------------------------
 * Parameters: This function requires relation and record as input parameter.
 * This function will create a new record in the relation table and will update the record id of the newly inserted record.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC insertRecord(RM_TableData *rel, Record *record)
{
    RecordManager *rcrdMngr = rel->mgmtData;
    RID *rcrdID = &record->id;
    char *info, *slotPointer;

    int recordSize = getRecordSize(rel->schema);
    rcrdID->page = rcrdMngr->freePg;

    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, rcrdID->page);

    info = rcrdMngr->BMpgHndl.data;
    do
    {
        rcrdID->slot = findFreeSlot(info, recordSize);
        if (rcrdID->slot == -1)
        {
            unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);
            rcrdID->page++;
            pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, rcrdID->page);
            info = rcrdMngr->BMpgHndl.data;
        }
    } while (rcrdID->slot == -1);

    slotPointer = info;

    markDirty(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl); // Marking the modified page as dirty

    slotPointer = slotPointer + (rcrdID->slot * recordSize);
    *slotPointer = '+';

    memcpy(++slotPointer, record->data + 1, recordSize - 1);
    unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);

    rcrdMngr->rowCount++;

    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, 0); // Pinning the page

    return RC_OK;
}

/*
 * Function: deleteRecord
 * ------------------------------
 * Parameters: This function requires relation and record id as input parameter.
 * This function will delete a record of the table 'rel' and record id as 'id'.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC deleteRecord(RM_TableData *rel, RID id)
{

    RecordManager *rcrdMngr = rel->mgmtData;

    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, id.page); // Performing the Pin operation for the page we want to modify

    if (rcrdMngr->BMpgHndl.pageNum != id.page)
    {
        unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);
        return RC_INVALID_PAGE_REQUESTED;
    }

    char *data = rcrdMngr->BMpgHndl.data;
    int recordSize = getRecordSize(rel->schema);

    data = data + (id.slot * recordSize);

    if (*data == '-')
    { // checking if the record is already deleted
        unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);
        return RC_RECORD_ALREADY_DELETED;
    }

    *data = '-';

    markDirty(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl); // Making the page as dirty as it has been modified and then unpinning the page.
    unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);

    return RC_OK;
}

/*
 * Function: updateRecord
 * ------------------------------
 * Parameters: This function requires relation and record id as input parameter.
 * This function will update  a record of the table 'rel' with record id as 'id'.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC updateRecord(RM_TableData *rel, Record *record)
{

    RecordManager *rcrdMngr = rel->mgmtData;

    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, record->id.page); // Pinning the required page.

    char *info;
    int recordSize = getRecordSize(rel->schema);

    info = rcrdMngr->BMpgHndl.data + (record->id.slot * recordSize);
    *info = '+';

    memcpy(++info, record->data + 1, recordSize - 1);
    markDirty(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);

    unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);

    return RC_OK;
}

/*
 * Function: getRecord
 * ------------------------------
 * Parameters: This function requires relation and record as input parameter.
 * This function will fetch a record of the table 'rel' with record id as 'id' and the result will be stored in the location specified in the parameter 'record'.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC getRecord(RM_TableData *rel, RID id, Record *record)
{

    RecordManager *rcrdMngr = rel->mgmtData;

    pinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl, id.page); // Pin the page for the particular record.

    int recordSize = getRecordSize(rel->schema);
    char *dataPointer = rcrdMngr->BMpgHndl.data + (id.slot * recordSize);

    do
    {
        if (*dataPointer != '+')
        {
            unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl);
            return RC_RM_NO_TUPLE_WITH_GIVEN_RID;
        }
        else
        {
            record->id = id;
            char *data = record->data;
            memcpy(++data, dataPointer + 1, recordSize - 1);
        }
    } while (0);

    unpinPage(&rcrdMngr->bufferPoolManager, &rcrdMngr->BMpgHndl); // Unpinning the page after modification.
    return RC_OK;
}

/*
 * Function: startScan
 * ------------------------------
 * Parameters: This function requires relation and scan and a conditon based on which scan operation will be performed.
 * This function will scan all the records based on the condition given in the parameter.
 * Initiallization starts from the 1st page and then scan will start based on the condition
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{
    if (cond == NULL)
    {
        return RC_CONDITION_NOT_FOUND;
    }

    openTable(rel, "ScanTable");

    RecordManager *scanMngr;
    RecordManager *tableMngr;

    scanMngr = (RecordManager *)malloc(sizeof(RecordManager));

    scan->mgmtData = scanMngr;

    scanMngr->rcrdID.page = 1;
    scanMngr->rcrdID.slot = 0;

    scanMngr->totalScanCount = 0;
    scanMngr->check = cond;

    tableMngr = rel->mgmtData;

    tableMngr->rowCount = SIZE_OF_THE_ATTRIBUTE;
    scan->rel = rel;

    //free(scanMngr);
    return RC_OK;
}

/*
 * Function: next
 * ------------------------------
 * Parameters: This function requires scan and record as input parameter
 * This function will scan all the records which are present in table according to the condition.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC next(RM_ScanHandle *scan, Record *record)
{
    RecordManager *scanMngr = scan->mgmtData;
    RecordManager *tableMngr = scan->rel->mgmtData;
    Schema *schema = scan->rel->schema;

    Value *result = (Value *)malloc(sizeof(Value));

    char *info;

    int schemaSize = getRecordSize(schema);
    int totalSlot = PAGE_SIZE / schemaSize;
    int totalScanCount = scanMngr->totalScanCount;

    int recordCount = tableMngr->rowCount;

    if (scanMngr->check == NULL)
    {
        return RC_SCAN_CONDITION_NOT_FOUND;
    }

    if (recordCount == 0) // It will print the respective RC message if there is no count.
        return RC_RM_NO_MORE_TUPLES;

    for (; totalScanCount <= recordCount; totalScanCount++)
    {
        if (totalScanCount > 0)
        {
            scanMngr->rcrdID.slot++;

            if (scanMngr->rcrdID.slot >= totalSlot)
            {
                scanMngr->rcrdID.slot = 0;
                scanMngr->rcrdID.page++;
            }
        }
        else
        {
            scanMngr->rcrdID.page = 1;
            scanMngr->rcrdID.slot = 0;
        }

        pinPage(&tableMngr->bufferPoolManager, &scanMngr->BMpgHndl, scanMngr->rcrdID.page);

        info = scanMngr->BMpgHndl.data;

        info += (scanMngr->rcrdID.slot * schemaSize);

        record->id.page = scanMngr->rcrdID.page;
        record->id.slot = scanMngr->rcrdID.slot;

        char *dataPntr = record->data;

        *dataPntr = '-';

        memcpy(++dataPntr, info + 1, schemaSize - 1);

        scanMngr->totalScanCount++;

        evalExpr(record, schema, scanMngr->check, &result);

        if (result->v.boolV == TRUE)
        {
            unpinPage(&tableMngr->bufferPoolManager, &scanMngr->BMpgHndl);
            return RC_OK;
        }
    }

    unpinPage(&tableMngr->bufferPoolManager, &scanMngr->BMpgHndl);

    scanMngr->rcrdID.page = 1;
    scanMngr->totalScanCount = 0;
    scanMngr->rcrdID.slot = 0;
    free(result);
    return RC_RM_NO_MORE_TUPLES;
}

/*
 * Function: closeScan
 * ------------------------------
 * Parameters: This function requires scan as input parameter
 * This function will stop the scan operation. by unpinning the page and making the total scan count as 0.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC closeScan(RM_ScanHandle *scan)
{
    RecordManager *scanManager = scan->mgmtData;
    RecordManager *rcrdMngr = scan->rel->mgmtData;

    while (scanManager->totalScanCount > 0)
    {

        unpinPage(&rcrdMngr->bufferPoolManager, &scanManager->BMpgHndl);

        scanManager->totalScanCount = 0;
        scanManager->rcrdID.page = 1;
        scanManager->rcrdID.slot = 0;
    }
    free(scan->mgmtData);
    scan->mgmtData = NULL;

    return RC_OK;
}

/*
 * Function: getRecordSize
 * ------------------------------
 * Parameters: This function requires name of the schema as input parameter
 * This function return the record size of the schema specified in the parameter.
 * ------------------------------
 * Returns: returns record size of the schema.
 */
extern int getRecordSize(Schema *schema)
{
    int rcrdSize = 0;

    for (int index = 0; index < schema->numAttr; index++)
    { // Based on the datatypes of the attributes, the opeartion will be performed.
        if (schema->dataTypes[index] == DT_STRING)
        {
            rcrdSize += schema->typeLength[index];
        }
        else if (schema->dataTypes[index] == DT_INT)
        {
            rcrdSize += sizeof(int);
        }
        else if (schema->dataTypes[index] == DT_FLOAT)
        {
            rcrdSize += sizeof(float);
        }
        else if (schema->dataTypes[index] == DT_BOOL)
        {
            rcrdSize += sizeof(bool);
        }
    }
    return ++rcrdSize;
}

/*
 * Function: createSchema
 * ------------------------------
 * Parameters: This function requires number of attribute, datatype and length of the attributes, size and key attribute as input parameters.
 * This function will create a new schema based on the parameters provided.
 * ------------------------------
 * Returns: returns rewly created schema.
 */
extern Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keyAttrs)
{

    Schema *schm = (Schema *)malloc(sizeof(Schema));

    schm->dataTypes = dataTypes;
    schm->typeLength = typeLength;

    schm->numAttr = numAttr;
    schm->attrNames = attrNames;

    schm->keySize = keySize;
    schm->keyAttrs = keyAttrs;

    return schm;
}

/*
 * Function: attrOffset
 * ------------------------------
 * Parameters: This function requires schema, number of attribues.
 * This function is used for setting the offset of attributes based on the data type of the attributes.
 * ------------------------------
 * Returns: returns RC message based onthe conditions.
 */
RC attrOffset(Schema *schema, int attrNum, int *result)
{
    int i;
    *result = 1;

    for (int index = 0; index < attrNum; index++)
    {
        if (schema->dataTypes[index] == DT_STRING)
        {
            *result = *result + schema->typeLength[index];
        }
        else if (schema->dataTypes[index] == DT_INT)
        {
            *result = *result + sizeof(int);
        }
        else if (schema->dataTypes[index] == DT_FLOAT)
        {
            *result = *result + sizeof(float);
        }
        else if (schema->dataTypes[index] == DT_BOOL)
        {
            *result = *result + sizeof(bool);
        }
    }
    return RC_OK;
}

/*
 * Function: freeSchema
 * ------------------------------
 * Parameters: This function requires schema name as parameter.
 * This function will fee up the schema and will deallocate the memory which was allocated to the same schema.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC freeSchema(Schema *schema)
{
    free(schema);
    return RC_OK;
}

/*
 * Function: createRecord
 * ------------------------------
 * Parameters: This function requires schema name i.e. 'schema' as parameter.
 * This function will create a record in the schema specified in the parameter.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC createRecord(Record **record, Schema *schema)
{

    Record *newlyCreatedRecord = (Record *)malloc(sizeof(Record));
    if (!newlyCreatedRecord)
    {
        // free(newlyCreatedRecord);
        return RC_MEMORY_ALLOCATION_ERROR;
    }

    int recordLength = getRecordSize(schema);

    newlyCreatedRecord->data = (char *)malloc(recordLength);
    if (!newlyCreatedRecord->data)
    {
        free(newlyCreatedRecord->data);
        free(newlyCreatedRecord);
        return RC_MEMORY_ALLOCATION_ERROR;
    }

    newlyCreatedRecord->id.page = newlyCreatedRecord->id.slot = -1;
    memset(newlyCreatedRecord->data, '-', recordLength);
    *record = newlyCreatedRecord;

    return RC_OK;
}

/*
 * Function: calculateAttributeOffset
 * ------------------------------
 * Parameters: This function requires schema name i.e. 'schema' , and attribute num as parameter.
 * This function will calculate the offset from initial position to the specified attribute passed as parameter into the result
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC calculateAttributeOffset(Schema *schema, int attrNum, int *result)
{
    int i;
    *result = 1;
    for (i = 0; i < attrNum; i++)
    {
        switch (schema->dataTypes[i])
        {
        case DT_STRING:
            *result = *result + schema->typeLength[i];
            break;
        case DT_INT:
            *result = *result + sizeof(int);
            break;
        case DT_FLOAT:
            *result = *result + sizeof(float);
            break;
        case DT_BOOL:
            *result = *result + sizeof(bool);
            break;
        }
    }
    return RC_OK;
}

/*
 * Function: freeRecord
 * ------------------------------
 * Parameters: This function takes record as parameter
 * This function will free the record from memory.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC freeRecord(Record *record)
{
    if (record != NULL)
    {
        free(record);
        return RC_OK;
    }
    else
    {
        return RC_RECORD_IS_NULL;
    }
}

/*
 * Function: getAttr
 * ------------------------------
 * Parameters: This function takes record, schema name, attribute number and value as parameter
 * This function will get the sprcified attribute from the mentioned schema from the given record.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC getAttr(Record *record, Schema *schema, int attrNum, Value **value)
{
    int offset = 0;
    attrOffset(schema, attrNum, &offset);

    Value *attr = (Value *)malloc(sizeof(Value));

    char *dtPtr = record->data;

    dtPtr = dtPtr + offset;

    schema->dataTypes[attrNum] = (attrNum == 1) ? 1 : schema->dataTypes[attrNum];

    if (schema->dataTypes[attrNum] == DT_STRING)
    {
        int length = schema->typeLength[attrNum];
        attr->v.stringV = (char *)malloc(length + 1);

        strncpy(attr->v.stringV, dtPtr, length);
        attr->v.stringV[length] = '\0';
        attr->dt = DT_STRING;
    }
    else if (schema->dataTypes[attrNum] == DT_INT)
    {
        int value = 0;
        memcpy(&value, dtPtr, sizeof(int));
        attr->v.intV = value;
        attr->dt = DT_INT;
    }
    else if (schema->dataTypes[attrNum] == DT_FLOAT)
    {
        float value;
        memcpy(&value, dtPtr, sizeof(float));
        attr->v.floatV = value;
        attr->dt = DT_FLOAT;
    }
    else if (schema->dataTypes[attrNum] == DT_BOOL)
    {
        bool value;
        memcpy(&value, dtPtr, sizeof(bool));
        attr->v.boolV = value;
        attr->dt = DT_BOOL;
    }
    else
    {
        printf("Serializer not defined for the given datatype. \n");
    }
    *value = attr;

    return RC_OK;
}

/*
 * Function: setAttr
 * ------------------------------
 * Parameters: This function takes record, schema name, attribute number and value as parameter
 * This function will set the specified attribute value in the mentioned schema for the given record.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
RC setAttr(Record *record, Schema *schema, int attrNum, Value *value)
{
    int attrOffsetValue = 0;
    calculateAttributeOffset(schema, attrNum, &attrOffsetValue);

    char *dataPtr = record->data;

    dataPtr = dataPtr + attrOffsetValue;

    if (schema->dataTypes[attrNum] == DT_STRING)
    {
        int strLength = schema->typeLength[attrNum];

        strncpy(dataPtr, value->v.stringV, strLength);
        dataPtr = dataPtr + schema->typeLength[attrNum];
    }
    else if (schema->dataTypes[attrNum] == DT_INT)
    {
        *(int *)dataPtr = value->v.intV;
        dataPtr = dataPtr + sizeof(int);
    }
    else if (schema->dataTypes[attrNum] == DT_FLOAT)
    {
        *(float *)dataPtr = value->v.floatV;
        dataPtr = dataPtr + sizeof(float);
    }
    else if (schema->dataTypes[attrNum] == DT_BOOL)
    {
        *(bool *)dataPtr = value->v.boolV;
        dataPtr = dataPtr + sizeof(bool);
    }
    else
    {
        printf("Serial---> not mentioned in the datatype. \n");
    }

    return RC_OK;
}