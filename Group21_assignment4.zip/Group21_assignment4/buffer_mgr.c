#include<stdio.h>
#include<stdlib.h>
#include "storage_mgr.h"
#include "buffer_mgr.h"


/*
 * Below defined structure shows a page frame in buffer pool manager->Content: It will have the content of the page
 * pageNumber: Unique number given to a page.
 * dirtyContent: It will be used in case if any page is modified by any instance and not writen into the disk.
 * pageInUse: It will be used to check the number of instances using the page.
 * lruPageNum: It will be used to get the leat recently used page.
 */
typedef struct PageFrame
{
    PageNumber pageNumber;
    SM_PageHandle content;
    int lruPageNum;
    int dirtyContent;
    int pageInUse;
    
} PageFrame;

int bufferPoolSize = 0;         //Declaring and initialling buffer pool size where page frames will be stored.
int pageFrameCounter = 0;       //This is a counter which will be maintained after the page frame being added ot buffer pool.
int readFromDisk = 0;           //This indicates the number of pages read from the disk.
int writtenToDisk = 0;          //This indicates the number of writes done on to disk.
int LastPage_Clock = 0;         //This indicates the last page added by the strategy clock algorithm.

// -- Initializes the buffer pool by setting up the page file, the number of pages, and the replacement strategy.
// -- Initially, all page frames should be empty, and the page file should already exist.


 RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                         const int numPages, ReplacementStrategy strategy,
                         void *stratData)
{
    bm->pageFile = (char *)pageFileName;
    bm->numPages = numPages;
    bm->strategy = strategy;
    

    PageFrame *pages = malloc(sizeof(PageFrame) * numPages);             //Memory allocation done for page frame based on the specified number of pages.

    if(pages==NULL)
    {
        return RC_ERROR;
    }

    int x = 0;
    bufferPoolSize = numPages;
    
    do                                                                  //Initiallizing the page frame values for each page
    {
        pages[x].pageNumber = -1;
        pages[x].pageInUse = 0;
        pages[x].content = NULL;
        pages[x].dirtyContent = 0;
        pages[x].lruPageNum = 0;
        x++;
    } while (x < bufferPoolSize);

    bm->mgmtData = pages;
    LastPage_Clock = 0;
    writtenToDisk = 0;

    bm->isInitialized = true;
    
    return RC_OK;
}

/*
 * Function: shutdownBufferPool
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will shutdown the specified buffer pool manager by removing all the pages from the memory.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */

 RC shutdownBufferPool(BM_BufferPool *const bm)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;
    int x = 0;
    int y = 0;
    forceFlushPool(bm);                         //This function will write the modified pages to disk.

    do
    {
        if(pageFrame[x].pageInUse != y)         //if condition means that some of the pages were modified but not written into the disk.
        {
            return RC_PINNED_PAGES_IN_BUFFER;
        }

        x++;

    } while (x < bufferPoolSize);

    free(pageFrame);                    //it will free up the memory.
    
    bm->mgmtData = NULL;
    free(bm);
    return RC_OK;
}

/*
 * Function: forceFlushPool
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will write the dirty pages to disk.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */

 RC forceFlushPool(BM_BufferPool *const bm)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    int x = 0;
    do
    {
        if(pageFrame[x].dirtyContent == 1 && pageFrame[x].pageInUse == 0)
        {   //This will open the page file, write the modified page into disk and will increment the counters.
            SM_FileHandle f;
            openPageFile(bm->pageFile, &f);
            writeBlock(pageFrame[x].pageNumber, &f, pageFrame[x].content);
            pageFrame[x].dirtyContent = 0;
            writtenToDisk++;
        }
        x++;
    } while (x < bufferPoolSize);

    return RC_OK;
}

/*
 * Function: markDirty
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and PageHandle structure.
 * Here modified pages will be marked dirty.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */

 RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    int x = 0;

    //This will be checked for all the pages and will be marked dirty for the page specified in the parameter.
    do
    {
        if(pageFrame[x].pageNumber == page->pageNum)
        {
            pageFrame[x].dirtyContent = 1;
            return RC_OK;
        }
        x++;
    } while (x < bufferPoolSize);
    return RC_ERROR;
}

/*
 * Function: unpinPage
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page from page handle structure.
 * This function will unpin/remove the page from the memory. It will check if the current page is to be unpinned then will decrease the page in use counter.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
 RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    int i=0;
    while(i < bufferPoolSize)
    {
        if(pageFrame[i].pageNumber == page->pageNum)
        {
            pageFrame[i].pageInUse--;
            break;
        }
        i++;
    }
    return RC_OK;
}

/*
 * Function: forcePage
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page from page handle structure.
 * This function will write the modified pages to disk. This function will use the write function which was implemented in storage_mgr.c
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
 RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    int x = 0;
    do
    {
        if(pageFrame[x].pageNumber == page->pageNum)
        {
            SM_FileHandle f;
            openPageFile(bm->pageFile, &f);
            writeBlock(pageFrame[x].pageNumber, &f, pageFrame[x].content);
            pageFrame[x].dirtyContent = 0;          //After writing the page into disk mark the same page as undirty.
            writtenToDisk++;
        }
        x++;
    }while(x<bufferPoolSize);
    return RC_OK;
}

/*
 * Function: FIFO
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page frame.
 * This function is one of the replacement strategy (FIFO First in First Out)
 * ------------------------------
 * Returns: This function doesn't return anything. Used as replacement strategy.
 */
void FIFO(BM_BufferPool *const bm, PageFrame *page)
{
    PageFrame *pageFrame = (PageFrame *) bm->mgmtData;

    int x, readFrontIndex;
    readFrontIndex = readFromDisk % bufferPoolSize;

    do
    {
        if(pageFrame[readFrontIndex].pageInUse == 0)
        {
            if(pageFrame[readFrontIndex].dirtyContent == 1)             //checking if the page frame is dirty page.
            {
                SM_FileHandle f;
                openPageFile(bm->pageFile, &f);
                writeBlock(pageFrame[readFrontIndex].pageNumber, &f, pageFrame[readFrontIndex].content);
                writtenToDisk++;
            }
            pageFrame[readFrontIndex].content = page->content;
            pageFrame[readFrontIndex].pageNumber = page->pageNumber;
            pageFrame[readFrontIndex].dirtyContent = page->dirtyContent;
            pageFrame[readFrontIndex].pageInUse = page->pageInUse;
            break;
        }
        else                    //else it will be moved to next location
        {
            readFrontIndex++;
            readFrontIndex = (readFrontIndex % bufferPoolSize == 0) ? 0 : readFrontIndex;
        }
        x++;
    }while (x < bufferPoolSize);
}

/*
 * Function: CLOCK
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page frame.
 * This function is one of the replacement strategy (Clock)
 * ------------------------------
 * Returns: This function doesn't return anything. Used as replacement strategy.
 */
void CLOCK(BM_BufferPool *const bm, PageFrame *page)
{
    PageFrame *pageFrame = (PageFrame *) bm->mgmtData;
    while(1)
    {
        LastPage_Clock = (LastPage_Clock % bufferPoolSize == 0) ? 0 : LastPage_Clock;

        if(pageFrame[LastPage_Clock].lruPageNum == 0)
        {
            if(pageFrame[LastPage_Clock].dirtyContent == 1)
            {
                SM_FileHandle fh;
                openPageFile(bm->pageFile, &fh);
                writeBlock(pageFrame[LastPage_Clock].pageNumber, &fh, pageFrame[LastPage_Clock].content);
                writtenToDisk++;
            }

            pageFrame[LastPage_Clock].content = page->content;
            pageFrame[LastPage_Clock].pageNumber = page->pageNumber;
            pageFrame[LastPage_Clock].dirtyContent = page->dirtyContent;
            pageFrame[LastPage_Clock].pageInUse = page->pageInUse;
            pageFrame[LastPage_Clock].lruPageNum = page->lruPageNum;
            LastPage_Clock++;
            break;
        }
        else
        {
            pageFrame[LastPage_Clock++].lruPageNum = 0;
        }
    }
}

/*
 * Function: LRU
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page frame.
 * This function is one of the replacement strategy (Least recently used)
 * ------------------------------
 * Returns: This function doesn't return anything. Used as replacement strategy.
 */
void LRU(BM_BufferPool *const bm, PageFrame *page)
{
    PageFrame *pageFrame = (PageFrame *) bm->mgmtData;
    int leastHitIndex, leastHitNum;
    int x = 0;

    do
    {
        if(pageFrame[x].pageInUse == 0)
        {
            leastHitIndex = x;
            leastHitNum = pageFrame[x].lruPageNum;
            break;
        }
        x++;
    }while (x < bufferPoolSize);

    for(x = leastHitIndex + 1; x < bufferPoolSize; x++)
    {
        if(pageFrame[x].lruPageNum < leastHitNum)
        {
            leastHitIndex = x;
            leastHitNum = pageFrame[x].lruPageNum;
        }
    }

    if(pageFrame[leastHitIndex].dirtyContent == 1)
    {
        SM_FileHandle f;
        openPageFile(bm->pageFile, &f);
        writeBlock(pageFrame[leastHitIndex].pageNumber, &f, pageFrame[leastHitIndex].content);

        writtenToDisk++;
    }

    pageFrame[leastHitIndex].pageNumber = page->pageNumber;
    pageFrame[leastHitIndex].pageInUse = page->pageInUse;
    pageFrame[leastHitIndex].content = page->content;
    pageFrame[leastHitIndex].dirtyContent = page->dirtyContent;
    pageFrame[leastHitIndex].lruPageNum = page->lruPageNum;
}


/*
 * Function: pinPage
 * ------------------------------
 * Parameters:This function takes the input as buffer pool and page from page handle structure along with page number.
 * This function will pin the pages which is being used by any instance with the specified page number.
 * And if the buffer size is full then based on the replacement stratgey the page will be replaced.
 * ------------------------------
 * Returns: returns RC message based on code definitions.
 */
 RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page,
                   const PageNumber pageNum)
{
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    // Checking if buffer pool is empty and this is the first page to be pinned
    if(pageFrame[0].pageNumber == -1)
    {
        // Reading page from disk and initializing page frame's content in the buffer pool
        pageFrame[0].content = (SM_PageHandle) malloc(PAGE_SIZE);
        if (pageFrame[0].content == NULL) {
        // Handle memory allocation failure
        return RC_MALLOC_FAILED;
        }
        SM_FileHandle filehandle;
        openPageFile(bm->pageFile, &filehandle);
        ensureCapacity(pageNum,&filehandle);
        readBlock(pageNum, &filehandle, pageFrame[0].content);
        pageFrame[0].pageNumber = pageNum;
        pageFrame[0].pageInUse++;
        readFromDisk = pageFrameCounter = 0;
        pageFrame[0].lruPageNum = pageFrameCounter;
        page->pageNum = pageNum;
        page->data = pageFrame[0].content;
        return RC_OK;
    }
    else
    {
        int i=0;
        bool BufferFull = true;

        while(i < bufferPoolSize)
        {
            if(pageFrame[i].pageNumber != -1)
            {
                if(pageFrame[i].pageNumber == pageNum)
                {
                    pageFrame[i].pageInUse++;
                    BufferFull = false;
                    pageFrameCounter++;
                    switch (bm->strategy) {
                        case RS_LRU:
                            pageFrame[i].lruPageNum = pageFrameCounter;
                            break;
                        case RS_CLOCK:
                            pageFrame[i].lruPageNum = 1;
                            break;
                        case RS_LFU:break;
                        case RS_FIFO: break; //already taken care
                        case RS_LRU_K: break;
                        default: break;
                    }
                    page->data = pageFrame[i].content;
                    page->pageNum = pageNum;
                    LastPage_Clock++;
                    break;
                }
            } else {
                SM_FileHandle fh;
                openPageFile(bm->pageFile, &fh);
                pageFrame[i].content = (SM_PageHandle) malloc(PAGE_SIZE);
                readBlock(pageNum, &fh, pageFrame[i].content);
                pageFrame[i].pageNumber = pageNum;
                pageFrame[i].pageInUse = 1;
                readFromDisk++;
                pageFrameCounter++;
                if(bm->strategy == RS_LRU)
                    pageFrame[i].lruPageNum = pageFrameCounter;
                else if(bm->strategy == RS_CLOCK)
                    pageFrame[i].lruPageNum = 1;

                page->pageNum = pageNum;
                page->data = pageFrame[i].content;
                BufferFull = false;
                break;
            }
            i++;
        }

        if(BufferFull == true)
        {
            PageFrame *newPage = (PageFrame *) malloc(sizeof(PageFrame));

            SM_FileHandle fh;
            openPageFile(bm->pageFile, &fh);
            newPage->content = (SM_PageHandle) malloc(PAGE_SIZE);
            readBlock(pageNum, &fh, newPage->content);
            newPage->pageNumber = pageNum;
            newPage->dirtyContent = 0;
            newPage->pageInUse = 1;
            readFromDisk++;
            pageFrameCounter++;

            if(bm->strategy == RS_LRU)
                newPage->lruPageNum = pageFrameCounter;
            else if(bm->strategy == RS_CLOCK)

                newPage->lruPageNum = 1;

            page->pageNum = pageNum;
            page->data = newPage->content;


            switch(bm->strategy)
            {
                case RS_FIFO: 
                    FIFO(bm, newPage);
                    break;

                case RS_LRU: 
                    LRU(bm, newPage);
                    break;

                case RS_CLOCK: 
                    CLOCK(bm, newPage);
                    break;

                case RS_LFU: 
                    printf("\n LFU algorithm not implemented");
                    break;

                case RS_LRU_K:
                    printf("\n LRU-k algorithm not implemented");
                    break;

                default:
                    printf("\nAlgorithm Not Implemented\n");
                    break;
            }
            free(newPage);

        }
        return RC_OK;
    }
    free(pageFrame);
    
}

/*Statistics Functions:*/

/*
 * Function: getFrameContents
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will store and return the page number in array.
 * ------------------------------
 * Returns: returns frameContents (i.e. page numbers).
 */
 PageNumber *getFrameContents (BM_BufferPool *const bm)
{
    PageNumber *ContentsofFrame = malloc(sizeof(PageNumber) * bufferPoolSize);
    PageFrame *pageFrame = (PageFrame *) bm->mgmtData;
    if (ContentsofFrame == NULL) {
        return NULL;
    }
    int i = 0;
    while(i < bufferPoolSize) {
        ContentsofFrame[i] = (pageFrame[i].pageNumber != -1) ? pageFrame[i].pageNumber : NO_PAGE;
        i++;
    }
    
    return ContentsofFrame;
}

/*
 * Function: getDirtyFlags
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will store and return the dirty pages in array of boolean.
 * ------------------------------
 * Returns: returns dirtyFlags (i.e. dirty pages).
 */

 bool *getDirtyFlags (BM_BufferPool *const bm)
{
    bool *dirtyFlags = malloc(sizeof(bool) * bufferPoolSize);
    PageFrame *pageFrame = (PageFrame *)bm->mgmtData;

    int i;
    for(i = 0; i < bufferPoolSize; i++)
    {
        dirtyFlags[i] = (pageFrame[i].dirtyContent == 1) ? true : false ;
    }
    return dirtyFlags;
}

/*
 * Function: getFixCounts
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will store and return the array of pages which are in use by any other instances
 * ------------------------------
 * Returns: returns fixCounts (i.e. pages in use).
 */
 int *getFixCounts (BM_BufferPool *const bm)
{
    int *fixCounts = malloc(sizeof(int) * bufferPoolSize);
    PageFrame *pageFrame= (PageFrame *)bm->mgmtData;
    if (fixCounts == NULL) {
        return NULL;
    }
    int i = 0;
    while(i < bufferPoolSize)
    {
        fixCounts[i] = (pageFrame[i].pageInUse != -1) ? pageFrame[i].pageInUse : 0;
        i++;
    }
    return fixCounts;
}



/*
 * Function: getNumReadIO
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will be used to see on the number of pages that have been read from the disk after buffer initialization.
 * ------------------------------
 * Returns: returns the count of pages that were read after buffer initialization.
 */

 int getNumReadIO (BM_BufferPool *const bm)
{
    return (readFromDisk + 1);
}

/*
 * Function: getNumWriteIO
 * ------------------------------
 * Parameters:This function takes the input as buffer pool.
 * This function will be used to see the number of pages that have been written into the disk
 * ------------------------------
 * Returns: returns the count of pages that were written after buffer initialization.
 */
 int getNumWriteIO (BM_BufferPool *const bm)
{
    return writtenToDisk;
}
