#include <stdlib.h>
#include "dberror.h"
#include "expr.h"
#include "record_mgr.h"
#include "tables.h"
#include "test_helper.h"
#include "rm_serializer.h"

// Macro to assert that two records are equal based on their attributes
#define ASSERT_EQUALS_RECORDS(_l,_r, schema, message)            \
    do {                                    \
        /* _l and _r are the two records being compared */       \
        Record *_lR = _l;                                         \
        Record *_rR = _r;                                         \
        /* Compare the raw data of both records byte by byte */   \
        ASSERT_TRUE(memcmp(_lR->data,_rR->data,getRecordSize(schema)) == 0, message); \
        /* Iterate over each attribute in the schema */           \
        int i;                                                    \
        for(i = 0; i < schema->numAttr; i++)                      \
        {                                                         \
            Value *lVal, *rVal;                                   \
            char *lSer, *rSer;                                    \
            /* Get the value of the i-th attribute of each record */  \
            getAttr(_lR, schema, i, &lVal);                       \
            getAttr(_rR, schema, i, &rVal);                       \
            /* Serialize the values to strings for comparison */  \
            lSer = serializeValue(lVal);                          \
            rSer = serializeValue(rVal);                          \
            /* Assert that the serialized values are the same */  \
            ASSERT_EQUALS_STRING(lSer, rSer, "attr same");        \
            /* Free memory allocated for the values and serialized strings */  \
            free(lVal);                                           \
            free(rVal);                                           \
            free(lSer);                                           \
            free(rSer);                                           \
        }                                                         \
    } while(0)


// Macro to assert that a specific record exists within an array of records
#define ASSERT_EQUALS_RECORD_IN(_l, _r, rSize, schema, message)        \
    do {                                    \
        /* Declare an index variable for the loop */                  \
        int i;                                \
        /* Flag to indicate if the record was found */                \
        boolean found = false;                        \
        /* Iterate through the array of records (_r) */               \
        for(i = 0; i < rSize; i++)                        \
        /* Compare the binary data of record _l to each record in the array */  \
        if (memcmp(_l->data, _r[i]->data, getRecordSize(schema)) == 0)    \
            found = true;  /* Set found to true if a match is found */  \
        /* Assert that the record was found, with an appropriate message */    \
        ASSERT_TRUE(found, message);                        \
    } while(0)


// Macro to assert the result of an operation on two values
#define OP_TRUE(left, right, op, message)        \
    do {                            \
        /* Allocate memory for the result of the operation */           \
        Value *result = (Value *) malloc(sizeof(Value));    \
        /* Apply the operation (op) to 'left' and 'right' and store the result */  \
        op(left, right, result);                \
        /* Extract the boolean result from the operation result */      \
        bool b = result->v.boolV;                \
        /* Free the memory allocated for the result */                  \
        free(result);                    \
        /* Assert that the boolean result of the operation is true */   \
        ASSERT_TRUE(b, message);                \
    } while (0)

// ************************************************************
// Test function declarations
// ************************************************************

// Test for creating records and manipulating attributes
static void testRecords(void);

// Test for creating a table and inserting records
static void testCreateTableAndInsert(void);

// Test for updating records in a table
static void testUpdateTable(void);

// Test for performing scans on a table (with conditions)
static void testScans(void);

// Test for performing additional scans with different conditions
static void testScansTwo(void);

// Test for inserting many records into a table and verifying them
static void testInsertManyRecords(void);

// Test for performing multiple concurrent scans on the same table
static void testMultipleScans(void);

// ************************************************************
// Struct to represent a test record
// ************************************************************

// Struct for holding a test record
typedef struct TestRecord {
    int a;   // Attribute 'a' (integer)
    char *b; // Attribute 'b' (string)
    int c;   // Attribute 'c' (integer)
} TestRecord;

// ************************************************************
// Helper function declarations
// ************************************************************

// Function to create a record based on attributes 'a', 'b', and 'c'
Record *testRecord(Schema *schema, int a, char *b, int c);

// Function to define a schema for the test table
Schema *testSchema(void);

// Function to create a record from a TestRecord struct
Record *fromTestRecord(Schema *schema, TestRecord in);

// ************************************************************
// Global variable for the current test name
// ************************************************************

// Holds the name of the current test for debugging/logging
char *testName;

// ************************************************************
// Main function
// ************************************************************

// Main function to run all test cases
int main(void) {
    // Initialize test name as an empty string
    testName = "";

    // Run the tests
    testInsertManyRecords();   // Test inserting many records
    testRecords();             // Test creating records and manipulating attributes
    testCreateTableAndInsert();// Test creating a table and inserting records
    testUpdateTable();         // Test updating records in the table
    testScans();               // Test scanning records with a condition
    testScansTwo();            // Test additional scans with different conditions
    testMultipleScans();       // Test performing multiple concurrent scans

    // Return 0 to indicate successful execution
    return 0;
}

// ************************************************************
// Test for creating records and manipulating attributes
// ************************************************************
void testRecords(void) {
    // Array of expected test records
    TestRecord expected[] = {
            {1, "aaaa", 3},  // Record with attributes: a=1, b="aaaa", c=3
    };
    Schema *schema;
    Record *r;
    Value *value;
    // Setting the test name for debugging/logging
    testName = "test creating records and manipulating attributes";

    // Used to store the result of stringToValue function
    Value *v;

    // ************************************************************
    // Step 1: Check the attributes of a created record
    // ************************************************************

    // Create schema for the table
    schema = testSchema();

    // Create a record from the expected test record
    r = fromTestRecord(schema, expected[0]);

    // ************************************************************
    // Step 2: Check the first attribute (a)
    // ************************************************************

    // Get the value of the first attribute (a) from the record
    getAttr(r, schema, 0, &value);
    // Convert the expected value "1" to a Value object
    v = stringToValue("i1");
    // Assert that the value of the first attribute is equal to "1"
    OP_TRUE(v, value, valueEquals, "first attr");
    // Free the allocated memory for the values
    freeVal(value);
    freeVal(v);

    // ************************************************************
    // Step 3: Check the second attribute (b)
    // ************************************************************

    // Get the value of the second attribute (b) from the record
    getAttr(r, schema, 1, &value);
    // Convert the expected string value "aaaa" to a Value object
    v = stringToValue("saaaa");
    // Assert that the value of the second attribute is equal to "aaaa"
    OP_TRUE(v, value, valueEquals, "second attr");
    // Free the allocated memory for the values
    freeVal(value);
    freeVal(v);

    // ************************************************************
    // Step 4: Check the third attribute (c)
    // ************************************************************

    // Get the value of the third attribute (c) from the record
    getAttr(r, schema, 2, &value);
    // Convert the expected value "3" to a Value object
    v = stringToValue("i3");
    // Assert that the value of the third attribute is equal to "3"
    OP_TRUE(v, value, valueEquals, "third attr");
    // Free the allocated memory for the values
    freeVal(value);
    freeVal(v);

    // ************************************************************
    // Step 5: Modify the third attribute (c)
    // ************************************************************

    // Modify the third attribute (c) to a new value "4"
    v = stringToValue("i4");
    setAttr(r, schema, 2, v);
    // Retrieve the updated value of the third attribute
    getAttr(r, schema, 2, &value);
    // Assert that the updated value of the third attribute is equal to "4"
    OP_TRUE(v, value, valueEquals, "third attr after setting");
    // Free the allocated memory for the values
    freeVal(value);
    freeVal(v);

    // ************************************************************
    // Step 6: Clean up memory
    // ************************************************************

    // Free the memory allocated for the record and schema
    freeRecord(r);
    freeSchema(schema);

    // Mark the test as done
    TEST_DONE();
}

// ************************************************************
// Test for creating a table and inserting records
// ************************************************************
void testCreateTableAndInsert(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},  // Record 1
        {2, "bbbb", 2},  // Record 2
        {3, "cccc", 1},  // Record 3
        {4, "dddd", 3},  // Record 4
        {5, "eeee", 5},  // Record 5
        {6, "ffff", 1},  // Record 6
        {7, "gggg", 3},  // Record 7
        {8, "hhhh", 3},  // Record 8
        {9, "iiii", 2},  // Record 9
    };
    int numInserts = 9, i;  // Number of records to insert and loop counter
    Record *r;              // Record pointer for inserting records
    RID *rids;              // Array to store the record IDs (RIDs)
    Schema *schema;         // Schema for the table
    RC result;              // Return code to capture results of function calls

    // Set the name of the current test for debugging/logging
    testName = "test creating a new table and inserting tuples";

    // Create the schema for the table
    schema = testSchema();

    // Allocate memory for storing RIDs of the inserted records
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // ************************************************************
    // Step 1: Initialize the Record Manager
    // ************************************************************
    TEST_CHECK(initRecordManager(NULL));

    // Step 1.1: Drop the table if it already exists
    result = deleteTable("test_table_r");
    if (result != RC_OK && result != RC_TABLE_NOT_EXISTS) {
        printf("Failed to delete existing table. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 2: Create a new table
    // ************************************************************
    result = createTable("test_table_r", schema);
    if (result != RC_OK) {
        printf("Failed to create table. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 3: Open the created table
    // ************************************************************
    result = openTable(table, "test_table_r");
    if (result != RC_OK) {
        printf("Failed to open table. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 4: Insert records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        // Convert the TestRecord to a Record and insert it into the table
        r = fromTestRecord(schema, inserts[i]);
        result = insertRecord(table, r);
        if (result != RC_OK) {
            printf("Failed to insert record %d. Error code: %d\n", i, result);
            return;
        }
        // Store the inserted record's ID
        rids[i] = r->id;
    }

    // ************************************************************
    // Step 5: Close the table after inserting records
    // ************************************************************
    result = closeTable(table);
    if (result != RC_OK) {
        printf("Failed to close table after insertion. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 6: Reopen the table for retrieval and comparison
    // ************************************************************
    result = openTable(table, "test_table_r");
    if (result != RC_OK) {
        printf("Failed to open table for comparison. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 7: Retrieve and compare inserted records
    // ************************************************************
    for (i = 0; i < 1000; i++) {
        // Select a random record and retrieve it
        int pos = rand() % numInserts;
        RID rid = rids[pos];
        result = getRecord(table, rid, r);
        if (result != RC_OK) {
            printf("Failed to get record %d. Error code: %d\n", pos, result);
            return;
        }
        // Compare the retrieved record with the expected record
        ASSERT_EQUALS_RECORDS(fromTestRecord(schema, inserts[pos]), r, schema, "compare records");
    }

    // ************************************************************
    // Step 8: Close and delete the table after completion
    // ************************************************************
    result = closeTable(table);
    if (result != RC_OK) {
        printf("Failed to close table after retrieval. Error code: %d\n", result);
        return;
    }

    result = deleteTable("test_table_r");
    if (result != RC_OK) {
        printf("Failed to delete table. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 9: Shut down the Record Manager
    // ************************************************************
    result = shutdownRecordManager();
    if (result != RC_OK) {
        printf("Failed to shut down Record Manager. Error code: %d\n", result);
        return;
    }

    // ************************************************************
    // Step 10: Free allocated resources
    // ************************************************************
    free(rids);      // Free the memory allocated for RIDs
    freeSchema(schema); // Free the memory allocated for the schema
    free(table);     // Free the memory allocated for the table structure

    TEST_DONE();  // Mark the test as done
}




// ************************************************************
// Test for running multiple scans on a table with a condition
// ************************************************************
void testMultipleScans(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},  // Record 1
        {2, "bbbb", 2},  // Record 2
        {3, "cccc", 1},  // Record 3
        {4, "dddd", 3},  // Record 4
        {5, "eeee", 5},  // Record 5
        {6, "ffff", 1},  // Record 6
        {7, "gggg", 3},  // Record 7
        {8, "hhhh", 3},  // Record 8
        {9, "iiii", 2},  // Record 9
        {10, "jjjj", 5}, // Record 10
    };

    // Variables to track the number of scans and inserted records
    int numInserts = 10, i, scanOne = 0, scanTwo = 0;

    // Allocate memory for records and schema
    Record *r;
    RID *rids;
    Schema *schema;

    // Set the name of the current test
    testName = "test running multiple scans";

    // Initialize schema and record IDs array
    schema = testSchema();
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // Allocate memory for two scan handles
    RM_ScanHandle *sc1 = (RM_ScanHandle *) malloc(sizeof(RM_ScanHandle));
    RM_ScanHandle *sc2 = (RM_ScanHandle *) malloc(sizeof(RM_ScanHandle));

    // Variables for expressions and return codes
    Expr *se1, *left, *right;
    int rc, rc2;

    // Initialize the Record Manager and create/open the table
    TEST_CHECK(initRecordManager(NULL));
    TEST_CHECK(createTable("test_table_r", schema));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Insert records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        r = fromTestRecord(schema, inserts[i]);
        TEST_CHECK(insertRecord(table, r));
        rids[i] = r->id;  // Store the record ID
    }

    // ************************************************************
    // Set up the condition for the scans (c = 3)
    // ************************************************************
    MAKE_CONS(left, stringToValue("i3"));       // Create constant value (c = 3)
    MAKE_ATTRREF(right, 2);                     // Attribute reference (column index 2: 'c')
    MAKE_BINOP_EXPR(se1, left, right, OP_COMP_EQUAL);  // Binary expression for the condition (c == 3)
    createRecord(&r, schema);                   // Allocate memory for record

    // ************************************************************
    // Start two scans with the same condition (c == 3)
    // ************************************************************
    TEST_CHECK(startScan(table, sc1, se1));     // Start scan 1
    TEST_CHECK(startScan(table, sc2, se1));     // Start scan 2

    // Perform scan 2 first to check a single tuple
    if ((rc2 = next(sc2, r)) == RC_OK)
        scanTwo++;

    // Perform scan 1 and interleave scan 2 every third tuple
    i = 0;
    while ((rc = next(sc1, r)) == RC_OK) {
        scanOne++;  // Increment scan 1 count
        i++;
        if (i % 3 == 0)  // Every third tuple, scan with scan 2
            if ((rc2 = next(sc2, r)) == RC_OK)
                scanTwo++;  // Increment scan 2 count
    }

    // Continue scan 2 until all tuples are scanned
    while ((rc2 = next(sc2, r)) == RC_OK)
        scanTwo++;

    // ************************************************************
    // Validate that both scans return the same number of tuples
    // ************************************************************
    ASSERT_TRUE(scanOne == scanTwo, "scans returned same number of tuples");
    
    // Check if the scan terminated properly
    if (rc != RC_RM_NO_MORE_TUPLES)
        TEST_CHECK(rc);

    // Close the scans
    TEST_CHECK(closeScan(sc1));
    TEST_CHECK(closeScan(sc2));

    // ************************************************************
    // Clean up: Close the table and delete it
    // ************************************************************
    TEST_CHECK(closeTable(table));
    TEST_CHECK(deleteTable("test_table_r"));
    TEST_CHECK(shutdownRecordManager());

    // Free allocated resources
    free(rids);
    freeSchema(schema);
    free(table);

    TEST_DONE();  // Mark the test as done
}

void testUpdateTable(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},
        {2, "bbbb", 2},
        {3, "cccc", 1},
        {4, "dddd", 3},
        {5, "eeee", 5},
        {6, "ffff", 1},
        {7, "gggg", 3},
        {8, "hhhh", 3},
        {9, "iiii", 2},
        {10, "jjjj", 5},
    };

    // Array of updates to be applied later
    TestRecord updates[] = {
        {1, "iiii", 6},
        {2, "iiii", 6},
        {3, "iiii", 6}
    };

    // Array of rows to be deleted
    int deletes[] = {9, 6, 7, 8, 5};

    // Final expected state of records after updates and deletions
    TestRecord finalR[] = {
        {1, "iiii", 6},
        {2, "iiii", 6},
        {3, "iiii", 6},
        {4, "dddd", 3},
        {5, "eeee", 5},
    };

    int numInserts = 10, numUpdates = 3, numDeletes = 5, numFinal = 5, i;
    Record *r;
    RID *rids;
    Schema *schema;

    // Set the name of the current test
    testName = "test creating a new table and insert, update, delete tuples";

    // Initialize schema and record IDs array
    schema = testSchema();
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // Initialize the Record Manager and create/open the table
    TEST_CHECK(initRecordManager(NULL));
    TEST_CHECK(createTable("test_table_r", schema));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Insert records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        r = fromTestRecord(schema, inserts[i]);
        TEST_CHECK(insertRecord(table, r));
        rids[i] = r->id;  // Store the record ID
    }

    // ************************************************************
    // Delete specified records from the table
    // ************************************************************
    for (i = 0; i < numDeletes; i++) {
        // Delete records using their IDs
        TEST_CHECK(deleteRecord(table, rids[deletes[i]]));
    }

    // ************************************************************
    // Update specified records in the table
    // ************************************************************
    for (i = 0; i < numUpdates; i++) {
        r = fromTestRecord(schema, updates[i]);
        r->id = rids[i];  // Update the record with its ID
        TEST_CHECK(updateRecord(table, r));
    }

    // Close and reopen the table to simulate persistent updates
    TEST_CHECK(closeTable(table));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Retrieve records and compare them with the expected final state
    // ************************************************************
    for (i = 0; i < numFinal; i++) {
        RID rid = rids[i];
        TEST_CHECK(getRecord(table, rid, r));
        ASSERT_EQUALS_RECORDS(fromTestRecord(schema, finalR[i]), r, schema, "compare records");
    }

    // ************************************************************
    // Clean up: Close and delete the table
    // ************************************************************
    TEST_CHECK(closeTable(table));
    TEST_CHECK(deleteTable("test_table_r"));
    TEST_CHECK(shutdownRecordManager());

    free(table);
    TEST_DONE();  // Mark the test as done
}

void testInsertManyRecords(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},
        {2, "bbbb", 2},
        {3, "cccc", 1},
        {4, "dddd", 3},
        {5, "eeee", 5},
        {6, "ffff", 1},
        {7, "gggg", 3},
        {8, "hhhh", 3},
        {9, "iiii", 2},
        {10, "jjjj", 5},
    };

    // Create a larger array for inserting 10,000 records
    TestRecord realInserts[10000];

    // Update one record (random record)
    TestRecord updates[] = {
        {3333, "iiii", 6}
    };

    int numInserts = 10000, i;
    int randomRec = 3333;
    Record *r;
    RID *rids;
    Schema *schema;

    // Set the name of the current test
    testName = "test creating a new table and inserting 10000 records then updating record from rids[3333]";

    // Initialize schema and record IDs array
    schema = testSchema();
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // Initialize the Record Manager and create/open the table
    TEST_CHECK(initRecordManager(NULL));
    TEST_CHECK(createTable("test_table_t", schema));
    TEST_CHECK(openTable(table, "test_table_t"));

    // ************************************************************
    // Insert 10,000 records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        realInserts[i] = inserts[i % 10];  // Cycle through the 10 records
        realInserts[i].a = i;  // Set unique IDs for each record
        r = fromTestRecord(schema, realInserts[i]);
        TEST_CHECK(insertRecord(table, r));
        rids[i] = r->id;
    }

    // Close and reopen the table to simulate persistence
    TEST_CHECK(closeTable(table));
    TEST_CHECK(openTable(table, "test_table_t"));

    // ************************************************************
    // Retrieve records and compare them with the inserted records
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        RID rid = rids[i];
        TEST_CHECK(getRecord(table, rid, r));
        ASSERT_EQUALS_RECORDS(fromTestRecord(schema, realInserts[i]), r, schema, "compare records");
    }

    // Update a random record and compare
    r = fromTestRecord(schema, updates[0]);
    r->id = rids[randomRec];
    TEST_CHECK(updateRecord(table, r));
    TEST_CHECK(getRecord(table, rids[randomRec], r));
    ASSERT_EQUALS_RECORDS(fromTestRecord(schema, updates[0]), r, schema, "compare records");

    // ************************************************************
    // Clean up: Close and delete the table
    // ************************************************************
    TEST_CHECK(closeTable(table));
    TEST_CHECK(deleteTable("test_table_t"));
    TEST_CHECK(shutdownRecordManager());

    freeRecord(r);
    free(table);
    TEST_DONE();  // Mark the test as done
}

void testScans(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},
        {2, "bbbb", 2},
        {3, "cccc", 1},
        {4, "dddd", 3},
        {5, "eeee", 5},
        {6, "ffff", 1},
        {7, "gggg", 3},
        {8, "hhhh", 3},
        {9, "iiii", 2},
        {10, "jjjj", 5},
    };

    // Expected results of the scan with condition c=1
    TestRecord scanOneResult[] = {
        {3, "cccc", 1},
        {6, "ffff", 1},
    };

    // Array to track found scan results
    bool foundScan[] = {FALSE, FALSE};

    int numInserts = 10, scanSizeOne = 2, i;
    Record *r;
    RID *rids;
    Schema *schema;

    // Allocate memory for scan handle
    RM_ScanHandle *sc = (RM_ScanHandle *) malloc(sizeof(RM_ScanHandle));

    // Expressions for scan conditions
    Expr *sel, *left, *right;
    int rc;

    // Set the name of the current test
    testName = "test creating a new table and inserting tuples";

    // Initialize schema and record IDs array
    schema = testSchema();
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // Initialize the Record Manager and create/open the table
    TEST_CHECK(initRecordManager(NULL));
    TEST_CHECK(createTable("test_table_r", schema));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Insert records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        r = fromTestRecord(schema, inserts[i]);
        TEST_CHECK(insertRecord(table, r));
        rids[i] = r->id;  // Store the record ID
    }

    // Close and reopen the table to simulate persistence
    TEST_CHECK(closeTable(table));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Set up the scan condition (c = 1) and start the scan
    // ************************************************************
    MAKE_CONS(left, stringToValue("i1"));
    MAKE_ATTRREF(right, 2);  // Column c (index 2)
    MAKE_BINOP_EXPR(sel, left, right, OP_COMP_EQUAL);  // Condition c == 1

    TEST_CHECK(startScan(table, sc, sel));

    // Perform the scan and check for matching records
    while ((rc = next(sc, r)) == RC_OK) {
        for (i = 0; i < scanSizeOne; i++) {
            if (memcmp(fromTestRecord(schema, scanOneResult[i])->data, r->data, getRecordSize(schema)) == 0)
                foundScan[i] = TRUE;  // Mark matching records
        }
    }

    if (rc != RC_RM_NO_MORE_TUPLES)
        TEST_CHECK(rc);  // Check for end of scan

    TEST_CHECK(closeScan(sc));

    // Check that all expected scan results were found
    for (i = 0; i < scanSizeOne; i++)
        ASSERT_TRUE(foundScan[i], "check for scan result");

    // ************************************************************
    // Clean up: Close and delete the table
    // ************************************************************
    TEST_CHECK(closeTable(table));
    TEST_CHECK(deleteTable("test_table_r"));
    TEST_CHECK(shutdownRecordManager());

    free(table);
    free(sc);
    freeExpr(sel);
    TEST_DONE();  // Mark the test as done
}


// ************************************************************
// Function to test multiple scans with different conditions
void testScansTwo(void) {
    // Allocate memory for the table structure
    RM_TableData *table = (RM_TableData *) malloc(sizeof(RM_TableData));

    // Array of test records to insert into the table
    TestRecord inserts[] = {
        {1, "aaaa", 3},
        {2, "bbbb", 2},
        {3, "cccc", 1},
        {4, "dddd", 3},
        {5, "eeee", 5},
        {6, "ffff", 1},
        {7, "gggg", 3},
        {8, "hhhh", 3},
        {9, "iiii", 2},
        {10, "jjjj", 5},
    };

    // Boolean array to keep track of found scan results
    bool foundScan[] = {
        FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE
    };

    int numInserts = 10, i;
    Record *r;
    RID *rids;
    Schema *schema;

    // Allocate memory for the scan handle
    RM_ScanHandle *sc = (RM_ScanHandle *) malloc(sizeof(RM_ScanHandle));

    // Expressions to define scan conditions
    Expr *sel, *left, *right, *first, *se;
    int rc;

    // Set the name of the current test
    testName = "test creating a new table and inserting tuples";

    // Initialize schema and record IDs array
    schema = testSchema();
    rids = (RID *) malloc(sizeof(RID) * numInserts);

    // Initialize the Record Manager and create/open the table
    TEST_CHECK(initRecordManager(NULL));
    TEST_CHECK(createTable("test_table_r", schema));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Insert records into the table
    // ************************************************************
    for (i = 0; i < numInserts; i++) {
        r = fromTestRecord(schema, inserts[i]);
        TEST_CHECK(insertRecord(table, r));
        rids[i] = r->id;  // Store the record ID
    }

    // Close and reopen the table to simulate persistence
    TEST_CHECK(closeTable(table));
    TEST_CHECK(openTable(table, "test_table_r"));

    // ************************************************************
    // Select 1 record with INT in condition a = 2
    // ************************************************************
    MAKE_CONS(left, stringToValue("i2"));
    MAKE_ATTRREF(right, 0);  // Column a (index 0)
    MAKE_BINOP_EXPR(sel, left, right, OP_COMP_EQUAL);  // Condition a == 2

    createRecord(&r, schema);
    TEST_CHECK(startScan(table, sc, sel));

    while ((rc = next(sc, r)) == RC_OK) {
        // Compare the result with the expected record
        ASSERT_EQUALS_RECORDS(fromTestRecord(schema, inserts[1]), r, schema, "compare records");
    }
    if (rc != RC_RM_NO_MORE_TUPLES)
        TEST_CHECK(rc);
    
    TEST_CHECK(closeScan(sc));

    // ************************************************************
    // Select 1 record with STRING in condition b = 'ffff'
    // ************************************************************
    MAKE_CONS(left, stringToValue("sffff"));
    MAKE_ATTRREF(right, 1);  // Column b (index 1)
    MAKE_BINOP_EXPR(sel, left, right, OP_COMP_EQUAL);  // Condition b == 'ffff'

    createRecord(&r, schema);
    TEST_CHECK(startScan(table, sc, sel));

    while ((rc = next(sc, r)) == RC_OK) {
        // Compare the result with the expected record
        ASSERT_EQUALS_RECORDS(fromTestRecord(schema, inserts[5]), r, schema, "compare records");
        serializeRecord(r, schema);  // Serialize the record to check the data
    }

    if (rc != RC_RM_NO_MORE_TUPLES)
        TEST_CHECK(rc);
    
    TEST_CHECK(closeScan(sc));

    // ************************************************************
    // Select all records, with condition being false (c >= 4)
    // ************************************************************
    MAKE_CONS(left, stringToValue("i4"));
    MAKE_ATTRREF(right, 2);  // Column c (index 2)
    MAKE_BINOP_EXPR(first, right, left, OP_COMP_SMALLER);  // Condition c < 4
    MAKE_UNOP_EXPR(se, first, OP_BOOL_NOT);  // NOT (c < 4) => c >= 4

    TEST_CHECK(startScan(table, sc, se));

    // Perform the scan and track found records
    while ((rc = next(sc, r)) == RC_OK) {
        serializeRecord(r, schema);  // Serialize record for further checks
        for (i = 0; i < numInserts; i++) {
            // Compare the record data and mark found records
            if (memcmp(fromTestRecord(schema, inserts[i])->data, r->data, getRecordSize(schema)) == 0)
                foundScan[i] = TRUE;
        }
    }

    if (rc != RC_RM_NO_MORE_TUPLES)
        TEST_CHECK(rc);
    
    TEST_CHECK(closeScan(sc));

    // ************************************************************
    // Assertions to check scan results based on condition c >= 4
    // ************************************************************
    ASSERT_TRUE(!foundScan[0], "not greater than four");  // Check c < 4 case
    ASSERT_TRUE(foundScan[4], "greater than four");  // Check c >= 4 case
    ASSERT_TRUE(foundScan[9], "greater than four");  // Check c >= 4 case

    // ************************************************************
    // Clean up: Close and delete the table
    // ************************************************************
    TEST_CHECK(closeTable(table));
    TEST_CHECK(deleteTable("test_table_r"));
    TEST_CHECK(shutdownRecordManager());

    freeRecord(r);
    free(table);
    free(sc);
    freeExpr(sel);
    TEST_DONE();  // Mark the test as done
}

// ************************************************************
// Function to create a test schema with 3 attributes: a, b, c
Schema *testSchema(void) {
    Schema *result;
    char *names[] = {"a", "b", "c"};  // Attribute names
    DataType dt[] = {DT_INT, DT_STRING, DT_INT};  // Data types for the attributes
    int sizes[] = {0, 4, 0};  // Size of attributes (only strings need size)
    int keys[] = {0};  // Define the primary key (index 0 for attribute 'a')
    int i;

    // Allocate memory for schema components
    char **cpNames = (char **) malloc(sizeof(char*) * 3);
    DataType *cpDt = (DataType *) malloc(sizeof(DataType) * 3);
    int *cpSizes = (int *) malloc(sizeof(int) * 3);
    int *cpKeys = (int *) malloc(sizeof(int));

    // Copy values into the schema components
    for (i = 0; i < 3; i++) {
        cpNames[i] = (char *) malloc(2);
        strcpy(cpNames[i], names[i]);
    }

    memcpy(cpDt, dt, sizeof(DataType) * 3);
    memcpy(cpSizes, sizes, sizeof(int) * 3);
    memcpy(cpKeys, keys, sizeof(int));

    // Create the schema with 3 attributes
    result = createSchema(3, cpNames, cpDt, cpSizes, 1, cpKeys);

    return result;
}

// ************************************************************
// Helper function to create a record from a TestRecord struct
Record *fromTestRecord(Schema *schema, TestRecord in) {
    return testRecord(schema, in.a, in.b, in.c);  // Call helper function
}

// ************************************************************
// Helper function to create a record from individual values
Record *testRecord(Schema *schema, int a, char *b, int c) {
    Record *result;
    Value *value;

    // Create a new record with the given schema
    TEST_CHECK(createRecord(&result, schema));

    // Set attribute 'a' (int)
    MAKE_VALUE(value, DT_INT, a);
    TEST_CHECK(setAttr(result, schema, 0, value));
    freeVal(value);

    // Set attribute 'b' (string)
    MAKE_STRING_VALUE(value, b);
    TEST_CHECK(setAttr(result, schema, 1, value));
    freeVal(value);

    // Set attribute 'c' (int)
    MAKE_VALUE(value, DT_INT, c);
    TEST_CHECK(setAttr(result, schema, 2, value));
    freeVal(value);

    return result;  // Return the created record
}