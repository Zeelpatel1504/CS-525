#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buffer_mgr.h"
#include "storage_mgr.h"

// -- Initializes the buffer pool by setting up the page file, the number of pages, and the replacement strategy.
// -- Initially, all page frames should be empty, and the page file should already exist.
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, 
                    const int numPages, ReplacementStrategy strategy,
		            void *stratData) 
{
    // Check if the buffer pool or the file name is NULL, return error if invalid.
    if(bm == NULL || pageFileName == NULL) {
        return RC_FILE_NOT_FOUND;
    }

    // Check if the number of pages in the buffer pool is valid.
    if (numPages <= 0) {
        return RC_ERROR;
    }
    
    // Check if the specified page file exists, return error if not found.
    FILE *fp = fopen(pageFileName, "r+");
    if(fp == NULL) {
        return RC_FILE_NOT_FOUND;
    }

    // Initialize buffer pool attributes: file name, number of pages, and replacement strategy.
    bm->pageFile = (char *) pageFileName;
    bm->numPages = numPages;
    bm->strategy = strategy;

    // Initialize the page cache to manage the pages in memory.
    PageCache* pageCache = createPageCache(bm, numPages);

    // Store the page cache in the buffer pool's management data.
    bm->mgmtData = pageCache;

    // Close the file as we only needed to check if it exists.
    fclose(fp);
    fp = NULL;

    return RC_OK;
}

// -- Shuts down the buffer pool by releasing all allocated resources.
// -- Dirty pages should be written back to disk before destroying the buffer pool.
// -- If any pages are pinned (in use), the function should raise an error.
RC shutdownBufferPool(BM_BufferPool *const bm)
{
    // Check if the buffer pool is valid, return error if not.
    if(bm == NULL) {
        return RC_ERROR;
    }

    // Get the page cache (management data) associated with this buffer pool.
    PageCache* pageCache = bm->mgmtData;

    // If the page cache is NULL, the buffer pool is already shut down.
    if(pageCache == NULL) {
        return RC_OK;
    }

    // Force the buffer pool to flush all dirty pages to disk.
    if(forceFlushPool(bm) != RC_OK) {
        return RC_ERROR;
    }

    // Free the resources used by the page cache (memory allocated for pages).
    freePageCache(pageCache);

    // Set the buffer pool's management data to NULL, indicating it has been freed.
    bm->mgmtData = NULL;

    // Free the buffer pool itself if it still exists.
    if(bm != NULL) {
        free(bm);
    }
    
    return RC_OK;
}

// forceFlushPool is used to write all dirty pages from the buffer pool back to disk.
// -- It checks for dirty pages (pages that have been modified) and ensures they are written to disk
// -- if they have no pins (i.e., no active clients are using them).
RC forceFlushPool(BM_BufferPool *const bm)
{
    // Validate that the buffer manager is not NULL.
    if(bm == NULL) {
        return RC_ERROR;
    }

    // Retrieve the page cache for the buffer pool.
    PageCache* pageCache = bm->mgmtData;

    // If the page cache is NULL, return OK as there are no pages to flush.
    if(pageCache == NULL) {
        return RC_OK;
    }

    // Iterate through all frames in the page cache.
    int i;
    for(i = 0; i < pageCache->capacity; i++) {
        Frame* frame = pageCache->arr[i];

        // Skip this frame if it does not contain a valid page (NO_PAGE).
        if(frame->pageNum == NO_PAGE) {
            continue;
        }

        // Check if the page is dirty and has no active pins (pinCount == 0).
        if (frame->dirtyBit == 1 && frame->pinCount == 0) {
            // Get the file handle to write the dirty page back to disk.
            SM_FileHandle *fHandle = pageCache->fHandle;

            // Write the dirty page back to disk and return an error if the write fails.
            if(writeBlock(frame->pageNum, fHandle, frame->data) != RC_OK) {
                return RC_WRITE_FAILED;
            }

            // Update the number of write I/O operations performed.
            pageCache->numWrite++;
            
            // After flushing, mark the page as clean by resetting the dirty bit.
            frame->dirtyBit = 0;
        } 
    }

    return RC_OK;
}


// pinPage pins a specific page in the buffer pool, meaning it loads the page into memory for use.
// -- Clients of the buffer manager can request a specific page by its page number, and the manager will pin it.
RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page, 
        const PageNumber pageNum) 
{
    // Validate that the input parameters are valid (buffer pool, page handle, and page number).
    if(bm == NULL || page == NULL || pageNum < 0) {
        return RC_ERROR;
    } 

    // Retrieve the page cache from the buffer pool management data.
    PageCache* pageCache = bm->mgmtData;

    // Ensure the page cache is valid.
    if(pageCache == NULL) {
        return RC_ERROR;
    }

    // Check if the requested page is already in the page cache (cache hit).
    Frame* frame = isHitPageCache(pageCache, pageNum);

    // If the page is already in the cache, update the page handle and increment the pin count.
    if(frame != NULL) {
        page->pageNum = pageNum;
        page->data = frame->data;
        frame->pinCount++;

        // If the replacement strategy is LRU (Least Recently Used), update the order to reflect the access.
        if(bm->strategy == RS_LRU) {
            updateLRUOrder(pageCache, pageNum);
        }

        return RC_OK;
    }
    
    // If the page is not in the cache, load the page using the appropriate replacement strategy.
    if(bm->strategy == RS_FIFO) {
        // Use FIFO (First In, First Out) strategy to add the page to the cache.
        return addPageToPageCacheWithFIFO(bm, page, pageNum);
    } else if(bm->strategy == RS_LRU) {
        // Use LRU (Least Recently Used) strategy to add the page to the cache.
        return addPageToPageCacheWithLRU(bm, page, pageNum);
    }

    return RC_OK;
}


// make a page as dirty
RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    // check validation of parameters
    if(bm == NULL || page == NULL) {
        return RC_ERROR;
    }

    // get page cache 
    PageCache* pageCache = bm->mgmtData;

    if(pageCache == NULL) {
        return RC_OK;
    }

    // search a frame from page cache
    Frame* frame = searchPageFromCache(pageCache, page->pageNum);

    // if this frame doesn't exist
    if(frame == NULL) {
        return RC_ERROR;
    }

    frame->dirtyBit = 1;

    return RC_OK;
}

// unpins the page.
// The pageNum field of page is used to figure out which page to pin.
RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    // check the validation of parameters
    if(bm == NULL || page == NULL) {
        return RC_ERROR;
    }
    // get page cache 
    PageCache* pageCache = bm->mgmtData;

    if(pageCache == NULL) {
        return RC_OK;
    }

    // search a frame from page cache
    Frame* frame = searchPageFromCache(pageCache, page->pageNum);

    // if this frame doesn't exist
    if(frame == NULL) {
        return RC_ERROR;
    }

    frame->pinCount--;

    if(frame->pinCount == 0 && frame->dirtyBit == 1) {
        // printf("hit force page");
        forcePage(bm, page);
    }
    return RC_OK;

}

// forcePage is to write the current content of page back to the page file on disk.
RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page) 
{
    // check the validation of parameters
    if(bm == NULL || page == NULL) {
        return RC_ERROR;
    }

    // get page cache 
    PageCache* pageCache = bm->mgmtData;

    if(pageCache == NULL) {
        return RC_OK;
    }

    // search a frame from page cache
    Frame* frame = searchPageFromCache(pageCache, page->pageNum);

    // if this frame doesn't exist
    if(frame == NULL) {
        return RC_ERROR;
    }

    // get the disk page handle pointer
    SM_FileHandle* fHandle = pageCache->fHandle;

    // printf("frame->data = %s\n", frame->data);

    // write this dirty page to the disk
    if(writeBlock(frame->pageNum, fHandle, frame->data) != RC_OK) {
        return RC_WRITE_FAILED;
    }

    return RC_OK;
}


// initialize a new frame node in buffer pool
Frame* createFrameNode() 
{
    // allocate memory for this frame
    Frame* frame = (Frame*)calloc(1, sizeof(Frame));

    // allocate memory for storing the content of the page
    char* data = (char *) calloc(PAGE_SIZE, sizeof(char));

    // initialize values for every attributes
    frame->pageNum = NO_PAGE; 
    frame->pinCount = 0; 
    frame->dirtyBit = 0;
    frame->data = data;
    return frame;
}

//reset this new frame node when remove this frame from buffer pool.
RC resetFrameNode(Frame* frame) {
    frame->pageNum = NO_PAGE; 
    frame->pinCount = 0; 
    frame->dirtyBit = 0;
    return RC_OK;
}

// create a map to record the utility of every frames, used for LRU
int* createHash(int capacity )
{
    int* hash =(int*)malloc(capacity * sizeof(int));
    for(int i = 0; i < capacity; i++) {
        hash[i] = -1;
    }
    return hash;
}

// create a cache area for pages 
PageCache* createPageCache(BM_BufferPool *const bm, int numPages) {
    // allocate memory for this page cache
    PageCache* pageCache = (PageCache* ) malloc(sizeof(PageCache));

    // initialize values for every attribute
    pageCache->front = 0;
    pageCache->rear = -1;
    pageCache->frameCnt = 0;
    pageCache->capacity = numPages;
    pageCache->numRead=0;
    pageCache->numWrite=0;

    // store a page data
    pageCache->arr = (Frame**) malloc(numPages * sizeof(Frame*));
    int i;
    for(i = 0; i < pageCache->capacity; ++i ) {
        Frame* frame = createFrameNode();
        pageCache->arr[i] = frame;
    }

    // store file handle data
    SM_FileHandle* fHandle = (SM_FileHandle*)calloc(1, sizeof(SM_FileHandle));

    openPageFile(bm->pageFile, fHandle);

    pageCache->fHandle = fHandle;

    // initialize hash map
    if(bm->strategy == RS_LRU) {
        pageCache->hash = createHash(numPages);
    } else if(bm->strategy == RS_FIFO) {
        pageCache->hash = NULL;
    }
    return pageCache;
}

// release all resources assigned to frames
void freeFrame(PageCache* pageCache) {
    if(pageCache->arr) {
        for(int i = 0; i < pageCache->capacity; i++) {
        
            Frame* frame = pageCache->arr[i];

            if(frame == NULL) {
                continue;
            }
            // release the resources assigned to store the content of the page
        
            free(frame);

            pageCache->arr[i] = NULL;
        }
        
        free(pageCache->arr);
    }
}

// release the resources assigned to the storage file handle.
void freeFileHandle(PageCache* pageCache) {
    if(pageCache->fHandle) {
        closePageFile(pageCache->fHandle);
        free(pageCache->fHandle);
    }
}

// release map resources assigned to frames created by LRU strategy
void freeHash(PageCache* pageCache) {
    if(pageCache->hash) {
        free(pageCache->hash);
    }
}
void freePageCache(PageCache* pageCache) {
    if(pageCache != NULL) {
        freeFileHandle(pageCache);
        freeFrame(pageCache);
        freeHash(pageCache);
        free(pageCache);
    }
}


// page cache is full when the frameCnt becomes equal to size
int isFull(PageCache* pageCache)
{
    return (pageCache->frameCnt == pageCache->capacity);
}

// page cache is empty when frameCnt is 0
int isEmpty(PageCache* pageCache)
{
    return (pageCache->frameCnt == 0);
}

// check whether the required pageNum hits the cache
Frame* isHitPageCache(PageCache* pageCache, const PageNumber pageNum) {
    // iterate all frames stored in this page cache
    int i;
    for(int i = 0; i < pageCache->capacity; i++) {
        Frame* frame = pageCache->arr[i];
        if(frame->pageNum == pageNum) {
            return frame;
        }
    }
    // the page cache didn't contain the current page number data, return NULL
    return NULL; 
}

RC updateLRUOrder(PageCache* pageCache, int pageNum) 
{
    int* hash = pageCache->hash;
    // update hash
    int index = -1;
    int i;
    for(i = 0; i < pageCache->capacity; i++) {
        if(hash[i] == pageNum) {
            index = i;
            break;
        }
    }
    if(index == -1) {
        return RC_ERROR;
    }
    int updatePageNum = hash[index];
    for(i = index; i < pageCache->capacity - 1; i++) {
        hash[i] = hash[i + 1];
    }
    hash[pageCache->capacity - 1] = updatePageNum;
    return RC_OK;
} 

// add a new frame to pageCache
RC addPageToPageCacheWithFIFO(BM_BufferPool *const bm, BM_PageHandle *const page, int pageNum) 
{    
    // get current page cache
    PageCache* pageCache = bm->mgmtData;

    // The following process is to add this new page to page cache

    // if current page cache is full
    if (isFull(pageCache)) {
        removePageWithFIFO(bm, page);
    } 
    // get the frame to store this page content
    pageCache->rear = (pageCache->rear + 1) % pageCache->capacity;

    Frame* frame = pageCache->arr[pageCache->rear];

    // copy the file content from disk to memory
    SM_FileHandle *fHandle = pageCache->fHandle;
    
    if(ensureCapacity(pageNum + 1, fHandle) != RC_OK) {
        return RC_READ_NON_EXISTING_PAGE;
    }
   
    if(readBlock(pageNum, fHandle, frame->data) != RC_OK) {
        return RC_ERROR;
    }

    pageCache->numRead++;

    // update this frame information page
    frame->pageNum = pageNum;
    frame->pinCount = 1;
    frame->dirtyBit = 0;

    // store page number info to page
    page->pageNum = pageNum;
    page->data = frame->data;
   
    // store this page in the cache
    // pageCache->arr[pageCache->rear] = frame;
    pageCache->frameCnt = pageCache->frameCnt + 1;

    return RC_OK;
}

// add new page to page cache based on LRU strategy
RC addPageToPageCacheWithLRU(BM_BufferPool *const bm, BM_PageHandle *const page, 
		const PageNumber pageNum)
{
    // get current page cache
    PageCache* pageCache = bm->mgmtData;

    int* hash = pageCache->hash;

    int frameIndex = -1;
 
    Frame* frame = NULL;
    // mark whether the current pageCache is full
    int fullFlag = 0;
    if(isFull(pageCache)) {
        int leastUsedPageNum = hash[0]; 
        frame = removePageWithLRU(bm, page, leastUsedPageNum);
        fullFlag = 1;
        // frame = pageCache->arr[leastUsedPageNum];
    } else {
        for(int i = 0; i < bm->numPages; i++) {
            if(hash[i] == -1) {
                frameIndex = i;
                break;
            }
        }
        if(frameIndex == -1) {
            return RC_ERROR;
        }
        frame = pageCache->arr[frameIndex];
    }

    if(frame == NULL) {
        return RC_ERROR;
    }
       
    // copy the page content
    SM_FileHandle *fHandle = pageCache->fHandle;
    
    // ensure the file page exists
    if(ensureCapacity(pageNum + 1, fHandle) != RC_OK) {
        return RC_READ_NON_EXISTING_PAGE;
    }

    // copy the file content from disk to memory
    if(readBlock(pageNum, fHandle, frame->data) != RC_OK) {
        return RC_ERROR;
    }

    // print frame page
    // printf("current fram index = %d\n", frameIndex);

    pageCache->numRead++;

    // update this frame information page
    frame->pageNum = pageNum;
    frame->pinCount = 1;
    frame->dirtyBit = 0;

    // store page number info to page
    page->pageNum = pageNum;
    page->data = frame->data;

    pageCache->frameCnt = pageCache->frameCnt + 1;

    // store this page in the cache
    if(fullFlag == 1) {
        // pageCache->arr[hash[0]] = frame;
        for(int i = 0; i < pageCache->capacity - 1; i++) {
            hash[i] = hash[i+1];
        }
        hash[pageCache->capacity - 1] = pageNum;
    } else {
        // pageCache->arr[frameIndex] = frame;
        hash[frameIndex] = pageNum;
    }

    return RC_OK;
}

// Remove a frame from queue based on FIFO. It changes front and frameCnt
RC removePageWithFIFO(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    PageCache* pageCache = bm->mgmtData;
    // check whether this page cache is empty
    if (isEmpty(pageCache))
        return RC_ERROR;

    // check whether there exisit frame with pinCount = 0
    int cnt = 0;
    Frame** arr = pageCache->arr;
    for(int i = 0; i < pageCache->capacity; i++) {
        if(arr[i]->pinCount == 0) {
            cnt++;
        }
    }
    if(cnt == 0) {
        return RC_ERROR;
    }
    
    // get the first frame in the page cache
    Frame* frame = pageCache->arr[pageCache->front];

    // fix test case :201
    if(frame->pinCount > 0) {
        while(pageCache->arr[pageCache->front]->pinCount > 0) {
            pageCache->front = (pageCache->front + 1) % pageCache->capacity;
        }
        frame = pageCache->arr[pageCache->front];

        // set the tail to the current frame
        pageCache->rear = pageCache->front - 1;
    } 
    if(frame->pinCount == 0 && frame->dirtyBit == 1) {
        forcePage(bm, page);
        pageCache->numWrite++;
    }
    // remove the first frame
    pageCache->front = (pageCache->front + 1) % pageCache->capacity;

    // update the number of used frame in page cache
    pageCache->frameCnt = pageCache->frameCnt - 1;

    // reset this frame node
    resetFrameNode(frame);

    return RC_OK;
}

Frame* removePageWithLRU(BM_BufferPool *const bm, BM_PageHandle *const page, int leastUsedPage)
{
    PageCache* pageCache = bm->mgmtData;
    // check whether this page cache is empty
    if (isEmpty(pageCache))
        return NULL;

    // check whether there exisit frame with pinCount = 0
    int cnt = 0;
    Frame** arr = pageCache->arr;
    for(int i = 0; i < pageCache->capacity; i++) {
        if(arr[i]->pinCount == 0) {
            cnt++;
        }
    }
    if(cnt == 0) {
        return NULL;
    }
    
    // get the least page in the page cache
    Frame* frame = searchPageFromCache(pageCache, leastUsedPage);

    if(frame == NULL) {
        return NULL;
    }
 
    if(frame->pinCount == 0 && frame->dirtyBit == 1) {
        forcePage(bm, page);
        pageCache->numWrite++;
    }

    // remove the least page
    resetFrameNode(frame);

    pageCache->frameCnt = pageCache->frameCnt - 1;
    
    return frame;
}

// get the frame from the page cache
Frame* searchPageFromCache(PageCache *const pageCache, int pageNum) {
    // get a frame based on page number
    int i;
    for(int i = 0; i < pageCache->capacity; i++) {
        Frame* frame = pageCache->arr[i];
        if(frame->pageNum == pageNum) {
            return frame;
        }
    }
    return NULL;
}
