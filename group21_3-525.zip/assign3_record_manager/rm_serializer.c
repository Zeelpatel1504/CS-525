#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h> // Windows-specific headers
#else
#include <unistd.h>  // Unix-like systems headers (only if needed on non-Windows)
#endif

#include "dberror.h"
#include "expr.h"
#include "record_mgr.h"
#include "tables.h"
#include "test_helper.h"
#include "rm_serializer.h"

// Serialize the table information, including the name and the number of tuples.
// -- This function returns a string that contains the table name, tuple count, and schema information.
char *
serializeTableInfo(RM_TableData *rel)
{
	VarString *result; // Variable-length string to hold the result
	MAKE_VARSTRING(result); // Macro to initialize the VarString

	// Append table name and number of tuples to the result string
	APPEND(result, "TABLE <%s> with <%i> tuples:\n", rel->name, getNumTuples(rel));

	// Serialize the schema and append it to the result
	// -- This step is required to store schema information alongside table data.
	char *schemaSerilizeData = serializeSchema(rel->schema);
	APPEND_STRING(result, schemaSerilizeData);

	// Free the memory allocated for schema serialization to avoid memory leaks
	free(schemaSerilizeData);

	// Return the final string containing table information and schema data
	RETURN_STRING(result);
}

// Serialize all page directories in the PageDirectoryCache into a single string.
// -- This function iterates through the page directory cache and serializes each page directory.
char *serializePageDirectories(PageDirectoryCache *pageDirectoryCache) 
{
	VarString *result; // Variable-length string to hold the result
	MAKE_VARSTRING(result); // Macro to initialize the VarString

	// Traverse the linked list of page directories in the cache
	PageDirectory *p = pageDirectoryCache->front;
	while(p != NULL) {
		// Serialize each page directory and append it to the result string
		APPEND_STRING(result, serializePageDirectory(p));
		p = p->next;
	}

	// Return the final string containing all serialized page directories
	RETURN_STRING(result);
}

// Serialize a single PageDirectory object into a string.
// -- The function converts page number, count, and first free slot to a string and formats them.
char *serializePageDirectory(PageDirectory *pd)
{
    VarString *result; // Variable-length string to hold the result
    MAKE_VARSTRING(result); // Macro to initialize the VarString

    // Temporary buffer to hold integer-to-string conversion
    int attrSize = sizeof(int); // The size of an integer (for fixed-length strings)
    char *data = malloc((attrSize + 1) * sizeof(char)); // Allocate memory for the string

    if (data == NULL) {
        // If memory allocation fails, return NULL to indicate an error
        return NULL;
    }

    // Convert the page number to a string and append it to the result
    memset(data, '0', attrSize); // Initialize the buffer with zeros
    data[attrSize] = '\0'; // Null-terminate the string
    PageInfoToString(3, pd->pageNum, data); // Convert pageNum to a string
    APPEND(result, "[%s-", data); // Append pageNum to result in formatted form

    // Convert the count (number of free slots) and append to the result
    memset(data, '0', attrSize); // Reuse buffer for count
    data[attrSize] = '\0'; // Null-terminate the string
    PageInfoToString(3, pd->count, data); // Convert count to a string
    APPEND(result, "%s-", data); // Append count to result

    // Convert the first free slot and append to the result
    memset(data, '0', attrSize); // Reuse buffer again for firstFreeSlot
    data[attrSize] = '\0'; // Null-terminate the string
    PageInfoToString(3, pd->firstFreeSlot, data); // Convert firstFreeSlot to a string
    APPEND(result, "%s]", data); // Append firstFreeSlot to result in formatted form

    // Append a newline character to the result for readability
    APPEND_STRING(result, "\n");

    // Free the memory used for the temporary buffer
    free(data); 

    // Return the final serialized string representing the page directory
    RETURN_STRING(result);
}

// Deserialize a string into a PageDirectoryCache structure.
// -- The function splits the input string (pdStr) by newlines and reconstructs the page directory entries.
PageDirectoryCache  *
deserializePageDirectories(char *pdStr)
{
	PageDirectory *front = NULL;  // Pointer to the first page directory (head of the list)
	PageDirectory *rear = NULL;   // Pointer to the last page directory (tail of the list)
	char *token;                  // Token to hold each line of the input string
	token = strtok(pdStr, "\n");   // Split the string by newlines
	int count = 0;                // Count of page directories
	
	// Loop through each token (line in the input string)
	while(token != NULL) {
		// Allocate memory for a new PageDirectory
		PageDirectory *pd = (PageDirectory*)malloc(sizeof(PageDirectory));
		
		// Extract page number, count, and first free slot from the token string
		char data[5];
		memset(data, '0', sizeof(char)*4);
		strncpy(data, token + 1, 4);
		data[4] = '\0';
		pd->pageNum = (int)strtol(data, NULL, 10);

		memset(data, '0', sizeof(char)*4);
		strncpy(data, token + 6, 4);
		data[4] = '\0';
		pd->count = (int)strtol(data, NULL, 10);

		memset(data, '0', sizeof(char)*4);
		strncpy(data, token + 11, 4);
		data[4] = '\0';
		pd->firstFreeSlot = (int)strtol(data, NULL, 10);

		pd->next = NULL;
		pd->pre = NULL;

		// Append the new PageDirectory to the linked list
		if(front == NULL) {
			front = pd;
		} else {
			rear->next = pd;
			pd->pre = rear;
		}
		rear = pd;

		// Get the next line (token)
		token = strtok(NULL, "\n");
		count = count + 1;
	}

	// Create a PageDirectoryCache and populate it
	PageDirectoryCache *pageDirectoryCache = (PageDirectoryCache*)malloc(sizeof(PageDirectoryCache));
	pageDirectoryCache->front = front;
	pageDirectoryCache->rear = rear;
	pageDirectoryCache->count = count;
	return pageDirectoryCache;
}

// Serialize a schema structure into a string representation.
// -- This function constructs a string that represents the schema of a table, including its attributes and data types.
char * 
serializeSchema(Schema *schema)
{
	int i;
	VarString *result;  // Variable-length string to hold the result
	MAKE_VARSTRING(result);  // Macro to initialize the VarString

	// Append the number of attributes to the result
	APPEND(result, "Schema with <%i> attributes (", schema->numAttr);

	// Append each attribute's name and type to the result string
	for(i = 0; i < schema->numAttr; i++)
	{
		APPEND(result,"%s%s: ", (i != 0) ? ",": "", schema->attrNames[i]);
		switch (schema->dataTypes[i])
		{
		case DT_INT:
			APPEND_STRING(result, "INT");
			break;
		case DT_FLOAT:
			APPEND_STRING(result, "FLOAT");
			break;
		case DT_STRING:
			APPEND(result,"STRING[%i]", schema->typeLength[i]);
			break;
		case DT_BOOL:
			APPEND_STRING(result,"BOOL");
			break;
		}
	}
	APPEND_STRING(result,")");

	// Append the schema's keys to the result string
	APPEND_STRING(result," with keys: {");
	for(i = 0; i < schema->keySize; i++)
		APPEND(result, "%s%s", ((i != 0) ? ",": ""), schema->attrNames[schema->keyAttrs[i]]);
	APPEND_STRING(result,"}\n");

	// Return the final serialized string for the schema
	RETURN_STRING(result);
}

// Serialize the contents of a table into a string.
// -- This function scans the table and converts each record into a serialized format.
char * 
serializeTableContent(RM_TableData *rel)
{
	int i;
	VarString *result;  // Variable-length string to hold the result
	RM_ScanHandle *sc = (RM_ScanHandle *) malloc(sizeof(RM_ScanHandle));  // Scan handle for table scanning
	Record *r = (Record *) malloc(sizeof(Record));  // Record object for fetching records during scanning
	MAKE_VARSTRING(result);  // Macro to initialize the VarString

	// Append the attribute names to the result string
	for(i = 0; i < rel->schema->numAttr; i++)
		APPEND(result, "%s%s", (i != 0) ? ", " : "", rel->schema->attrNames[i]);

	// Start a scan on the table without any condition (NULL condition)
	startScan(rel, sc, NULL);

	// Append each record to the result string
	while(next(sc, r) != RC_RM_NO_MORE_TUPLES)
	{
		APPEND_STRING(result, serializeRecord(r, rel->schema));
		APPEND_STRING(result,"\n");
	}
	// Close the scan once all records are fetched
	closeScan(sc);

	// Return the final serialized string containing table content
	RETURN_STRING(result);
}

// Extract a substring from a string between two specified characters.
// -- This function returns a portion of the string located between the 'start' and 'end' characters.
char *
substring(const char *s, const char start, const char end)
{
    int i = 0, j = 0;

    // Find the starting character in the string
    while(s[i] != start) {
        i++;
    }
    i++;
    j = i;

    // Find the ending character in the string
    while(s[i] != end) {
        i++;
    }
    
    // Calculate the size of the substring and allocate memory for it
    int size = i - j;
    char *temp = calloc(size + 1, sizeof(char));

    // Copy the substring into the allocated memory
    strncpy(temp, s + j,  size);
    temp[size] = '\0';

    // Return the extracted substring
    return temp;

}
// Deserialize a Schema structure from a serialized string.
// -- Parses the schema string and reconstructs the Schema object including attributes and keys.
Schema * 
deserializeSchema(char *schemaData)
{
	Schema *schema = (Schema *) malloc(sizeof(Schema));

	// Extract number of attributes from the schema string
	char *numAttrStr = substring(schemaData, '<', '>');
	int numAttr = atoi(numAttrStr);  // Convert extracted number to integer
    schema->numAttr = numAttr;
	free(numAttrStr);  // Free the temporary string used for extraction
    
    // Extract attributes information enclosed in parentheses
    char *attrInfo = substring(schemaData, '(', ')');
    parseAttrInfo(schema, attrInfo);  // Parse attributes info and populate schema
	free(attrInfo);  // Free the temporary string after parsing

    // Extract keys information enclosed in curly braces
    char *keyInfo = substring(schemaData, '{', '}');
    parseKeyInfo(schema, keyInfo);  // Parse keys info and populate schema keys
	free(keyInfo);  // Free the temporary string after parsing

	return schema;  // Return the newly created schema object
}


// Parse attribute information for a schema and populate attribute names, data types, and type lengths.
// -- Extracts attribute names and their corresponding data types from the serialized schema string.
void *
parseAttrInfo(Schema *schema, char *attrInfo) 
{
    char *t1;
    int numAttr = schema->numAttr;  // Number of attributes in the schema

    // Allocate memory for attribute names, data types, and their lengths.
    char **attrNames = (char **) malloc(sizeof(char*) * numAttr);
	DataType *dataTypes = (DataType *) malloc(sizeof(DataType) * numAttr);
	int *typeLength = (int *) malloc(sizeof(int) * numAttr);

    // Tokenize the input string to extract attribute names and data types.
	t1 = strtok(attrInfo, ": ");
    for(int i = 0; i < numAttr && t1 != NULL; ++i)
    {
        // Extract attribute name
        if(i != 0) {
            t1 = strtok (NULL, ": ");
        } 
        int size = strlen(t1) + 1;
        attrNames[i] = (char *)malloc(size * sizeof(char));  // Allocate memory for attribute name
        memcpy(attrNames[i], t1, size - 1);  // Copy the attribute name
        attrNames[i][size - 1] = '\0';  // Null-terminate the string

        // Extract data type
        t1 = strtok(NULL, ", ");
        int tokenSize = strlen(t1);

        // Assign the data type based on the string token
        if (t1[0] == 'I'){
            dataTypes[i] = DT_INT;
            typeLength[i] = 0;
        } else if (t1[0] == 'F'){
            dataTypes[i] = DT_FLOAT;
            typeLength[i] = 0;
        } else if (t1[0] == 'B'){
            dataTypes[i] = DT_BOOL;
            typeLength[i] = 0;
        } else if(t1[0] == 'S'){
            dataTypes[i] = DT_STRING;
        }
    }

    // Extract the string length from the schema data and set the type length for string attributes.
	char *length = substring(attrInfo, '[', ']');
    int stringLength = atoi(length);
    schema->attrNames = attrNames;
    for(int i = 0; i < numAttr; i++) {
        if(dataTypes[i] == DT_STRING){
            typeLength[i] = stringLength;  // Assign string length for string attributes
        }
    }

    // Set the schema fields
    schema->dataTypes = dataTypes;
    schema->attrNames = attrNames;
    schema->typeLength = typeLength;

    free(length);  // Free the allocated memory
}

// Parse key information for the schema and populate key attributes.
// -- Retrieves the key attribute index from the serialized schema string and stores it in the schema.
void *
parseKeyInfo(Schema *schema, char *keyInfo)
{
	int numAttr = schema->numAttr;
    int *keyAttrs = (int *) malloc(sizeof(int) * numAttr);  // Allocate memory for key attributes

    // Find the index of the key attribute
    int index = -1;
    for(int i = 0; i < numAttr; i++) {
        if(strcmp(schema->attrNames[i], keyInfo) == 0) {
            index = i;  // Found the key attribute
            break;
        }
    }

    if(index == -1) {
        printf("Not a valid attribute name\n");  // Handle invalid key attribute
    }

    // Set key attributes
    for(int i = 0; i < numAttr; ++i)
    {
       keyAttrs[i] = index;
    }
    schema->keyAttrs = keyAttrs;
	schema->keySize = 1;  // Set the key size
}

// Convert an integer value into a string format and store it in the provided data buffer.
// -- Converts the given value into a string of a specific size, adding leading zeros where necessary.
void PageInfoToString(int j,  int val,  char *data){
    int r = 0;
    int q = val;
    int last = j;
    // Convert integer to string by extracting digits
    while (q > 0 && j >= 0) {
        r = q % 10;
        q = q / 10;
        data[j] = data[j] + r;
        j--;
    }
    data[last + 1] = '\0';  // Null-terminate the string
}

// Serialize a record into a string format for storage or display.
// -- Converts the record's page number, slot, and attribute values into a human-readable string.
char *serializeRecord(Record *record, Schema *schema)
{
    VarString *result;  // Dynamic string variable
    MAKE_VARSTRING(result);
    int i;

    // Allocate memory for temporary data buffer to store page number and slot information
    int attrSize = sizeof(int);
    char *data = (char *)malloc((attrSize + 1) * sizeof(char));  // Dynamically allocate memory

    if (data == NULL) {
        return NULL;  // Handle memory allocation failure by returning NULL
    }

    // Convert and append the page number
    memset(data, '0', sizeof(char) * 4);  // Initialize buffer with zeros
    PageInfoToString(3, record->id.page, data);  // Convert page number to string
    APPEND(result, "[%s", data);

    // Convert and append the slot number
    memset(data, '0', sizeof(char) * 4);
    PageInfoToString(3, record->id.slot, data);  // Convert slot number to string
    APPEND(result, "-%s](", data);

    // Append the attributes in the record
    for (i = 0; i < schema->numAttr; i++) {
        APPEND_STRING(result, serializeAttr(record, schema, i));  // Serialize each attribute
        APPEND(result, "%s", (i == schema->numAttr - 1) ? "" : ",");  // Add commas between attributes
    }

    APPEND_STRING(result, ")\n");  // Close the serialized string

    free(data);  // Free the allocated memory for the temporary buffer

    RETURN_STRING(result);  // Return the serialized string
}
// Serialize the attribute value of a record based on its schema and attribute number.
// -- Converts the value of the specified attribute in the record to a human-readable string.
char * 
serializeAttr(Record *record, Schema *schema, int attrNum)
{
	int offset;  // Variable to store the offset of the attribute in the record's data.
	char attrData[5];  // Buffer to store the attribute's data.
	VarString *result;
	MAKE_VARSTRING(result);

	// Get the offset of the attribute within the record.
	attrOffset(schema, attrNum, &offset);
	memcpy(attrData, record->data + offset, 4);  // Copy the attribute data to attrData.
	attrData[4] = '\0';  // Null-terminate the string.

	// Serialize the attribute value based on its data type.
	switch(schema->dataTypes[attrNum])
	{
	case DT_INT:  // Integer attribute.
	{
		char val[5];
		memset(val, '\0', sizeof(int));  // Initialize value buffer.
		memcpy(val, attrData, sizeof(int));  // Copy the integer value.
		APPEND(result, "%s:%s", schema->attrNames[attrNum], val);  // Append the attribute name and value.
	}
	break;

	case DT_STRING:  // String attribute.
	{
		char *buf;
		int len = schema->typeLength[attrNum];  // Get the string length from the schema.
		buf = (char *) malloc(len + 1);  // Allocate memory for the string.
		strncpy(buf, attrData, len);  // Copy the string data.
		buf[len] = '\0';  // Null-terminate the string.
		APPEND(result, "%s:%s", schema->attrNames[attrNum], buf);  // Append the attribute name and value.
		free(buf);  // Free the allocated memory for the string.
	}
	break;

	case DT_FLOAT:  // Float attribute.
	{
		float val;
		memcpy(&val, attrData, sizeof(float));  // Copy the float value.
		APPEND(result, "%s:%f", schema->attrNames[attrNum], val);  // Append the attribute name and value.
	}
	break;

	case DT_BOOL:  // Boolean attribute.
	{
		bool val;
		memcpy(&val, attrData, sizeof(bool));  // Copy the boolean value.
		APPEND(result, "%s:%s", schema->attrNames[attrNum], val ? "TRUE" : "FALSE");  // Append the attribute name and value.
	}
	break;

	default:
		return "NO SERIALIZER FOR DATATYPE";  // Return an error if the data type is not supported.
	}

	RETURN_STRING(result);  // Return the serialized attribute string.
}

// Serialize the value of a `Value` structure to a human-readable string.
// -- Converts the value based on its data type (int, float, string, bool) to a string format.
char *
serializeValue(Value *val)
{
	VarString *result;
	MAKE_VARSTRING(result);

	// Serialize the value based on its data type.
	switch(val->dt)
	{
	case DT_INT:  // Integer value.
		APPEND(result, "%i", val->v.intV);
		break;
	case DT_FLOAT:  // Float value.
		APPEND(result, "%f", val->v.floatV);
		break;
	case DT_STRING:  // String value.
		APPEND(result, "%s", val->v.stringV);
		break;
	case DT_BOOL:  // Boolean value.
		APPEND_STRING(result, (val->v.boolV) ? "true" : "false");  // Convert the boolean to "true" or "false".
		break;
	}

	RETURN_STRING(result);  // Return the serialized value string.
}

// Convert a string representation of a value into a `Value` structure.
// -- Parses a string and creates a `Value` structure based on the prefix (i, f, s, b) for int, float, string, and bool.
Value *
stringToValue(char *val)
{
	Value *result = (Value *) malloc(sizeof(Value));  // Allocate memory for the result.

	// Convert the string to a value based on the prefix.
	switch(val[0])
	{
	case 'i':  // Integer.
		result->dt = DT_INT;
		result->v.intV = atoi(val + 1);  // Convert string to integer.
		break;
	case 'f':  // Float.
		result->dt = DT_FLOAT;
		result->v.floatV = atof(val + 1);  // Convert string to float.
		break;
	case 's':  // String.
		result->dt = DT_STRING;
		result->v.stringV = malloc(strlen(val));  // Allocate memory for the string.
		strcpy(result->v.stringV, val + 1);  // Copy the string.
		break;
	case 'b':  // Boolean.
		result->dt = DT_BOOL;
		result->v.boolV = (val[1] == 't') ? TRUE : FALSE;  // Convert string to boolean.
		break;
	default:  // Default to integer if the prefix is unrecognized.
		result->dt = DT_INT;
		result->v.intV = -1;
		break;
	}

	return result;  // Return the resulting `Value` structure.
}

// Calculate the offset of an attribute in a record based on its schema.
// -- Determines the byte offset of the attribute by summing the sizes of the preceding attributes.
RC 
attrOffset (Schema *schema, int attrNum, int *result)
{
	int offset = 0;  // Initialize the offset.
	int attrPos = 0;

	// Loop through each attribute to calculate the offset.
	for(attrPos = 0; attrPos < attrNum; attrPos++) {
		switch (schema->dataTypes[attrPos])
		{
		case DT_STRING:
			offset += schema->typeLength[attrPos];  // Add string length to the offset.
			break;
		case DT_INT:
			offset += sizeof(int);  // Add integer size to the offset.
			break;
		case DT_FLOAT:
			offset += sizeof(float);  // Add float size to the offset.
			break;
		case DT_BOOL:
			offset += sizeof(bool);  // Add boolean size to the offset.
			break;
		}
	}

	*result = offset;  // Set the result to the calculated offset.
	return RC_OK;  // Return success.
}

// Create a `RecordNode` struct to store record information, including page and slot numbers.
// -- Allocates and initializes a new `RecordNode` with the provided page, slot, and data.
RecordNode *createRecordNode(int page, int slot, char *data, int sizeRecord) {
	RecordNode *node = (RecordNode *)malloc(sizeof(RecordNode));  // Allocate memory for the node.
	char *content = (char*)calloc(sizeRecord + 1, sizeof(char));  // Allocate memory for record content.
	strcpy(content, data);  // Copy the record data.
	content[strlen(content)] = '\0';  // Null-terminate the content.
	node->page = page;  // Set the page number.
	node->slot = slot;  // Set the slot number.
	node->data = data;  // Set the data.
	node->pre = NULL;  // Initialize the previous pointer to NULL.
	node->next = NULL;  // Initialize the next pointer to NULL.
	return node;  // Return the created node.
}

// Deserialize a string of records into a linked list of `RecordNode` structures.
// -- Parses the serialized records and converts them into a linked list of `RecordNode` objects.
RecordNode *
deserializeRecords(Schema *schema, char *recordStr, int sizeRecord) 
{
	if(recordStr == NULL || schema == NULL) {
		return NULL;  // Return NULL if the input is invalid.
	}
	char *token;
	char *a = strdup(recordStr);  // Duplicate the record string.
    token = strtok(a, "\n");  // Tokenize the string by newlines.
	
	RecordNode *head = NULL;
	RecordNode *p = NULL;
	int i = 0;
    while(token != NULL) {
		Record *newRecord = (Record*)malloc(sizeof(Record));  // Allocate memory for a new record.
		char *recordData = (char*)calloc(sizeRecord, sizeof(char));  // Allocate memory for record data.
		newRecord->data = recordData;

		// Extract the page number and slot number from the token.
		char pageNum[5];
		memset(pageNum, '\0', 4);
		strncpy(pageNum, token + 1, 4);
		pageNum[4] = '\0';
		int page = (int)strtol(pageNum, NULL, 10);

		char slotNum[5];
		memset(slotNum, '\0', 4);
		strncpy(slotNum, token + 6, 4);
		slotNum[4] = '\0';
		int slot = (int)strtol(slotNum, NULL, 10);

		// Extract the record data and create a record node.
		char data[13];
		memset(data, '\0', 12);
		strncpy(data, token + 14, 4);
		strncpy(data + 4, token + 21, 4);
		strncpy(data + 8, token + 28, 4);
		data[12] = '\0';
		char *temp = strdup(data);
		RecordNode *node = createRecordNode(page, slot, temp, sizeRecord);  // Create the record node.

		// Link the node to the list.
		if(head == NULL) {
			head = node;
		} else {
			p->next = node;
		}
		p = node;
        token = strtok(NULL, "\n");  // Move to the next token.
    }
	return head;  // Return the head of the linked list.
}























