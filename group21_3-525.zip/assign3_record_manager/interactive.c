#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "dberror.h"
#include "expr.h"
#include "record_mgr.h"
#include "tables.h"
#include "test_helper.h"

#define TITLE_LENGTH 50
#define GENRE_LENGTH 20
#define MOVIE_LIST_FILE "movie_list.dat"
#define MAX_MOVIES 100

typedef struct MovieRecord {
    int id;                        // TID (Tuple ID) - Unique ID for each record
    char title[TITLE_LENGTH];
    char genre[GENRE_LENGTH];
    int year;
} MovieRecord;

Record *asRecord(Schema *schema, MovieRecord record);
void interactiveCreate(char *fileName);
void interactiveInsert(int movieId, char *movieTitle, char *movieGenre, int year);
void interactiveUpdate(int movieId);
void interactiveDelete(int movieId);
void interactiveView();
void displayMenu();
void saveMovieListToFile();
void loadMovieListFromFile();
int checkPrimaryKey(int movieId);  // Function to check for duplicate movie ID

Schema *interactiveSchema;
RM_TableData *interactiveTable;
MovieRecord movieList[MAX_MOVIES];
int movieCount = 0;

// Display the main menu to the user (Interactive Interface concept)
void displayMenu() {
    printf("\nMOVIE DATABASE\n"
           "1. Create movie list\n"
           "2. Insert movie\n"
           "3. Update movie\n"
           "4. Delete movie\n"
           "5. View all movies\n"
           "E. Exit\n"
           "\nWhat would you like to do:\n");
}

// Load the movie list from a file
void loadMovieListFromFile() {
    FILE *file = fopen(MOVIE_LIST_FILE, "rb");
    if (file == NULL) {
        printf("No movie list found. Starting with an empty list.\n");
        return;
    }

    fread(&movieCount, sizeof(int), 1, file);  // Read the movie count
    fread(movieList, sizeof(MovieRecord), movieCount, file);  // Read the movie records
    fclose(file);
    printf("Movie list loaded from file.\n");
}

// Save the movie list to a file
void saveMovieListToFile() {
    FILE *file = fopen(MOVIE_LIST_FILE, "wb");
    if (file == NULL) {
        printf("Error saving movie list to file!\n");
        return;
    }

    fwrite(&movieCount, sizeof(int), 1, file);  // Write the movie count
    fwrite(movieList, sizeof(MovieRecord), movieCount, file);  // Write the movie records
    fclose(file);
    printf("Movie list saved to file.\n");
}

// Check primary key constraint - Check if the primary key (movieId) already exists
int checkPrimaryKey(int movieId) {
    for (int i = 0; i < movieCount; i++) {
        if (movieList[i].id == movieId) {
            return 1;  // Movie ID already exists (Primary Key constraint violation)
        }
    }
    return 0;  // Movie ID does not exist, safe to insert
}

void recursive() {
    displayMenu();
    char option[2];  // Increase to 2 to account for the null terminator
    scanf("%s", option);

    if (strcmp(option, "1") == 0) {
        printf("\nEnter movie list name:\n");
        char listName[30];
        scanf("%s", listName);
        interactiveCreate(listName);  // Create a new movie list (Table)
        printf("\nMovie list created!\n");
    } else if (strcmp(option, "2") == 0) {
        printf("\nNew movie ID:\n");
        int movieId;
        scanf("%d", &movieId);

        // Check for Primary Key constraint
        if (checkPrimaryKey(movieId)) {
            printf("Error: Movie ID already exists. Please use a unique ID.\n");
        } else {
            printf("\nNew movie title:\n");
            char movieTitle[TITLE_LENGTH];
            scanf("%s", movieTitle);

            printf("\nNew movie genre:\n");
            char movieGenre[GENRE_LENGTH];
            scanf("%s", movieGenre);

            printf("\nRelease year:\n");
            int year;
            scanf("%d", &year);

            interactiveInsert(movieId, movieTitle, movieGenre, year);
            printf("Movie inserted successfully!\n");
            saveMovieListToFile();  // Save the movie list to file after inserting
        }

    } else if (strcmp(option, "3") == 0) {
        printf("\nExisting movie ID:\n");
        int movieId;
        scanf("%d", &movieId);
        interactiveUpdate(movieId);
        printf("Movie updated!\n");
        saveMovieListToFile();  // Save the movie list to file after updating
    } else if (strcmp(option, "4") == 0) {
        printf("\nExisting movie ID:\n");
        int movieId;
        scanf("%d", &movieId);
        interactiveDelete(movieId);
        printf("Movie deleted!\n");
        saveMovieListToFile();  // Save the movie list to file after deleting
    } else if (strcmp(option, "5") == 0) {
        interactiveView();  // Display all movies (Scan operation)
    } else if (strcmp(option, "e") == 0 || strcmp(option, "E") == 0) {
        saveMovieListToFile();  // Save the movie list to file before exiting
        printf("\nGoodbye!\n");
        closeTable(interactiveTable);
        free(interactiveTable); // Free the allocated memory
        exit(0);
    } else {
        printf("Unknown input!\n");
    }

    recursive();  // Recur to keep the menu looping (Interactive interface)
}

int main() {
    loadMovieListFromFile();  // Load the movie list from file at the start
    recursive();  // Start the interactive menu
    return 0;
}

// Create a new table for the movie list
void interactiveCreate(char *fileName) {
    char *names[] = {"id", "title", "genre", "year"};  // Attributes for the movie schema
    DataType types[] = {DT_INT, DT_STRING, DT_STRING, DT_INT};  // Data types for the attributes
    int sizes[] = {sizeof(int), TITLE_LENGTH, GENRE_LENGTH, sizeof(int)};  // Sizes of the attributes
    int keys[] = {0};  // Primary key is the 'id' field

    interactiveSchema = createSchema(4, names, types, sizes, 1, keys);
    createTable(fileName, interactiveSchema);

    interactiveTable = (RM_TableData *) malloc(sizeof(RM_TableData));
    openTable(interactiveTable, fileName);
}

// Insert a new movie into the list
void interactiveInsert(int movieId, char *movieTitle, char *movieGenre, int year) {
    MovieRecord record = {movieId, "", "", year};
    strncpy(record.title, movieTitle, TITLE_LENGTH - 1);  // Ensure no buffer overflow
    strncpy(record.genre, movieGenre, GENRE_LENGTH - 1);

    movieList[movieCount++] = record;  // Insert into in-memory movie list

    insertRecord(interactiveTable, asRecord(interactiveSchema, record));  // Add to database
}

// Update an existing movie in the list
void interactiveUpdate(int movieId) {
    int found = 0;
    printf("\nWhat would you like to update?\n1. Title\n2. Genre\n3. Year\n");
    int choice;
    scanf("%d", &choice);

    for (int i = 0; i < movieCount; i++) {
        if (movieList[i].id == movieId) {
            if (choice == 1) {
                printf("\nNew movie title:\n");
                scanf("%s", movieList[i].title);
            } else if (choice == 2) {
                printf("\nNew movie genre:\n");
                scanf("%s", movieList[i].genre);
            } else if (choice == 3) {
                printf("\nNew release year:\n");
                scanf("%d", &movieList[i].year);
            } else {
                printf("Invalid choice\n");
                return;
            }
            updateRecord(interactiveTable, asRecord(interactiveSchema, movieList[i]));  // Update in database
            printf("Movie updated!\n");
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Movie with ID %d not found!\n", movieId);
    }
}

// Delete a movie from the list
void interactiveDelete(int movieId) {
    int found = 0;
    for (int i = 0; i < movieCount; i++) {
        if (movieList[i].id == movieId) {
            for (int j = i; j < movieCount - 1; j++) {
                movieList[j] = movieList[j + 1];  // Shift movies to delete the record
            }
            movieCount--;
            RID rid;
            rid.page = movieId;  // The record's unique ID (TID) is used to identify it for deletion
            deleteRecord(interactiveTable, rid);  // Delete from database
            printf("Movie deleted successfully!\n");
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Movie with ID %d not found!\n", movieId);
    }
}

// View all movies in the list (Scan the table)
void interactiveView() {
    if (movieCount == 0) {
        printf("No movies to display!\n");
        return;
    }

    printf("\nMOVIE RECORDS:\n");
    printf("ID\tTitle\t\tGenre\t\tYear\n");
    printf("---------------------------------------------------\n");

    for (int i = 0; i < movieCount; i++) {
        printf("%d\t%s\t\t%s\t\t%d\n", movieList[i].id, movieList[i].title, movieList[i].genre, movieList[i].year);
    }

    // Also include code to view from the record manager if needed
    RM_ScanHandle scan;
    Record *record;
    startScan(interactiveTable, &scan, NULL);

    while (next(&scan, record) == RC_OK) {
        Value *value;

        // Get ID (TID)
        getAttr(record, interactiveSchema, 0, &value);
        printf("%d\t", value->v.intV);

        // Get Title
        getAttr(record, interactiveSchema, 1, &value);
        printf("%s\t\t", value->v.stringV);

        // Get Genre
        getAttr(record, interactiveSchema, 2, &value);
        printf("%s\t\t", value->v.stringV);

        // Get Year
        getAttr(record, interactiveSchema, 3, &value);
        printf("%d\n", value->v.intV);
    }

    closeScan(&scan);

    recursive();  // Display menu again after viewing records
}

// Convert the MovieRecord structure to a database record
Record *asRecord(Schema *schema, MovieRecord record) {
    Record *result;
    Value *value;
    createRecord(&result, schema);

    // Set ID (Primary Key and TID)
    MAKE_VALUE(value, DT_INT, record.id);
    setAttr(result, schema, 0, value);
    freeVal(value);

    // Set Title (Can add NULL value handling here if title is missing)
    MAKE_STRING_VALUE(value, record.title);
    setAttr(result, schema, 1, value);
    freeVal(value);

    // Set Genre (Can add NULL value handling here if genre is missing)
    MAKE_STRING_VALUE(value, record.genre);
    setAttr(result, schema, 2, value);
    freeVal(value);

    // Set Year
    MAKE_VALUE(value, DT_INT, record.year);
    setAttr(result, schema, 3, value);
    freeVal(value);

    return result;
}
