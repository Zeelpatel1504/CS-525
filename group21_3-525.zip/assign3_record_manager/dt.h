#ifndef DT_H
#define DT_H

// Check if bool is already defined (by system headers)
#ifndef __cplusplus
    #ifndef bool
        typedef short bool;
        #define true 1
        #define false 0
    #endif
#endif

// Avoid redefining TRUE and FALSE if they are already defined
#ifndef TRUE
    #define TRUE true
#endif

#ifndef FALSE
    #define FALSE false
#endif

#endif // DT_H
