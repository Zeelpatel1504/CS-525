#ifndef DBERROR_H
#define DBERROR_H

#include "stdio.h"
#include "stdlib.h"  // Added for malloc and free

/* Module-wide constants */
#define PAGE_SIZE 4096

/* Return code definitions */
typedef int RC;  // Defines RC as an integer

/* General return codes */
#define RC_OK 0
#define RC_FILE_NOT_FOUND 1
#define RC_FILE_HANDLE_NOT_INIT 2
#define RC_WRITE_FAILED 3
#define RC_READ_NON_EXISTING_PAGE 4
#define RC_ERROR 5
#define RC_PARAMS_ERROR 6
#define RC_ALLOC_MEM_FAIL 7
#define RC_DATATYPE_MISMATCH 8
#define RC_DATATYPE_UNDEFINED 9

/* New error codes */
#define RC_INVALID_ARGUMENT 10 // Error code for invalid arguments
#define RC_FILE_SIZE_EXCEEDED 11 // Error code for file size exceeded


/* Table related return codes */
#define RC_TABLE_NOT_EXISTS 100
#define RC_TABLE_EXISTS 101
#define RC_TABLE_CREATION_FAILED 102
#define RC_NO_SCHEMA_DATA 103

/* Record Manager (RM) related return codes */
#define RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE 200
#define RC_RM_EXPR_RESULT_IS_NOT_BOOLEAN 201
#define RC_RM_BOOLEAN_EXPR_ARG_IS_NOT_BOOLEAN 202
#define RC_RM_NO_MORE_TUPLES 203
#define RC_RM_NO_PRINT_FOR_DATATYPE 204
#define RC_RM_UNKNOWN_DATATYPE 205

/* Index Manager (IM) related return codes */
#define RC_IM_KEY_NOT_FOUND 300
#define RC_IM_KEY_ALREADY_EXISTS 301
#define RC_IM_N_TOO_LARGE 302  // Fixed typo from "TO_LAGE" to "TOO_LARGE"
#define RC_IM_NO_MORE_ENTRIES 303

/* Holder for error messages */
extern char *RC_message;

/* Function declarations */

/**
 * @brief Prints an error message based on the error code.
 * 
 * @param error Error code to describe
 */
extern void printError(RC error);

/**
 * @brief Returns the error message corresponding to the provided error code.
 * 
 * @param error Error code to describe
 * @return A string describing the error
 */
extern char *errorMessage(RC error);

/* Error handling macros */

/**
 * @brief Throws an error with a specific return code and message.
 * 
 * @param rc The return code
 * @param message The error message
 */
#define THROW(rc, message) \
    do {                   \
        RC_message = message; \
        return rc;          \
    } while (0)

/**
 * @brief Checks if the return code is an error, and if so, prints an error and exits.
 * 
 * @param code The return code to check
 */
#define CHECK(code)                             \
    do {                                        \
        int rc_internal = (code);               \
        if (rc_internal != RC_OK) {             \
            char *message = errorMessage(rc_internal); \
            printf("[%s-L%i-%s] ERROR: Operation returned error: %s\n", __FILE__, __LINE__, __TIME__, message); \
            free(message);                      \
            exit(1);                            \
        }                                       \
    } while (0)

#endif /* DBERROR_H */
