#include "buffer_mgr_stat.h"
#include "buffer_mgr.h"

#include <stdio.h>
#include <stdlib.h>

// Local function to print the replacement strategy of the buffer manager
static void printStrat (BM_BufferPool *const bm);

// External function to print the content of the buffer pool
// This function displays the frame contents, dirty flags, and fix counts for each frame in the buffer pool
void 
printPoolContent (BM_BufferPool *const bm)
{
	PageNumber *frameContent;  // Array to hold the page numbers currently in the buffer frames
	int *dirty;                // Array to hold dirty flags (1 if page is dirty, 0 if clean)
	int *fixCount;             // Array to hold fix counts (number of clients holding a page)
	int i;                     // Loop variable

	// Get frame contents, dirty flags, and fix counts from the buffer manager
	frameContent = getFrameContents(bm);  
	dirty = getDirtyFlags(bm);
	fixCount = getFixCounts(bm);

	// Print the buffer replacement strategy and the number of pages
	printf("{");
	printStrat(bm);   // Print the buffer pool's replacement strategy
	printf(" %i}: ", bm->numPages);   // Print the number of pages in the buffer pool

	// Print the content of each frame, showing page number, dirty flag, and fix count
	for (i = 0; i < bm->numPages; i++)
		// If the page is dirty, mark with 'x', otherwise leave it as a blank space
		printf("%s[%i%s%i]", ((i == 0) ? "" : ",") , frameContent[i], (dirty[i] ? "x": " "), fixCount[i]);
	
	printf("\n");

	// Free the memory allocated for frameContent, dirty flags, and fix counts
	free(frameContent);
	free(dirty);
	free(fixCount);
}

// Function to print the content of the buffer pool in a formatted string
// Returns a string that contains information about the frame contents, dirty flags, and fix counts
char *
sprintPoolContent (BM_BufferPool *const bm)
{
	PageNumber *frameContent;   // Array to hold page numbers of frames in the buffer
	int *dirty;                 // Array to hold dirty flags of frames in the buffer
	int *fixCount;              // Array to hold fix counts of frames in the buffer
	int i;                      // Loop variable
	char *message;              // String to hold the formatted output
	int pos = 0;                // Position tracker for the string

	// Allocate memory for the message string based on the number of pages
	message = (char *) malloc(256 + (22 * bm->numPages));

	// Get the content, dirty flags, and fix counts for all frames in the buffer
	frameContent = getFrameContents(bm);
	dirty = getDirtyFlags(bm);
	fixCount = getFixCounts(bm);

	// Loop through the frames and append information to the message string
	for (i = 0; i < bm->numPages; i++)
		pos += sprintf(message + pos, "%s[%i%s%i]", ((i == 0) ? "" : ","), frameContent[i], (dirty[i] ? "x": " "), fixCount[i]);

	// Free allocated memory
	free(frameContent);
	free(dirty);
	free(fixCount);

	// Return the formatted message string
	return message;
}

// Function to print the content of a single page in hexadecimal format
void
printPageContent (BM_PageHandle *const page)
{
	int i;  // Loop variable

	// Print the page number
	printf("[Page %i]\n", page->pageNum);

	// Loop through the page data and print it in hexadecimal format, grouped by 8 and 64 bytes
	for (i = 1; i <= PAGE_SIZE; i++)
		printf("%02X%s%s", page->data[i], (i % 8) ? "" : " ", (i % 64) ? "" : "\n");
}

// Function to print the content of a single page into a string in hexadecimal format
char *
sprintPageContent (BM_PageHandle *const page)
{
	int i;            // Loop variable
	char *message;    // String to hold the formatted output
	int pos = 0;      // Position tracker for the string

	// Allocate memory for the message string
	message = (char *) malloc(30 + (2 * PAGE_SIZE) + (PAGE_SIZE % 64) + (PAGE_SIZE % 8));

	// Start by printing the page number
	pos += sprintf(message + pos, "[Page %i]\n", page->pageNum);

	// Loop through the page data and append the hexadecimal format data to the message string
	for (i = 1; i <= PAGE_SIZE; i++)
		pos += sprintf(message + pos, "%02X%s%s", page->data[i], (i % 8) ? "" : " ", (i % 64) ? "" : "\n");

	// Return the formatted message string
	return message;
}

// Function to print the buffer pool replacement strategy (e.g., FIFO, LRU, CLOCK)
void
printStrat (BM_BufferPool *const bm)
{
	switch (bm->strategy)
	{
	case RS_FIFO:
		printf("FIFO");
		break;
	case RS_LRU:
		printf("LRU");
		break;
	case RS_CLOCK:
		printf("CLOCK");
		break;
	case RS_LFU:
		printf("LFU");
		break;
	case RS_LRU_K:
		printf("LRU-K");
		break;
	default:
		printf("%i", bm->strategy);
		break;
	}
}

// Function to get the contents (page numbers) of all frames in the buffer pool
// Returns an array of page numbers
PageNumber *getFrameContents (BM_BufferPool *const bm) {
	if(bm == NULL) {
		return NULL;
	}

	int totalNumPages = bm->numPages;

	// Get the page cache from the buffer manager's management data
	PageCache* pageCache = bm->mgmtData;

	// Allocate memory for the page numbers array
	PageNumber *arr = (PageNumber*) malloc(bm->numPages * sizeof(PageNumber));

	// Loop through the buffer pool and fill the array with the page numbers
	int i;
	for(i = 0; i < bm->numPages; i++) {
		arr[i] = pageCache->arr[i]->pageNum;
	}
	return arr;
}

// Function to get the dirty flags for all frames in the buffer pool
// Returns an array of dirty flags (1 if dirty, 0 if clean)
int *getDirtyFlags (BM_BufferPool *const bm) {
	if(bm == NULL) {
		return NULL;
	}

	// Get the page cache from the buffer manager's management data
	PageCache* pageCache = bm->mgmtData;
	int numPages = bm->numPages;

	// Allocate memory for the dirty flags array
	int *arr = (int*) malloc(numPages * sizeof(int));

	// Loop through the buffer pool and fill the array with dirty flags
	int i;
	for(i = 0; i < numPages; i++) {
		arr[i] = pageCache->arr[i]->dirtyBit;
	}
	return arr;
}

// Function to get the fix counts for all frames in the buffer pool
// Returns an array of fix counts (number of clients holding a page)
int *getFixCounts (BM_BufferPool *const bm)
{
	if(bm == NULL) {
		return NULL;
	}

	// Get the page cache from the buffer manager's management data
	PageCache* pageCache = bm->mgmtData;
	int numPages = bm->numPages;

	// Allocate memory for the fix counts array
	int *arr = (int*) malloc(numPages * sizeof(int));

	// Loop through the buffer pool and fill the array with fix counts
	int i;
	for(i = 0; i < numPages; i++) {
		arr[i] = pageCache->arr[i]->pinCount;
	}
	return arr;
}

// Function to get the number of read I/O operations performed by the buffer pool
int getNumReadIO (BM_BufferPool *const bm) {
	if(bm == NULL) {
		return -1;
	}

	// Get the page cache from the buffer manager's management data
    PageCache* pageCache = bm->mgmtData;

	// Return the number of read I/O operations
	return pageCache->numRead;
}

// Function to get the number of write I/O operations performed by the buffer pool
int getNumWriteIO (BM_BufferPool *const bm) {
	if(bm == NULL) {
		return -1;
	}

	// Get the page cache from the buffer manager's management data
    PageCache* pageCache = bm->mgmtData;

	// Return the number of write I/O operations
	return pageCache->numWrite;
}
