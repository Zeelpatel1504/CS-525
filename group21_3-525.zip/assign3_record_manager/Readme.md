This assignment was completed by Group 21.

Patel Zeel R- A20556822
Patel Dhruval -A20549909
Rajodiya Ruchika-A20562246


This project implements a simple record manager for managing tables with a fixed schema. The Record Manager (RM) provides essential functionality to create, insert, update, delete, and scan records in a table. Each table is stored in a separate page file, and the Record Manager utilizes a buffer manager to efficiently handle page access and memory management.

The project also implements advanced features such as primary key constraints, NULL value handling, and tombstone records for deleted entries, and provides an interactive interface to manipulate the movie database.


Here is the updated README file with the group information included:



Key Features

Table Management: Create, open, close, and delete tables with a defined schema.

Record Management: Insert, update, delete, and retrieve records in a table.

Scan Functionality: Execute scans with conditions to retrieve records based on specific criteria.

Primary Key Constraints: Ensures no duplicate primary keys are allowed when inserting or updating records.

NULL Value Handling: Support for SQL-style NULL values in the data types and records.

TIDs and Tombstones: Tracks records with Tombstones to manage deleted records efficiently without moving them around.

Interactive User Interface: A simple command-line interface to create tables, insert, update, delete records, and view the data.

File Storage: Stores the movie list to a file and allows reloading for persistent data across runs.


| File                     | Description |
| ------------------------- | ----------- |
| `buffer_mgr.*`            | Manages the memory page frames and page files for efficient data access. |
| `buffer_mgr_stat.*`       | Provides statistics interfaces for the Buffer Manager. |
| `dberror.*`               | Handles error reporting and tracking throughout the system. |
| `dt.h`                    | Defines Boolean constants for use in the project. |
| `expr.*`                  | Parses condition expressions used in scans and updates. |
| `record_mgr.*`            | Implements the core functions of the record manager, including table management, record manipulation, and scanning. |
| `rm_serializer.*`         | Responsible for serializing and deserializing data stored in files for persistence. |
| `storage_mgr.*`           | Manages file-based storage and memory for the database. |
| `tables.h`                | Defines data structures such as schema, record, and table management. |
| `test_assign3_1.c`        | Contains test cases for verifying the core functionality of the record manager. |
| `test_helper.h`           | Provides utilities for testing and assertions. |
| 'interactive.c'           | Implements an interactive interface for creating, inserting, updating, deleting, and viewing records in a movie list. The movie ID serves as the primary   
                             key and does not allow duplicate entries. Before inserting records, a new movie list is created in the file. 
                             The interactive system works seamlessly with these functionalities, and records can be added, updated, deleted, and viewed properly after the list is created.
                                                                                 

Functions Overview
Record Manager (record_mgr.c)

The following functions have been implemented in record_mgr.c:

Table and Manager Functions:
initRecordManager(): Initializes the record manager with the provided management data.

shutdownRecordManager(): Shuts down the record manager.

createTable(): Creates a new table with the given name and schema.

openTable(): Opens an existing table and initializes the table data structure.

closeTable(): Closes the table, releasing associated resources.

deleteTable(): Deletes the table with the specified name.

getNumTuples(): Retrieves the total number of tuples stored in the table.


Record Handling Functions:
insertRecord(): Inserts a new record into the table.

deleteRecord(): Deletes a record from the table using the provided record identifier.

updateRecord(): Updates an existing record in the table.

getRecord(): Retrieves a record from the table using the provided record identifier.


Scan Functions:
startScan(): Initializes a scan on the table based on the provided condition.

next(): Retrieves the next tuple that fulfills the scan condition.

closeScan(): Closes the scan handle, releasing associated resources.


Schema Functions:
getRecordSize(): Calculates and returns the size of records for a given schema.

createSchema(): Creates a schema with the provided attributes, data types, and keys.

freeSchema(): Frees the memory allocated for the schema structure and its components.


Record and Attribute Functions:
createRecord(): Creates a new record with the provided schema.

freeRecord(): Frees the memory allocated for a record.

getAttr(): Retrieves the attribute value of a record at the specified attribute number.

setAttr(): Sets the attribute value of a record at the specified attribute number.


Additional Structures in record_mgr.h
ScanInfo: Stores the scan condition, current page, and current slot during a scan operation.

Structures and Attributes in table.h
SlotDirectoryEntry: Tracks free space within a page using a slot directory entry.

PageDirectoryEntry: Tracks the page information, including page ID, free slots, and record counts.

RM_mgmtData: Stores the management data of a table, including file handlers and buffer pool pointers.

Testing
The test_assign3_1.c file contains the following test cases to verify the functionality of the record manager:

testInsertManyRecords(): Tests inserting multiple records to ensure the system handles bulk inserts efficiently.

testRecords(): Tests the creation, update, and retrieval of records.

testCreateTableAndInsert(): Tests creating a table and inserting records into it.

testUpdateTable(): Tests updating records within a table.

testScans() and testScansTwo(): Tests scanning through records based on conditions.

testMultipleScans(): Tests running multiple scans concurrently.

Serialization and Deserialization Functions

Serialization Functions:
serializeTableInfo(): Serializes the table's basic information, including the number of tuples and schema.

serializePageDirectories(): Serializes page directories into a string.

serializePageDirectory(): Serializes a page directory entry.

serializeSchema(): Converts a schema into a string format.

serializeTableContent(): Serializes all records of a table into a string format.

serializeRecord(): Serializes a single record according to its schema.

serializeAttr(): Serializes a specific attribute of a record.

serializeValue(): Serializes a value based on its type (int, float, string, bool).

Deserialization Functions:
deserializePageDirectories(): Deserializes page directories from a string into a PageDirectoryCache.

deserializeSchema(): Deserializes schema data from a string format back into a Schema.

deserializeRecords(): Converts serialized records into a linked list of RecordNode.

Optional Extensions
Below are some of the extensions included in this project:

Create Movie List: Allows users to create a movie list stored in a file.

Insert Movie: Inserts a new movie record with attributes like id, title, genre, and year.

Update Movie: Updates the attributes of an existing movie by specifying the movie ID.

Delete Movie: Deletes a movie by its ID. The system prevents deletion of movies that do not exist.

View Movies: Views all movies stored in the movie list.

Primary Key Constraint: The movie ID is treated as a primary key, ensuring no duplicate entries for the same movie ID.

TIDs and Tombstones: Implemented to handle tombstone markers for deleted records, ensuring that free space is reused effectively.

NULL Values: SQL-style NULL values have been added to the data types and expressions. This includes using NULL bitmaps to track NULL attributes in records.

Primary Key Constraints: Primary key constraints ensure that no record with the same key attribute value as an existing record can be inserted or updated.

Interactive Interface: A command-line interface that allows users to create tables, insert, update, delete records, and execute scans. This simple shell-based interface makes it easy to interact with the database system.

Conditional Updates Using Scans: The scan system supports updates using conditions (expressions) to modify tuples that meet certain criteria.



Instructions for Running the Project

To run the main program:
reach to root directory 
mingw32-make clean
mingw32-make
.\test_assign3_1


To terminate a running process:
reach to root directory
taskkill /F /IM assign3.exe

Remove the build directory (if it exists) by running the following command in PowerShell:
Remove-Item -Recurse -Force build

Create the build directory:
mkdir build


Navigate into the build directory:
cd build

Run CMake to generate the project:
cmake -G "MinGW Makefiles" ..

Build the project:
mingw32-make

Running the Project

To run the tests:
.\assign3.exe

Test results are in screeenshot folder 

Conclusion
This project provides a robust implementation of a record manager capable of managing tables, records, and scans efficiently. With advanced features like primary key constraints, tombstone records, and NULL value handling, the system offers a complete solution for basic database management. The optional extensions provide additional functionality, making this project a versatile tool for managing structured data in a file-based system.

